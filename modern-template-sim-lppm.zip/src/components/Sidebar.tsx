import React from 'react';
import { ThemePreset, CustomControls } from '../types';
import { User, Award, BookOpen, AlertCircle, History, ExternalLink, ChevronRight } from 'lucide-react';

interface SidebarProps {
  preset: ThemePreset;
  controls: CustomControls;
}

export default function Sidebar({ preset, controls }: SidebarProps) {
  // Determine border radius class
  const roundedClass = 
    controls.roundedMode === 'none' ? 'rounded-none' :
    controls.roundedMode === 'md' ? 'rounded-md' :
    controls.roundedMode === 'xl' ? 'rounded-xl' : 'rounded-2xl';

  // Determine user-specific color accents
  const colors = preset.config;

  return (
    <div className={`space-y-4 w-full ${controls.layoutMode === 'compact' ? 'space-y-3' : 'space-y-4'}`}>
      
      {/* 1. Contextual User Profile Card */}
      {controls.showSidebarProfile && (
        <div className={`${colors.cardBg} border border-gray-200 ${roundedClass} overflow-hidden shadow-sm transition-all duration-300 hover:shadow-md`}>
          <div className={`${colors.primaryBg} px-4 py-2.5 text-white text-xs font-bold flex justify-between items-center`}>
            <span>Profil Saya</span>
            <span className="cursor-pointer opacity-85 hover:opacity-100">✏️</span>
          </div>
          <div className="p-4">
            <div className="flex gap-3 items-center pb-3 border-b border-gray-100 mb-3 text-left">
              <div className="w-12 h-12 bg-gray-50 border-2 border-gray-200 rounded-full flex items-center justify-center text-xl shadow-xs shrink-0 select-none overflow-hidden relative">
                <svg className="w-full h-full bg-pink-100" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                  {/* Skin face */}
                  <circle cx="50" cy="46" r="22" fill="#fce7f3" />
                  {/* Smiling mouth */}
                  <path d="M43,51 Q50,56 57,51" stroke="#be123c" strokeWidth="2" strokeLinecap="round" fill="none" />
                  {/* Hair */}
                  <path d="M26,38 C28,21 38,18 50,18 C62,18 72,21 74,38" fill="#451a03" />
                  {/* Glasses */}
                  <circle cx="41" cy="42" r="6" fill="none" stroke="#1e293b" strokeWidth="2" />
                  <circle cx="59" cy="42" r="6" fill="none" stroke="#1e293b" strokeWidth="2" />
                  <line x1="47" y1="42" x2="53" y2="42" stroke="#1e293b" strokeWidth="2" />
                  <circle cx="41" cy="42" r="1.5" fill="#1e293b" />
                  <circle cx="59" cy="42" r="1.5" fill="#1e293b" />
                  {/* Suit collar */}
                  <path d="M25,82 L75,82 L70,105 L30,105 Z" fill="#1e3a8a" />
                  <path d="M42,82 L58,82 L50,92 Z" fill="#ffffff" />
                  <path d="M48,83 L52,83 L50,102 Z" fill="#3b82f6" />
                </svg>
              </div>
              <div className="min-w-0">
                <h3 className={`text-xs font-bold leading-tight ${colors.textColor} uppercase tracking-tight truncate`}>
                  {preset.brand.userName}
                </h3>
                <p className="text-[10px] text-gray-500 whitespace-pre-line leading-relaxed">
                  {preset.brand.userMeta}
                </p>
                <span className="inline-block mt-1 px-1.5 py-0.5 bg-emerald-50 text-emerald-700 text-[9px] font-bold rounded">
                  Aktif Mengajar / Dosen
                </span>
              </div>
            </div>

            {/* Profile Statistics Grid (Customized based on presets) */}
            <div className="grid grid-cols-3 text-center divide-x divide-gray-100">
              <div className="px-1">
                <div className="text-xs font-black text-slate-800 tracking-tight">
                  {preset.brand.userSinta}
                </div>
                <div className="text-[9px] text-gray-400 font-medium leading-tight pt-1">
                  Sinta Score Overall
                </div>
              </div>
              <div className="px-1">
                <div className="text-xs font-black text-slate-800 tracking-tight">
                  {preset.brand.userEducation}
                </div>
                <div className="text-[9px] text-gray-400 font-medium leading-tight pt-1">
                  Jenjang Pendidikan
                </div>
              </div>
              <div className="px-1 text-center">
                <div className="text-xs font-extrabold text-amber-600 tracking-tight">
                  {preset.brand.userRank}
                </div>
                <div className="text-[9px] text-gray-400 font-medium leading-tight pt-1">
                  Jabatan Akademik
                </div>
              </div>
            </div>
            
            <div className="mt-3.5 pt-3 border-t border-gray-100 flex items-center justify-between text-[10px] text-blue-600 font-bold hover:underline cursor-pointer">
              <span>Sinkronisasi Data SINTA Dikti</span>
              <ChevronRight className="w-3 h-3 text-blue-500" />
            </div>
          </div>
        </div>
      )}

      {/* 2. Historic List or Dynamic Logging Category */}
      <div className={`${colors.cardBg} border border-gray-200 ${roundedClass} overflow-hidden shadow-sm transition-all duration-300 hover:shadow-md`}>
        <div className={`${colors.primaryBg} px-4 py-2.5 text-white text-xs font-bold flex justify-between items-center`}>
          <span className="flex items-center gap-1">
            <History className="w-3.5 h-3.5" />
            Riwayat Usulan
          </span>
          <span className="text-[10px] opacity-75 font-mono">Real-time</span>
        </div>
        <div className="p-4 space-y-4">
          {preset.history.map((hist, idx) => (
            <div key={idx} className="pb-3 border-b border-gray-50 last:border-b-0 last:pb-0">
              <div className="flex justify-between items-center mb-1">
                <span className={`text-[10px] font-black uppercase tracking-wider text-blue-700`}>
                  {hist.category}
                </span>
                <span className="text-[9px] text-blue-500 cursor-pointer font-bold hover:underline flex items-center gap-0.5">
                  Selengkapnya <ExternalLink className="w-2.5 h-2.5 text-blue-400" />
                </span>
              </div>
              <p className="text-[10.5px] text-gray-600 leading-normal border-l-2 pl-2 border-slate-300 hover:border-blue-500 transition-all">
                {hist.title}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Helper Tip / Tech info */}
      <div className="p-3.5 bg-indigo-50/50 border border-indigo-100 rounded-lg">
        <h4 className="text-[11px] font-bold text-indigo-900 flex items-center gap-1 mb-1">
          <BookOpen className="w-3.5 h-3.5 text-indigo-700" />
          Ekstraksi Template Instan
        </h4>
        <p className="text-[10px] text-indigo-900/85 leading-relaxed">
          Semua konfigurasi warna, navigasi, dan tata letak table yang diubah secara visual akan langsung tersinkronisasi ke dalam menu ekspor kode di kanan atas.
        </p>
      </div>

    </div>
  );
}
