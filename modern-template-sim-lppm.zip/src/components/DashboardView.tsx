import React, { useState, useMemo, useEffect } from 'react';
import { ThemePreset, CustomControls } from '../types';
import { 
  Sparkles, Calendar, TrendingUp, Cpu, Info, CheckCircle2, 
  BarChart3, LineChart, Award, ArrowUpRight, CheckCircle, 
  ChevronDown, ChevronUp, Layers, Coins, Settings, Plus, Trash2, 
  Edit3, Megaphone, CalendarClock, Newspaper, HeartHandshake,
  ChevronLeft, ChevronRight, RotateCcw, X, Check, Bell
} from 'lucide-react';

interface DashboardViewProps {
  preset: ThemePreset;
  controls: CustomControls;
}

export interface BulletinItem {
  id: string;
  type: 'pengumuman' | 'jadwal' | 'berita' | 'salam';
  title: string;
  content: string;
  date: string;
  badge: string;
  isImportant?: boolean;
}

const defaultBulletins: BulletinItem[] = [
  {
    id: 'b-1',
    type: 'salam',
    title: 'Salam Semangat Tri Dharma',
    content: 'Have a nice Thursday! Tetap semangat berkarya dalam Tri Dharma Perguruan Tinggi LPPM ITSNU Pekalongan.',
    date: '11 Juni 2026',
    badge: '👋 MOTIVASI & SALAM',
    isImportant: false
  },
  {
    id: 'b-2',
    type: 'pengumuman',
    title: 'Batas Akhir Laporan Kemajuan & SPTB 70%',
    content: 'Batas Akhir Unggah Laporan Kemajuan & SPTB 70%: 15 Juli 2026. Mohon bapak/ibu dosen peneliti melengkapi berkas.',
    date: '15 Juli 2026',
    badge: '📢 PENGUMUMAN PENTING',
    isImportant: true
  },
  {
    id: 'b-3',
    type: 'jadwal',
    title: 'Desk Evaluasi Proposal & Monev Lapangan Tahap II',
    content: 'Desk Evaluasi & Monev Lapangan Proposal Tahap II: 2 - 4 Agustus 2026 bertempat di Ruang Rapat LPPM Lt. 2.',
    date: '02-04 Ags 2026',
    badge: '📅 JADWAL KEGIATAN',
    isImportant: true
  },
  {
    id: 'b-4',
    type: 'berita',
    title: 'Sosialisasi Hibah Riset & Hilirisasi Prototipe 2026',
    content: 'Sosialisasi Panduan Riset Hibah Kemendiktisaintek & Skema Hilirisasi Riset ITSNU Pekalongan Tahun Akademik 2026/2027.',
    date: '20 Juni 2026',
    badge: '📰 BERITA TERKINI',
    isImportant: false
  }
];

interface YearStat {
  year: string;
  usulanPenelitian: number;
  didanaiPenelitian: number;
  usulanPengabdian: number;
  didanaiPengabdian: number;
  danaTotalJuta: number;
  catatan: string;
}

const trendData: YearStat[] = [
  {
    year: '2021',
    usulanPenelitian: 20,
    didanaiPenelitian: 12,
    usulanPengabdian: 14,
    didanaiPengabdian: 8,
    danaTotalJuta: 310,
    catatan: 'Laporan Akhir Lengkap & Luaran Sinta Terbit'
  },
  {
    year: '2022',
    usulanPenelitian: 25,
    didanaiPenelitian: 15,
    usulanPengabdian: 18,
    didanaiPengabdian: 11,
    danaTotalJuta: 420,
    catatan: 'Pertanggungjawaban Keuangan & SPTB 100%'
  },
  {
    year: '2023',
    usulanPenelitian: 32,
    didanaiPenelitian: 21,
    usulanPengabdian: 22,
    didanaiPengabdian: 15,
    danaTotalJuta: 580,
    catatan: 'Monev Selesai & Prototipe Terdaftar'
  },
  {
    year: '2024',
    usulanPenelitian: 38,
    didanaiPenelitian: 26,
    usulanPengabdian: 28,
    didanaiPengabdian: 19,
    danaTotalJuta: 725,
    catatan: 'Serah Terima BASTB & BAST Luaran Jurnal'
  },
  {
    year: '2025',
    usulanPenelitian: 46,
    didanaiPenelitian: 32,
    usulanPengabdian: 34,
    didanaiPengabdian: 24,
    danaTotalJuta: 890,
    catatan: 'Surat Tugas & Kontrak Tahap Pelaporan'
  },
  {
    year: '2026',
    usulanPenelitian: 54,
    didanaiPenelitian: 38,
    usulanPengabdian: 40,
    didanaiPengabdian: 29,
    danaTotalJuta: 1080,
    catatan: 'Tahun Berjalan / Seleksi & Verifikasi Aktif'
  }
];

export default function DashboardView({ preset, controls }: DashboardViewProps) {
  const [filterScheme, setFilterScheme] = useState<'all' | 'penelitian' | 'pengabdian'>('all');
  const [viewMode, setViewMode] = useState<'modern_both' | 'bar' | 'trend'>('modern_both');
  const [activeChartHover, setActiveChartHover] = useState<number | null>(5); // default select 2026
  const [showTableDetail, setShowTableDetail] = useState(false);

  // Announcement / News / Schedule Banner State
  const [bulletins, setBulletins] = useState<BulletinItem[]>(() => {
    const saved = localStorage.getItem('lppm_dashboard_bulletins');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return defaultBulletins;
      }
    }
    return defaultBulletins;
  });

  const [activeBulletinIndex, setActiveBulletinIndex] = useState(0);
  const [isAutoRotate, setIsAutoRotate] = useState(true);
  const [isManageModalOpen, setIsManageModalOpen] = useState(false);
  const [editingBulletin, setEditingBulletin] = useState<BulletinItem | null>(null);

  // New bulletin form state
  const [formType, setFormType] = useState<BulletinItem['type']>('pengumuman');
  const [formTitle, setFormTitle] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formDate, setFormDate] = useState('Juni 2026');
  const [formImportant, setFormImportant] = useState(false);

  // Persist bulletins
  useEffect(() => {
    localStorage.setItem('lppm_dashboard_bulletins', JSON.stringify(bulletins));
  }, [bulletins]);

  // Auto rotate banner bulletins
  useEffect(() => {
    if (!isAutoRotate || bulletins.length <= 1) return;
    const interval = setInterval(() => {
      setActiveBulletinIndex((prev) => (prev + 1) % bulletins.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [isAutoRotate, bulletins.length]);

  const currentBulletin = bulletins[activeBulletinIndex] || bulletins[0];

  const handleNextBulletin = () => {
    setActiveBulletinIndex((prev) => (prev + 1) % bulletins.length);
  };

  const handlePrevBulletin = () => {
    setActiveBulletinIndex((prev) => (prev - 1 + bulletins.length) % bulletins.length);
  };

  const handleSaveBulletin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formContent.trim()) return;

    let badge = '📢 PENGUMUMAN';
    if (formType === 'jadwal') badge = '📅 JADWAL KEGIATAN';
    else if (formType === 'berita') badge = '📰 BERITA TERKINI';
    else if (formType === 'salam') badge = '👋 MOTIVASI & SALAM';

    if (editingBulletin) {
      setBulletins((prev) =>
        prev.map((item) =>
          item.id === editingBulletin.id
            ? {
                ...item,
                type: formType,
                title: formTitle.trim() || 'Pengumuman LPPM',
                content: formContent.trim(),
                date: formDate.trim() || 'Juni 2026',
                badge,
                isImportant: formImportant
              }
            : item
        )
      );
      setEditingBulletin(null);
    } else {
      const newItem: BulletinItem = {
        id: `b-${Date.now()}`,
        type: formType,
        title: formTitle.trim() || 'Informasi LPPM',
        content: formContent.trim(),
        date: formDate.trim() || 'Juni 2026',
        badge,
        isImportant: formImportant
      };
      setBulletins((prev) => [newItem, ...prev]);
      setActiveBulletinIndex(0);
    }

    // Reset form
    setFormTitle('');
    setFormContent('');
    setFormDate('Juni 2026');
    setFormImportant(false);
  };

  const handleStartEdit = (b: BulletinItem) => {
    setEditingBulletin(b);
    setFormType(b.type);
    setFormTitle(b.title);
    setFormContent(b.content);
    setFormDate(b.date);
    setFormImportant(!!b.isImportant);
  };

  const handleDeleteBulletin = (id: string) => {
    if (bulletins.length <= 1) {
      alert('Minimal harus ada satu pengumuman atau salam aktif.');
      return;
    }
    setBulletins((prev) => prev.filter((item) => item.id !== id));
    setActiveBulletinIndex(0);
  };

  const handleResetBulletins = () => {
    if (window.confirm('Kembalikan ke pengumuman & jadwal bawaan LPPM?')) {
      setBulletins(defaultBulletins);
      setActiveBulletinIndex(0);
    }
  };

  // Determine border radius class
  const roundedClass = 
    controls.roundedMode === 'none' ? 'rounded-none' :
    controls.roundedMode === 'md' ? 'rounded-md' :
    controls.roundedMode === 'xl' ? 'rounded-xl' : 'rounded-2xl';

  const colors = preset.config;

  // Process filtered dataset
  const processedData = useMemo(() => {
    return trendData.map((item) => {
      let usulan = 0;
      let didanai = 0;

      if (filterScheme === 'penelitian') {
        usulan = item.usulanPenelitian;
        didanai = item.didanaiPenelitian;
      } else if (filterScheme === 'pengabdian') {
        usulan = item.usulanPengabdian;
        didanai = item.didanaiPengabdian;
      } else {
        usulan = item.usulanPenelitian + item.usulanPengabdian;
        didanai = item.didanaiPenelitian + item.didanaiPengabdian;
      }

      const rate = usulan > 0 ? (didanai / usulan) * 100 : 0;
      const tidakDidanai = usulan - didanai;

      return {
        ...item,
        usulan,
        didanai,
        tidakDidanai,
        rate: Number(rate.toFixed(1))
      };
    });
  }, [filterScheme]);

  // Aggregate summary calculations
  const totals = useMemo(() => {
    const totalUsulan = processedData.reduce((acc, curr) => acc + curr.usulan, 0);
    const totalDidanai = processedData.reduce((acc, curr) => acc + curr.didanai, 0);
    const totalTidakDidanai = totalUsulan - totalDidanai;
    const fundingRate = totalUsulan > 0 ? ((totalDidanai / totalUsulan) * 100).toFixed(1) : '0';
    const totalDana = trendData.reduce((acc, curr) => {
      if (filterScheme === 'penelitian') return acc + (curr.danaTotalJuta * 0.6);
      if (filterScheme === 'pengabdian') return acc + (curr.danaTotalJuta * 0.4);
      return acc + curr.danaTotalJuta;
    }, 0);

    const maxUsulan = Math.max(...processedData.map((d) => d.usulan), 1);

    return {
      totalUsulan,
      totalDidanai,
      totalTidakDidanai,
      fundingRate,
      totalDanaMilyar: (totalDana / 1000).toFixed(2),
      maxUsulan
    };
  }, [processedData, filterScheme]);

  const activeItem = activeChartHover !== null ? processedData[activeChartHover] : processedData[processedData.length - 1];

  return (
    <div className={`space-y-4 ${controls.layoutMode === 'compact' ? 'space-y-3' : 'space-y-4'}`}>
      
      {/* 1. Welcome Banner Card with Admin-Managed Bulletins (News / Schedule / Announcement) */}
      <div 
        id="dashboard-welcome-banner"
        className={`${colors.primaryBg} ${roundedClass} text-white p-6 shadow-sm relative overflow-hidden transition-all duration-300 min-h-[160px] flex items-center justify-between`}
      >
        {/* Abstract visual decor */}
        <div className="absolute right-0 top-0 w-48 h-48 bg-white/5 rounded-full translate-x-12 -translate-y-8 blur-2xl pointer-events-none"></div>
        <div className="absolute right-1/3 bottom-0 w-32 h-32 bg-cyan-400/10 rounded-full translate-y-10 blur-xl pointer-events-none"></div>
        
        {/* Dynamic Lecturer Illustrator Mascot */}
        <div className="hidden lg:flex absolute right-6 bottom-0 h-36 w-44 items-end justify-center pointer-events-none select-none z-0 opacity-80 overflow-hidden">
          <svg className="w-full h-full overflow-visible" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
            <path d="M10,20 L12,23 L15,24 L12,25 L10,28 L8,25 L5,24 L8,23 Z" fill="#38bdf8" opacity="0.8"/>
            <path d="M100,50 L101.5,53 L104,54 L101.5,55 L100,58 L98.5,55 L96,54 L98.5,53 Z" fill="#38bdf8" opacity="0.9"/>
            <ellipse cx="65" cy="115" rx="35" ry="5" fill="rgba(0,0,0,0.2)" />
            <rect x="58" y="72" width="14" height="15" rx="3" fill="#bae6fd" />
            <rect x="45" y="32" width="40" height="42" rx="14" fill="#e0f2fe" />
            <circle cx="53" cy="58" r="4" fill="#38bdf8" opacity="0.4" />
            <circle cx="77" cy="58" r="4" fill="#38bdf8" opacity="0.4" />
            <path d="M42,42 C42,24 55,20 68,22 C81,24 88,34 88,44" stroke="#0f172a" strokeWidth="7" strokeLinecap="round" fill="none" />
            <path d="M43,36 C48,26 62,24 74,25 C84,26 87,32 87,36" fill="#0f172a" />
            <path d="M57,60 Q65,66 73,60" stroke="#0284c7" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            <circle cx="54" cy="48" r="9" fill="none" stroke="#0f172a" strokeWidth="2.5" />
            <circle cx="76" cy="48" r="9" fill="none" stroke="#0f172a" strokeWidth="2.5" />
            <line x1="63" y1="48" x2="67" y2="48" stroke="#0f172a" strokeWidth="2.5" />
            <circle cx="54" cy="48" r="2.2" fill="#0f172a" />
            <circle cx="76" cy="48" r="2.2" fill="#0f172a" />
            <path d="M35,90 L95,90 L88,125 L42,125 Z" fill="#0369a1" />
            <path d="M54,90 L76,90 L65,107 Z" fill="#ffffff" />
            <path d="M62,91 L68,91 L65,123 L62,123 Z" fill="#38bdf8" stroke="#0284c7" strokeWidth="0.5" />
          </svg>
        </div>

        {/* Content Section */}
        <div className="relative z-10 space-y-2.5 max-w-full lg:max-w-[76%] text-left">
          {/* Top Row: Date & Admin Manage Button */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] uppercase font-bold bg-white/20 tracking-wider">
              <Calendar className="w-3 h-3" />
              <span>📅 Kamis, 11 Juni 2026</span>
            </div>

            {/* Current Bulletin Category Badge */}
            <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase transition-all shadow-xs ${
              currentBulletin.type === 'pengumuman' ? 'bg-amber-400 text-amber-950 ring-1 ring-amber-300' :
              currentBulletin.type === 'jadwal' ? 'bg-emerald-400 text-emerald-950 ring-1 ring-emerald-300' :
              currentBulletin.type === 'berita' ? 'bg-cyan-300 text-cyan-950 ring-1 ring-cyan-200' :
              'bg-blue-300 text-blue-950 ring-1 ring-blue-200'
            }`}>
              {currentBulletin.badge}
            </span>

            {/* Admin Management Trigger */}
            <button
              type="button"
              onClick={() => setIsManageModalOpen(true)}
              className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-white/15 hover:bg-white/30 text-white transition-all cursor-pointer border border-white/25 ml-auto md:ml-0"
              title="Kelola pengumuman, jadwal kegiatan, dan berita LPPM"
            >
              <Settings className="w-3 h-3 text-cyan-200 animate-spin-slow" />
              <span>Kelola Pengumuman/Jadwal</span>
            </button>
          </div>

          {/* Personalized Greeting */}
          <div>
            <h2 className="text-xl md:text-2xl font-black tracking-tight flex items-center gap-2">
              <span>Selamat Datang, {preset.brand.userName}!</span>
              <Sparkles className="w-5 h-5 text-amber-300 animate-pulse shrink-0" />
            </h2>
          </div>

          {/* Admin Managed Dynamic Bulletin Box */}
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-3 text-white transition-all duration-300 relative group">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1 min-w-0 pr-2">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-xs text-cyan-200 uppercase tracking-wide">
                    {currentBulletin.title}
                  </span>
                  <span className="text-[10px] text-white/70 font-mono">
                    • {currentBulletin.date}
                  </span>
                </div>
                <p className="text-xs md:text-sm text-white/95 font-medium leading-relaxed">
                  {currentBulletin.content}
                </p>
              </div>

              {/* Bulletin Navigation Controls */}
              <div className="flex items-center gap-1 shrink-0 pt-0.5">
                <button
                  type="button"
                  onClick={handlePrevBulletin}
                  title="Sebelumnya"
                  className="w-6 h-6 rounded-md bg-white/10 hover:bg-white/25 flex items-center justify-center text-white cursor-pointer transition-all"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
                <span className="text-[10px] font-mono font-bold text-white/80 px-1">
                  {activeBulletinIndex + 1}/{bulletins.length}
                </span>
                <button
                  type="button"
                  onClick={handleNextBulletin}
                  title="Berikutnya"
                  className="w-6 h-6 rounded-md bg-white/10 hover:bg-white/25 flex items-center justify-center text-white cursor-pointer transition-all"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Pagination dots indicator */}
            <div className="flex items-center gap-1 mt-2">
              {bulletins.map((_, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setActiveBulletinIndex(idx)}
                  className={`h-1 rounded-full transition-all cursor-pointer ${
                    activeBulletinIndex === idx ? 'w-5 bg-cyan-300' : 'w-1.5 bg-white/30 hover:bg-white/60'
                  }`}
                  title={`Pindah ke item ${idx + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 2. Stats Grid Cards */}
      {controls.showStats && (
        <div 
          id="dashboard-stats-grid"
          className={`grid grid-cols-1 sm:grid-cols-2 ${preset.stats.length === 4 ? 'lg:grid-cols-4' : 'lg:grid-cols-3'} gap-3.5`}
        >
          {preset.stats.map((stat, idx) => {
            const bgClass = stat.colorClass || colors.highlightColors.first;

            return (
              <div
                key={idx}
                id={`stat-card-${idx}`}
                className={`${bgClass} ${roundedClass} text-white p-4 uppercase flex items-center justify-between shadow-sm transition-all duration-350 hover:-translate-y-1 hover:shadow-md cursor-pointer`}
              >
                <div className="space-y-1 pr-2 min-w-0">
                  <div className="text-3xl font-black tracking-tight leading-none font-mono tabular-nums">
                    {stat.value}
                  </div>
                  <div className="text-xs font-black uppercase tracking-wide truncate">
                    {stat.title}
                  </div>
                  <p className="text-[10px] text-white/80 normal-case leading-snug whitespace-pre-line truncate">
                    {stat.sub}
                  </p>
                </div>
                <div className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center text-base select-none shrink-0 transition-all">
                  {stat.icon}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 3. Redesigned Modern Infographic Charting Box Matching Uploaded Graphic */}
      {controls.showChart && (
        <div 
          id="dashboard-chart-box"
          className={`bg-white border border-slate-200 ${roundedClass} p-5 md:p-6 shadow-sm space-y-6 overflow-hidden`}
        >
          {/* Header Row: Title, Filters & Controls */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <span className="p-1.5 bg-cyan-50 text-cyan-700 rounded-lg border border-cyan-200/60 shadow-xs">
                  <TrendingUp className="w-4 h-4 text-cyan-600" />
                </span>
                <h3 className={`text-base font-extrabold uppercase tracking-wide ${colors.primaryText}`}>
                  Visualisasi Trend Usulan Penelitian & Pengabdian
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Menghitung visualisasi volume usulan yang diunggah dan didanai (Tahun Akademik 2021 - 2026)
              </p>
            </div>
            
            {/* Interactive Scheme Filter Controls */}
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200/80 text-xs shadow-xs">
                <button
                  type="button"
                  onClick={() => setFilterScheme('all')}
                  className={`px-3 py-1 font-semibold rounded-md transition-all cursor-pointer ${
                    filterScheme === 'all'
                      ? 'bg-white text-cyan-800 shadow-xs font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Semua Skema
                </button>
                <button
                  type="button"
                  onClick={() => setFilterScheme('penelitian')}
                  className={`px-3 py-1 font-semibold rounded-md transition-all cursor-pointer ${
                    filterScheme === 'penelitian'
                      ? 'bg-white text-blue-700 shadow-xs font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Penelitian
                </button>
                <button
                  type="button"
                  onClick={() => setFilterScheme('pengabdian')}
                  className={`px-3 py-1 font-semibold rounded-md transition-all cursor-pointer ${
                    filterScheme === 'pengabdian'
                      ? 'bg-white text-emerald-700 shadow-xs font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Pengabdian
                </button>
              </div>

              {/* View Layout Controls */}
              <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200/80 text-xs">
                <button
                  type="button"
                  title="Tampilan Lengkap (Modern Infografis)"
                  onClick={() => setViewMode('modern_both')}
                  className={`px-2.5 py-1 rounded-md transition-all cursor-pointer font-bold flex items-center gap-1 ${
                    viewMode === 'modern_both'
                      ? 'bg-cyan-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Infografis</span>
                </button>
                <button
                  type="button"
                  title="Fokus Grafik Batang Kapsul"
                  onClick={() => setViewMode('bar')}
                  className={`p-1.5 rounded-md transition-all cursor-pointer ${
                    viewMode === 'bar'
                      ? 'bg-cyan-600 text-white shadow-xs'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  <BarChart3 className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  title="Fokus Kurva Area Mountain"
                  onClick={() => setViewMode('trend')}
                  className={`p-1.5 rounded-md transition-all cursor-pointer ${
                    viewMode === 'trend'
                      ? 'bg-cyan-600 text-white shadow-xs'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  <LineChart className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* SECTION A: 3 Circular Progress Gauge Meters (from Top Row of Uploaded Image) */}
          <div className="bg-gradient-to-b from-sky-50/50 via-slate-50/40 to-white p-5 rounded-2xl border border-sky-100/80 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse"></span>
                Indikator Capaian Kinerja Utama LPPM (KPI Gauge)
              </span>
              <span className="text-[11px] font-mono text-cyan-800 bg-cyan-50 border border-cyan-200 px-2 py-0.5 rounded-full font-bold">
                Tahun Berjalan 2026
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center justify-items-center">
              {/* Gauge 1: Rasio Didanai (Default 80% / Dynamic) */}
              <div className="flex flex-col items-center text-center group cursor-pointer transition-transform duration-300 hover:scale-105">
                <div className="relative w-36 h-36 flex items-center justify-center">
                  {/* Outer glowing orbital arc */}
                  <svg className="w-full h-full -rotate-90 transform overflow-visible" viewBox="0 0 120 120">
                    <circle
                      cx="60"
                      cy="60"
                      r="50"
                      stroke="#e0f2fe"
                      strokeWidth="5"
                      fill="none"
                      className="opacity-60"
                    />
                    <circle
                      cx="60"
                      cy="60"
                      r="50"
                      stroke="url(#cyanGaugeGrad)"
                      strokeWidth="6"
                      strokeDasharray="314"
                      strokeDashoffset={314 - (314 * Math.min(Number(totals.fundingRate), 100)) / 100}
                      strokeLinecap="round"
                      fill="none"
                      className="transition-all duration-700 drop-shadow-[0_0_8px_rgba(6,182,212,0.6)]"
                    />
                    <defs>
                      <linearGradient id="cyanGaugeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#22d3ee" />
                        <stop offset="50%" stopColor="#0284c7" />
                        <stop offset="100%" stopColor="#0369a1" />
                      </linearGradient>
                    </defs>
                  </svg>

                  {/* Concentric 3D Radial Sphere Disc */}
                  <div className="absolute inset-3 rounded-full bg-gradient-to-br from-cyan-400 via-sky-600 to-blue-800 shadow-[inset_0_4px_8px_rgba(255,255,255,0.4),0_8px_20px_rgba(2,132,199,0.35)] flex flex-col items-center justify-center border-2 border-white/40">
                    <span className="text-2xl font-black text-white font-mono tracking-tight drop-shadow-sm">
                      {totals.fundingRate}%
                    </span>
                    <span className="text-[9px] uppercase font-bold text-cyan-100 tracking-wider">
                      Rasio Lolos
                    </span>
                  </div>
                </div>
                <div className="mt-3">
                  <h4 className="text-xs font-black uppercase text-slate-900 tracking-wide">
                    Kelolosan Usulan
                  </h4>
                  <p className="text-[11px] text-slate-500 font-medium">
                    {totals.totalDidanai} dari {totals.totalUsulan} proposal didanai
                  </p>
                </div>
              </div>

              {/* Gauge 2: Capaian Monev & SPTB (50% / Dynamic) */}
              <div className="flex flex-col items-center text-center group cursor-pointer transition-transform duration-300 hover:scale-105">
                <div className="relative w-36 h-36 flex items-center justify-center">
                  <svg className="w-full h-full -rotate-90 transform overflow-visible" viewBox="0 0 120 120">
                    <circle
                      cx="60"
                      cy="60"
                      r="50"
                      stroke="#e0f2fe"
                      strokeWidth="5"
                      fill="none"
                      className="opacity-60"
                    />
                    <circle
                      cx="60"
                      cy="60"
                      r="50"
                      stroke="url(#cyanGaugeGrad2)"
                      strokeWidth="6"
                      strokeDasharray="314"
                      strokeDashoffset={314 - (314 * 72) / 100}
                      strokeLinecap="round"
                      fill="none"
                      className="transition-all duration-700 drop-shadow-[0_0_8px_rgba(56,189,248,0.6)]"
                    />
                    <defs>
                      <linearGradient id="cyanGaugeGrad2" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#38bdf8" />
                        <stop offset="100%" stopColor="#2563eb" />
                      </linearGradient>
                    </defs>
                  </svg>

                  <div className="absolute inset-3 rounded-full bg-gradient-to-br from-sky-400 via-blue-600 to-indigo-800 shadow-[inset_0_4px_8px_rgba(255,255,255,0.4),0_8px_20px_rgba(37,99,235,0.35)] flex flex-col items-center justify-center border-2 border-white/40">
                    <span className="text-2xl font-black text-white font-mono tracking-tight drop-shadow-sm">
                      72%
                    </span>
                    <span className="text-[9px] uppercase font-bold text-sky-100 tracking-wider">
                      Monev 70%
                    </span>
                  </div>
                </div>
                <div className="mt-3">
                  <h4 className="text-xs font-black uppercase text-slate-900 tracking-wide">
                    Kemajuan Riset
                  </h4>
                  <p className="text-[11px] text-slate-500 font-medium">
                    Laporan Antara & SPTB 70% diverifikasi
                  </p>
                </div>
              </div>

              {/* Gauge 3: Serapan Anggaran & BASTB (60% / Dynamic) */}
              <div className="flex flex-col items-center text-center group cursor-pointer transition-transform duration-300 hover:scale-105">
                <div className="relative w-36 h-36 flex items-center justify-center">
                  <svg className="w-full h-full -rotate-90 transform overflow-visible" viewBox="0 0 120 120">
                    <circle
                      cx="60"
                      cy="60"
                      r="50"
                      stroke="#e0f2fe"
                      strokeWidth="5"
                      fill="none"
                      className="opacity-60"
                    />
                    <circle
                      cx="60"
                      cy="60"
                      r="50"
                      stroke="url(#cyanGaugeGrad3)"
                      strokeWidth="6"
                      strokeDasharray="314"
                      strokeDashoffset={314 - (314 * 85) / 100}
                      strokeLinecap="round"
                      fill="none"
                      className="transition-all duration-700 drop-shadow-[0_0_8px_rgba(14,165,233,0.6)]"
                    />
                    <defs>
                      <linearGradient id="cyanGaugeGrad3" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#06b6d4" />
                        <stop offset="100%" stopColor="#1d4ed8" />
                      </linearGradient>
                    </defs>
                  </svg>

                  <div className="absolute inset-3 rounded-full bg-gradient-to-br from-cyan-400 via-sky-600 to-blue-900 shadow-[inset_0_4px_8px_rgba(255,255,255,0.4),0_8px_20px_rgba(14,165,233,0.35)] flex flex-col items-center justify-center border-2 border-white/40">
                    <span className="text-2xl font-black text-white font-mono tracking-tight drop-shadow-sm">
                      85%
                    </span>
                    <span className="text-[9px] uppercase font-bold text-cyan-100 tracking-wider">
                      Realisasi
                    </span>
                  </div>
                </div>
                <div className="mt-3">
                  <h4 className="text-xs font-black uppercase text-slate-900 tracking-wide">
                    Penyaluran Hibah
                  </h4>
                  <p className="text-[11px] text-slate-500 font-medium">
                    Rp {totals.totalDanaMilyar} M dana terserap
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* SECTION B: 4 Hexagonal Top Capsule Step Cards (from Middle Row of Uploaded Image) */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
            {/* Card 01 */}
            <div className="relative group pt-4">
              {/* Hexagonal Top Badge */}
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 z-10 w-12 h-10 flex items-center justify-center drop-shadow-md">
                <svg viewBox="0 0 48 42" className="w-full h-full fill-cyan-500 stroke-white stroke-[2.5]">
                  <polygon points="24,2 44,11 44,31 24,40 4,31 4,11" />
                </svg>
                <span className="absolute text-white font-mono font-black text-xs">01</span>
              </div>
              {/* Capsule Body */}
              <div className="bg-gradient-to-b from-cyan-500 via-sky-600 to-blue-700 text-white rounded-b-3xl rounded-t-xl pt-7 pb-4 px-3 text-center shadow-md transition-all duration-300 group-hover:-translate-y-1 group-hover:shadow-lg border border-cyan-300/40">
                <h5 className="text-[11px] font-black uppercase tracking-wider text-cyan-100">
                  Tahap Pengajuan
                </h5>
                <div className="text-xl font-black font-mono mt-1 text-white tabular-nums">
                  {totals.totalUsulan} <span className="text-xs font-normal text-cyan-200">Judul</span>
                </div>
                <p className="text-[10px] text-white/85 mt-1 line-clamp-2 leading-tight">
                  Proposal baru masuk & surat bebas plagiat
                </p>
              </div>
            </div>

            {/* Card 02 */}
            <div className="relative group pt-4">
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 z-10 w-12 h-10 flex items-center justify-center drop-shadow-md">
                <svg viewBox="0 0 48 42" className="w-full h-full fill-cyan-500 stroke-white stroke-[2.5]">
                  <polygon points="24,2 44,11 44,31 24,40 4,31 4,11" />
                </svg>
                <span className="absolute text-white font-mono font-black text-xs">02</span>
              </div>
              <div className="bg-gradient-to-b from-cyan-500 via-sky-600 to-blue-700 text-white rounded-b-3xl rounded-t-xl pt-7 pb-4 px-3 text-center shadow-md transition-all duration-300 group-hover:-translate-y-1 group-hover:shadow-lg border border-cyan-300/40">
                <h5 className="text-[11px] font-black uppercase tracking-wider text-cyan-100">
                  Desk Review
                </h5>
                <div className="text-xl font-black font-mono mt-1 text-white tabular-nums">
                  {Math.round(totals.totalUsulan * 0.88)} <span className="text-xs font-normal text-cyan-200">Lolos</span>
                </div>
                <p className="text-[10px] text-white/85 mt-1 line-clamp-2 leading-tight">
                  Penilaian reviewer & telaah etik riset
                </p>
              </div>
            </div>

            {/* Card 03 */}
            <div className="relative group pt-4">
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 z-10 w-12 h-10 flex items-center justify-center drop-shadow-md">
                <svg viewBox="0 0 48 42" className="w-full h-full fill-cyan-500 stroke-white stroke-[2.5]">
                  <polygon points="24,2 44,11 44,31 24,40 4,31 4,11" />
                </svg>
                <span className="absolute text-white font-mono font-black text-xs">03</span>
              </div>
              <div className="bg-gradient-to-b from-cyan-500 via-sky-600 to-blue-700 text-white rounded-b-3xl rounded-t-xl pt-7 pb-4 px-3 text-center shadow-md transition-all duration-300 group-hover:-translate-y-1 group-hover:shadow-lg border border-cyan-300/40">
                <h5 className="text-[11px] font-black uppercase tracking-wider text-cyan-100">
                  Kontrak Didanai
                </h5>
                <div className="text-xl font-black font-mono mt-1 text-white tabular-nums">
                  {totals.totalDidanai} <span className="text-xs font-normal text-cyan-200">SK</span>
                </div>
                <p className="text-[10px] text-white/85 mt-1 line-clamp-2 leading-tight">
                  Surat tugas, SPK bermaterai & termin dana
                </p>
              </div>
            </div>

            {/* Card 04 */}
            <div className="relative group pt-4">
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 z-10 w-12 h-10 flex items-center justify-center drop-shadow-md">
                <svg viewBox="0 0 48 42" className="w-full h-full fill-cyan-500 stroke-white stroke-[2.5]">
                  <polygon points="24,2 44,11 44,31 24,40 4,31 4,11" />
                </svg>
                <span className="absolute text-white font-mono font-black text-xs">04</span>
              </div>
              <div className="bg-gradient-to-b from-cyan-500 via-sky-600 to-blue-700 text-white rounded-b-3xl rounded-t-xl pt-7 pb-4 px-3 text-center shadow-md transition-all duration-300 group-hover:-translate-y-1 group-hover:shadow-lg border border-cyan-300/40">
                <h5 className="text-[11px] font-black uppercase tracking-wider text-cyan-100">
                  Monev & Luaran
                </h5>
                <div className="text-xl font-black font-mono mt-1 text-white tabular-nums">
                  {activeItem.didanai} <span className="text-xs font-normal text-cyan-200">BASTB</span>
                </div>
                <p className="text-[10px] text-white/85 mt-1 line-clamp-2 leading-tight">
                  Laporan akhir, SPTB 100% & artikel Sinta
                </p>
              </div>
            </div>
          </div>

          {/* SECTION C: Modern Charts Row (from Bottom Row of Uploaded Image) */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 pt-2">
            
            {/* LEFT CHART: Modern Capsule Bar Chart with Embedded Bead Rings */}
            {(viewMode === 'modern_both' || viewMode === 'bar') && (
              <div className="bg-slate-50/80 border border-slate-200/90 rounded-2xl p-4 shadow-xs flex flex-col justify-between">
                <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-cyan-500 ring-2 ring-cyan-200"></span>
                    <h4 className="text-xs font-black uppercase text-slate-900 tracking-wide">
                      Grafik Kapsul Usulan & Didanai
                    </h4>
                  </div>
                  <div className="flex items-center gap-3 text-[11px]">
                    <span className="flex items-center gap-1 font-bold text-cyan-700">
                      <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span> Usulan
                    </span>
                    <span className="flex items-center gap-1 font-bold text-blue-700">
                      <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span> Didanai
                    </span>
                  </div>
                </div>

                {/* SVG Capsule Bar Chart */}
                <div className="py-2">
                  <svg className="w-full h-56 overflow-visible" viewBox="0 0 340 180">
                    <defs>
                      {/* Cyan-to-blue gradient for Usulan capsule */}
                      <linearGradient id="capsuleGradUsulan" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#22d3ee" />
                        <stop offset="40%" stopColor="#06b6d4" />
                        <stop offset="100%" stopColor="#0284c7" />
                      </linearGradient>

                      {/* Deeper blue gradient for Didanai capsule */}
                      <linearGradient id="capsuleGradDidanai" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#38bdf8" />
                        <stop offset="50%" stopColor="#2563eb" />
                        <stop offset="100%" stopColor="#1e40af" />
                      </linearGradient>

                      {/* Drop shadow filter */}
                      <filter id="capsuleGlow" x="-20%" y="-20%" width="140%" height="140%">
                        <feDropShadow dx="0" dy="2" stdDeviation="2" floodColor="#0284c7" floodOpacity="0.25" />
                      </filter>
                    </defs>

                    {/* Horizontal crisp grid lines with ticks */}
                    {[20, 55, 90, 125, 155].map((y, idx) => (
                      <g key={idx}>
                        <line x1="30" y1={y} x2="330" y2={y} stroke="#e2e8f0" strokeWidth="0.8" />
                        <text x="22" y={y + 3} textAnchor="end" fontSize="8" fill="#94a3b8" fontFamily="monospace">
                          {idx === 0 ? '60' : idx === 1 ? '45' : idx === 2 ? '30' : idx === 3 ? '15' : '0'}
                        </text>
                      </g>
                    ))}

                    {/* Render Capsule Bars */}
                    {processedData.map((d, i) => {
                      const isHovered = activeChartHover === i;
                      const colWidth = 44;
                      const startX = 40 + i * colWidth;
                      const barWidth = 14;

                      // Heights (max height ~130px)
                      const maxVal = 65;
                      const hUsulan = Math.max((d.usulan / maxVal) * 125, 20);
                      const yUsulan = 155 - hUsulan;

                      const hDidanai = Math.max((d.didanai / maxVal) * 125, 16);
                      const yDidanai = 155 - hDidanai;

                      return (
                        <g 
                          key={d.year} 
                          className="cursor-pointer transition-all duration-300"
                          onMouseEnter={() => setActiveChartHover(i)}
                          onClick={() => setActiveChartHover(i)}
                        >
                          {/* Hover background column indicator */}
                          {isHovered && (
                            <rect
                              x={startX - 3}
                              y="12"
                              width={barWidth * 2 + 10}
                              height="146"
                              rx="8"
                              fill="#f0f9ff"
                              stroke="#bae6fd"
                              strokeWidth="1"
                            />
                          )}

                          {/* 1. Bar Usulan (Pill Capsule) */}
                          <rect
                            x={startX}
                            y={yUsulan}
                            width={barWidth}
                            height={hUsulan}
                            rx={barWidth / 2}
                            fill="url(#capsuleGradUsulan)"
                            filter="url(#capsuleGlow)"
                            className={`transition-all duration-300 ${isHovered ? 'brightness-110' : 'hover:brightness-105'}`}
                          />
                          {/* Iconic bead ring inside top of capsule */}
                          <circle
                            cx={startX + barWidth / 2}
                            cy={yUsulan + barWidth / 2 + 1}
                            r={barWidth / 2 - 2.5}
                            fill="#0891b2"
                            stroke="#ffffff"
                            strokeWidth="1.2"
                          />
                          <circle
                            cx={startX + barWidth / 2}
                            cy={yUsulan + barWidth / 2 + 1}
                            r="1.8"
                            fill="#ffffff"
                          />

                          {/* 2. Bar Didanai (Pill Capsule) */}
                          <rect
                            x={startX + barWidth + 4}
                            y={yDidanai}
                            width={barWidth}
                            height={hDidanai}
                            rx={barWidth / 2}
                            fill="url(#capsuleGradDidanai)"
                            filter="url(#capsuleGlow)"
                            className={`transition-all duration-300 ${isHovered ? 'brightness-110' : 'hover:brightness-105'}`}
                          />
                          {/* Iconic bead ring inside top of capsule */}
                          <circle
                            cx={startX + barWidth + 4 + barWidth / 2}
                            cy={yDidanai + barWidth / 2 + 1}
                            r={barWidth / 2 - 2.5}
                            fill="#1d4ed8"
                            stroke="#ffffff"
                            strokeWidth="1.2"
                          />
                          <circle
                            cx={startX + barWidth + 4 + barWidth / 2}
                            cy={yDidanai + barWidth / 2 + 1}
                            r="1.8"
                            fill="#ffffff"
                          />

                          {/* X-axis Label */}
                          <text
                            x={startX + barWidth + 2}
                            y="172"
                            textAnchor="middle"
                            fontSize="9"
                            fontFamily="monospace"
                            fontWeight={isHovered ? '900' : '600'}
                            fill={isHovered ? '#0369a1' : '#64748b'}
                          >
                            {d.year}
                          </text>

                          {/* Rate badge on top if hovered */}
                          {isHovered && (
                            <text
                              x={startX + barWidth + 2}
                              y={Math.min(yUsulan, yDidanai) - 4}
                              textAnchor="middle"
                              fontSize="8"
                              fontWeight="bold"
                              fontFamily="monospace"
                              fill="#0284c7"
                            >
                              {d.rate}%
                            </text>
                          )}
                        </g>
                      );
                    })}
                  </svg>
                </div>
                
                <p className="text-[10px] text-slate-500 text-center font-medium">
                  Setiap kolom menampilkan kapsul Usulan (cyan) dan Didanai (royal blue) dengan indikator simpul bead di puncak kapsul.
                </p>
              </div>
            )}

            {/* RIGHT CHART: Modern Mountain / Wave Area Spline Chart with Peak Nodes */}
            {(viewMode === 'modern_both' || viewMode === 'trend') && (
              <div className="bg-slate-50/80 border border-slate-200/90 rounded-2xl p-4 shadow-xs flex flex-col justify-between">
                <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-600 ring-2 ring-blue-200"></span>
                    <h4 className="text-xs font-black uppercase text-slate-900 tracking-wide">
                      Grafik Kurva Gelombang Mountain (Spline)
                    </h4>
                  </div>
                  <span className="text-[10px] font-mono font-bold text-slate-500 bg-white px-2 py-0.5 rounded border border-slate-200">
                    Akumulasi: {totals.fundingRate}% Lolos
                  </span>
                </div>

                {/* SVG Mountain Spline Chart */}
                <div className="py-2">
                  <svg className="w-full h-56 overflow-visible" viewBox="0 0 340 180">
                    <defs>
                      {/* Cyan-to-white mountain wave fill gradient */}
                      <linearGradient id="mountainAreaGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.55" />
                        <stop offset="50%" stopColor="#38bdf8" stopOpacity="0.25" />
                        <stop offset="100%" stopColor="#ffffff" stopOpacity="0.0" />
                      </linearGradient>

                      <linearGradient id="mountainAreaDidanaiGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#2563eb" stopOpacity="0.45" />
                        <stop offset="100%" stopColor="#ffffff" stopOpacity="0.0" />
                      </linearGradient>
                    </defs>

                    {/* Horizontal Guideline Grid like in uploaded image */}
                    {[20, 55, 90, 125, 155].map((y, idx) => (
                      <line 
                        key={idx} 
                        x1="20" 
                        y1={y} 
                        x2="330" 
                        y2={y} 
                        stroke="#e2e8f0" 
                        strokeWidth="0.8" 
                      />
                    ))}

                    {/* Coordinates calculation for mountain path */}
                    {(() => {
                      const count = processedData.length;
                      const maxVal = 65;

                      const usulanPts = processedData.map((d, i) => {
                        const x = 30 + (i / (count - 1)) * 290;
                        const y = 155 - (d.usulan / maxVal) * 130;
                        return { x, y, val: d.usulan, year: d.year, rate: d.rate };
                      });

                      const didanaiPts = processedData.map((d, i) => {
                        const x = 30 + (i / (count - 1)) * 290;
                        const y = 155 - (d.didanai / maxVal) * 130;
                        return { x, y, val: d.didanai, year: d.year };
                      });

                      // Mountain Path String (smooth spline / polygon)
                      const uPath = usulanPts.reduce((acc, curr, idx) => 
                        idx === 0 ? `M ${curr.x} ${curr.y}` : `${acc} L ${curr.x} ${curr.y}`, ''
                      );
                      const uArea = `${uPath} L ${usulanPts[usulanPts.length - 1].x} 155 L ${usulanPts[0].x} 155 Z`;

                      const dPath = didanaiPts.reduce((acc, curr, idx) => 
                        idx === 0 ? `M ${curr.x} ${curr.y}` : `${acc} L ${curr.x} ${curr.y}`, ''
                      );
                      const dArea = `${dPath} L ${didanaiPts[didanaiPts.length - 1].x} 155 L ${didanaiPts[0].x} 155 Z`;

                      return (
                        <>
                          {/* Mountain Area Fills */}
                          <path d={uArea} fill="url(#mountainAreaGrad)" />
                          <path d={dArea} fill="url(#mountainAreaDidanaiGrad)" />

                          {/* Line Strokes */}
                          <path 
                            d={uPath} 
                            fill="none" 
                            stroke="#06b6d4" 
                            strokeWidth="3" 
                            strokeLinecap="round" 
                            strokeLinejoin="round" 
                          />
                          <path 
                            d={dPath} 
                            fill="none" 
                            stroke="#2563eb" 
                            strokeWidth="2.5" 
                            strokeLinecap="round" 
                            strokeLinejoin="round" 
                            strokeDasharray="4 2"
                          />

                          {/* Data Peak Nodes (Solid blue nodes with white/cyan halo borders) */}
                          {usulanPts.map((pt, i) => {
                            const isHovered = activeChartHover === i;
                            return (
                              <g 
                                key={`m-u-${i}`}
                                className="cursor-pointer"
                                onMouseEnter={() => setActiveChartHover(i)}
                                onClick={() => setActiveChartHover(i)}
                              >
                                {isHovered && (
                                  <line
                                    x1={pt.x}
                                    y1={pt.y}
                                    x2={pt.x}
                                    y2="155"
                                    stroke="#0284c7"
                                    strokeWidth="1"
                                    strokeDasharray="2 2"
                                  />
                                )}
                                <circle 
                                  cx={pt.x} 
                                  cy={pt.y} 
                                  r={isHovered ? 7 : 5} 
                                  fill="#0284c7" 
                                  stroke="#ffffff" 
                                  strokeWidth="2.5"
                                  className="transition-all duration-200 drop-shadow-sm"
                                />
                                <text
                                  x={pt.x}
                                  y="172"
                                  textAnchor="middle"
                                  fontSize="9"
                                  fontFamily="monospace"
                                  fontWeight={isHovered ? '900' : '600'}
                                  fill={isHovered ? '#0369a1' : '#64748b'}
                                >
                                  {pt.year}
                                </text>
                              </g>
                            );
                          })}

                          {didanaiPts.map((pt, i) => {
                            const isHovered = activeChartHover === i;
                            return (
                              <g 
                                key={`m-d-${i}`}
                                className="cursor-pointer"
                                onMouseEnter={() => setActiveChartHover(i)}
                                onClick={() => setActiveChartHover(i)}
                              >
                                <circle 
                                  cx={pt.x} 
                                  cy={pt.y} 
                                  r={isHovered ? 6 : 4} 
                                  fill="#2563eb" 
                                  stroke="#ffffff" 
                                  strokeWidth="2"
                                  className="transition-all duration-200"
                                />
                              </g>
                            );
                          })}
                        </>
                      );
                    })()}
                  </svg>
                </div>

                <p className="text-[10px] text-slate-500 text-center font-medium">
                  Kurva Mountain Wave menampilkan lintasan pertumbuhan proposal dengan simpul puncak data interaktif.
                </p>
              </div>
            )}
          </div>

          {/* Interactive Inspection Card for Selected / Hovered Year */}
          <div className="p-4 bg-gradient-to-r from-sky-50 via-slate-50 to-indigo-50 border border-sky-100 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs shadow-xs">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-700 text-white flex flex-col items-center justify-center font-mono font-bold leading-none shrink-0 shadow-sm border border-white/40">
                <span className="text-[9px] uppercase tracking-wider text-cyan-200">TAHUN</span>
                <span className="text-base font-black">{activeItem.year}</span>
              </div>
              <div>
                <div className="font-extrabold text-slate-900 flex items-center gap-2">
                  <span>Rincian Volume Usulan & Pendanaan {activeItem.year}</span>
                  <span className="text-[10px] font-bold text-cyan-800 bg-cyan-100 px-2.5 py-0.5 rounded-full border border-cyan-200">
                    Tingkat Kelolosan: {activeItem.rate}%
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                  <span>Status: <strong className="text-slate-800">{activeItem.catatan}</strong></span>
                </div>
              </div>
            </div>

            {/* Quick Metrics of Active Year */}
            <div className="flex items-center gap-2.5 self-end md:self-auto font-mono">
              <div className="px-3 py-1.5 bg-white border border-slate-200/80 rounded-lg text-right shadow-xs">
                <div className="text-[9px] text-slate-500 uppercase font-sans font-bold">Usulan Masuk</div>
                <div className="font-black text-cyan-700 text-sm tabular-nums">{activeItem.usulan} Proposal</div>
              </div>
              <div className="px-3 py-1.5 bg-white border border-slate-200/80 rounded-lg text-right shadow-xs">
                <div className="text-[9px] text-slate-500 uppercase font-sans font-bold">Didanai LPPM</div>
                <div className="font-black text-blue-700 text-sm tabular-nums">{activeItem.didanai} Proposal</div>
              </div>
              <div className="px-3 py-1.5 bg-white border border-slate-200/80 rounded-lg text-right shadow-xs">
                <div className="text-[9px] text-slate-500 uppercase font-sans font-bold">Total Dana</div>
                <div className="font-black text-slate-900 text-sm tabular-nums">Rp {activeItem.danaTotalJuta} Jt</div>
              </div>
            </div>
          </div>

          {/* Drilldown Toggle: Expandable Full Table Breakdown */}
          <div className="pt-1">
            <button
              type="button"
              onClick={() => setShowTableDetail(!showTableDetail)}
              className="text-xs font-bold text-cyan-700 hover:text-cyan-900 flex items-center gap-1.5 cursor-pointer py-1"
            >
              <span>{showTableDetail ? 'Sembunyikan' : 'Tampilkan'} Tabel Lengkap Rekapitulasi Usulan & Dana per Tahun</span>
              {showTableDetail ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>

            {showTableDetail && (
              <div className="mt-3 overflow-x-auto border border-slate-200 rounded-xl shadow-xs">
                <table className="w-full text-left text-xs text-slate-700">
                  <thead className="bg-slate-100 text-[11px] font-bold text-slate-800 uppercase tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3">Tahun Akademik</th>
                      <th className="py-2.5 px-3 text-right">Usulan (Diunggah)</th>
                      <th className="py-2.5 px-3 text-right">Didanai LPPM</th>
                      <th className="py-2.5 px-3 text-right">Tidak Didanai</th>
                      <th className="py-2.5 px-3 text-right">Tingkat Lolos (%)</th>
                      <th className="py-2.5 px-3 text-right">Penyaluran Dana</th>
                      <th className="py-2.5 px-3">Catatan Administrasi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
                    {processedData.map((row) => (
                      <tr 
                        key={row.year} 
                        className={`hover:bg-cyan-50/40 transition-colors ${
                          activeItem.year === row.year ? 'bg-cyan-50/70 font-semibold' : ''
                        }`}
                      >
                        <td className="py-2.5 px-3 font-bold text-slate-900 font-sans">
                          Tahun {row.year}
                        </td>
                        <td className="py-2.5 px-3 text-right text-cyan-700 font-bold">
                          {row.usulan}
                        </td>
                        <td className="py-2.5 px-3 text-right text-blue-700 font-bold">
                          {row.didanai}
                        </td>
                        <td className="py-2.5 px-3 text-right text-slate-400">
                          {row.tidakDidanai}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-slate-800">
                          {row.rate}%
                        </td>
                        <td className="py-2.5 px-3 text-right text-slate-700 font-sans">
                          Rp {row.danaTotalJuta} Juta
                        </td>
                        <td className="py-2.5 px-3 font-sans text-[11px] text-slate-500">
                          {row.catatan}
                        </td>
                      </tr>
                    ))}
                    {/* Summary row */}
                    <tr className="bg-slate-100/90 font-bold text-slate-900 border-t-2 border-slate-300">
                      <td className="py-2.5 px-3 font-sans">Total Akumulasi</td>
                      <td className="py-2.5 px-3 text-right text-cyan-900">{totals.totalUsulan}</td>
                      <td className="py-2.5 px-3 text-right text-blue-900">{totals.totalDidanai}</td>
                      <td className="py-2.5 px-3 text-right text-slate-500">{totals.totalTidakDidanai}</td>
                      <td className="py-2.5 px-3 text-right">{totals.fundingRate}%</td>
                      <td className="py-2.5 px-3 text-right font-sans">Rp {totals.totalDanaMilyar} M</td>
                      <td className="py-2.5 px-3 font-sans text-[11px] text-slate-600">Terverifikasi SIM LPPM ITSNU</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 4. LPPM ADMIN MODAL: KELOLA PENGUMUMAN, JADWAL & BERITA */}
      {isManageModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-cyan-600 via-sky-600 to-blue-700 text-white p-4.5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center text-white">
                  <Megaphone className="w-4 h-4 text-cyan-200" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold uppercase tracking-wide">
                    Kelola Pengumuman, Jadwal & Berita LPPM
                  </h3>
                  <p className="text-[11px] text-cyan-100">
                    Kelola pesan sambutan, batas waktu kegiatan, dan pengumuman resmi dosen
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsManageModalOpen(false);
                  setEditingBulletin(null);
                }}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center cursor-pointer transition-all"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 space-y-5 max-h-[75vh] overflow-y-auto">
              {/* Form Input Section */}
              <form onSubmit={handleSaveBulletin} className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black uppercase text-slate-800 flex items-center gap-1.5">
                    {editingBulletin ? <Edit3 className="w-3.5 h-3.5 text-cyan-600" /> : <Plus className="w-3.5 h-3.5 text-cyan-600" />}
                    {editingBulletin ? 'Edit Informasi Terpilih' : 'Tambah Pengumuman / Jadwal Baru'}
                  </span>
                  {editingBulletin && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditingBulletin(null);
                        setFormTitle('');
                        setFormContent('');
                        setFormDate('Juni 2026');
                        setFormImportant(false);
                      }}
                      className="text-[11px] text-slate-500 hover:text-slate-800 underline cursor-pointer"
                    >
                      Batal Edit
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Category Type */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                      Kategori
                    </label>
                    <select
                      value={formType}
                      onChange={(e) => setFormType(e.target.value as any)}
                      className="w-full text-xs bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 font-medium focus:ring-2 focus:ring-cyan-500 focus:outline-hidden"
                    >
                      <option value="pengumuman">📢 Pengumuman Penting</option>
                      <option value="jadwal">📅 Jadwal Kegiatan</option>
                      <option value="berita">📰 Berita Terkini</option>
                      <option value="salam">👋 Salam & Motivasi</option>
                    </select>
                  </div>

                  {/* Title */}
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                      Judul / Topik Ringkas
                    </label>
                    <input
                      type="text"
                      placeholder="Contoh: Batas Akhir Unggah SPTB 70%"
                      value={formTitle}
                      onChange={(e) => setFormTitle(e.target.value)}
                      className="w-full text-xs bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 font-medium focus:ring-2 focus:ring-cyan-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                {/* Content Message */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                    Isi Pesan / Pengumuman / Jadwal Lengkap *
                  </label>
                  <textarea
                    rows={2}
                    required
                    placeholder="Tuliskan isi informasi yang akan tampil pada banner selamat datang..."
                    value={formContent}
                    onChange={(e) => setFormContent(e.target.value)}
                    className="w-full text-xs bg-white border border-slate-300 rounded-lg p-2.5 font-medium focus:ring-2 focus:ring-cyan-500 focus:outline-hidden"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
                  {/* Date / Deadline */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                      Tanggal / Periode Kegiatan
                    </label>
                    <input
                      type="text"
                      placeholder="Contoh: 15 Juli 2026 atau Semester Genap"
                      value={formDate}
                      onChange={(e) => setFormDate(e.target.value)}
                      className="w-full text-xs bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 font-medium focus:ring-2 focus:ring-cyan-500 focus:outline-hidden"
                    />
                  </div>

                  <div className="flex items-center gap-2 pt-4">
                    <input
                      type="checkbox"
                      id="important-check"
                      checked={formImportant}
                      onChange={(e) => setFormImportant(e.target.checked)}
                      className="w-4 h-4 text-cyan-600 rounded border-slate-300 focus:ring-cyan-500 cursor-pointer"
                    />
                    <label htmlFor="important-check" className="text-xs font-bold text-slate-700 cursor-pointer select-none">
                      Tandai sebagai Prioritas Utama
                    </label>
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="submit"
                    className="px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-700 hover:from-cyan-700 hover:to-blue-800 text-white rounded-lg text-xs font-bold shadow-sm transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>{editingBulletin ? 'Perbarui Pengumuman' : 'Simpan & Publikasikan ke Banner'}</span>
                  </button>
                </div>
              </form>

              {/* Existing List Section */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black uppercase text-slate-800">
                      Daftar Pengumuman & Jadwal Aktif ({bulletins.length})
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsAutoRotate(!isAutoRotate)}
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border transition-all cursor-pointer ${
                        isAutoRotate
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                          : 'bg-slate-100 text-slate-600 border-slate-300'
                      }`}
                    >
                      {isAutoRotate ? '▶ Auto-Rotate Aktif (6s)' : '⏸ Auto-Rotate Mati'}
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={handleResetBulletins}
                    className="text-[11px] text-cyan-700 hover:text-cyan-900 font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Reset Bawaan</span>
                  </button>
                </div>

                <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
                  {bulletins.map((b, idx) => {
                    const isSelected = activeBulletinIndex === idx;

                    return (
                      <div
                        key={b.id}
                        className={`p-3.5 flex items-start justify-between gap-3 transition-colors ${
                          isSelected ? 'bg-cyan-50/60' : 'hover:bg-slate-50'
                        }`}
                      >
                        <div className="space-y-1 min-w-0 pr-2">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-slate-200 text-slate-800">
                              {b.badge}
                            </span>
                            <span className="text-xs font-bold text-slate-900">
                              {b.title}
                            </span>
                            <span className="text-[10px] text-slate-500 font-mono">
                              ({b.date})
                            </span>
                            {isSelected && (
                              <span className="text-[9px] font-black uppercase px-1.5 py-0.2 bg-cyan-600 text-white rounded">
                                Tampil Sekarang
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-600 leading-snug">
                            {b.content}
                          </p>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-1 shrink-0 pt-0.5">
                          <button
                            type="button"
                            onClick={() => setActiveBulletinIndex(idx)}
                            title="Tampilkan di Banner Sekarang"
                            className={`px-2 py-1 rounded text-[11px] font-bold cursor-pointer transition-all ${
                              isSelected
                                ? 'bg-cyan-600 text-white'
                                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                            }`}
                          >
                            Pilih
                          </button>
                          <button
                            type="button"
                            onClick={() => handleStartEdit(b)}
                            title="Edit"
                            className="p-1 rounded text-slate-500 hover:text-cyan-700 hover:bg-cyan-50 cursor-pointer transition-all"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteBulletin(b.id)}
                            title="Hapus"
                            className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer transition-all"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="bg-slate-50 border-t border-slate-200 p-3.5 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsManageModalOpen(false);
                  setEditingBulletin(null);
                }}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg text-xs font-bold cursor-pointer transition-all"
              >
                Tutup Pengaturan
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
