import React, { useState, useMemo } from 'react';
import { ThemePreset, CustomControls } from '../types';
import { 
  Search, 
  Info, 
  Eye, 
  MessageSquare, 
  Filter, 
  Plus, 
  Download, 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  FileText, 
  DollarSign, 
  Wallet, 
  ArrowUpRight, 
  Trash2, 
  X,
  FileSpreadsheet,
  Receipt
} from 'lucide-react';

interface TableViewProps {
  preset: ThemePreset;
  controls: CustomControls;
}

interface ExpenseRecord {
  id: string;
  tanggal: string;
  kategori: 'Bahan Habis Pakai & ATK' | 'Operasional Lapangan & SPPD' | 'Honorarium' | 'Publikasi & HKI' | 'Konsumsi & FGD';
  uraian: string;
  volume: string;
  nominal: number;
  noBukti: string;
  status: 'Terverifikasi' | 'Dalam Pemeriksaan' | 'Draf';
  lampiran: string;
}

const initialExpenses: ExpenseRecord[] = [
  {
    id: 'EXP-001',
    tanggal: '18 Mei 2026',
    kategori: 'Honorarium',
    uraian: 'Honor tim pembantu peneliti lapangan & enumerator data kuesioner UMKM',
    volume: '2 Orang x 2 Bulan',
    nominal: 3500000,
    noBukti: 'KW-01/ITSNU/V/2026',
    status: 'Terverifikasi',
    lampiran: 'Kuitansi_Honor_Peneliti.pdf'
  },
  {
    id: 'EXP-002',
    tanggal: '27 Mei 2026',
    kategori: 'Bahan Habis Pakai & ATK',
    uraian: 'Pengadaan komponen sensor IoT ESP32, casing panel tahan air, dan kit instalasi prototipe',
    volume: '5 Paket',
    nominal: 4800000,
    noBukti: 'NT-8821/ELEK/V/2026',
    status: 'Terverifikasi',
    lampiran: 'Nota_Komponen_Sensor_IoT.pdf'
  },
  {
    id: 'EXP-003',
    tanggal: '05 Juni 2026',
    kategori: 'Operasional Lapangan & SPPD',
    uraian: 'BBM & biaya transportasi dinas survei lapangan mitra BumDes Pekalongan Selatan',
    volume: '3 Perjalanan',
    nominal: 2650000,
    noBukti: 'SPPD-04/LPPM/VI/2026',
    status: 'Terverifikasi',
    lampiran: 'Form_SPPD_Karcis_Tol.pdf'
  },
  {
    id: 'EXP-004',
    tanggal: '14 Juni 2026',
    kategori: 'Bahan Habis Pakai & ATK',
    uraian: 'Pembelian kertas HVS 80gr, toner printer laserjet, dan jilid draf laporan kemajuan',
    volume: '1 Paket ATK',
    nominal: 1350000,
    noBukti: 'KW-09/TB-GRAHA/VI/2026',
    status: 'Terverifikasi',
    lampiran: 'Kuitansi_ATK_Pelaporan.pdf'
  },
  {
    id: 'EXP-005',
    tanggal: '02 Juli 2026',
    kategori: 'Publikasi & HKI',
    uraian: 'Biaya PNBP permohonan pencatatan Hak Cipta program komputer di DJKI Kemenkumham',
    volume: '1 Sertifikat HKI',
    nominal: 600000,
    noBukti: 'BILL-SIMPONI-029831',
    status: 'Terverifikasi',
    lampiran: 'Bukti_Bayar_PNBP_DJKI.pdf'
  },
  {
    id: 'EXP-006',
    tanggal: '19 Juli 2026',
    kategori: 'Publikasi & HKI',
    uraian: 'Article Processing Charge (APC) publikasi jurnal ilmiah terakreditasi SINTA 2',
    volume: '1 Naskah Terbit',
    nominal: 3000000,
    noBukti: 'INV-JURNAL-S2/2026',
    status: 'Dalam Pemeriksaan',
    lampiran: 'Invoice_LoA_Jurnal_SINTA2.pdf'
  },
  {
    id: 'EXP-007',
    tanggal: '04 Agustus 2026',
    kategori: 'Konsumsi & FGD',
    uraian: 'Konsumsi rapat FGD diseminasi penerapan teknologi bersama pengurus koperasi & perwakilan desa',
    volume: '25 Kotak Snack & Makan',
    nominal: 1450000,
    noBukti: 'NT-CAT-221/VIII/2026',
    status: 'Terverifikasi',
    lampiran: 'Nota_Katering_Daftar_Hadir.pdf'
  }
];

export default function TableView({ preset, controls }: TableViewProps) {
  const [activeTab, setActiveTab] = useState<number>(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterYear, setFilterYear] = useState('2026');
  
  // Custom states for showing modals/comments
  const [activeComment, setActiveComment] = useState<{title: string, user: string, text: string} | null>(null);

  // States for Realisasi Anggaran
  const [expenses, setExpenses] = useState<ExpenseRecord[]>(initialExpenses);
  const [categoryFilter, setCategoryFilter] = useState<string>('Semua');
  const [expenseSearch, setExpenseSearch] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  // Form state for adding new expense
  const [newExpense, setNewExpense] = useState({
    tanggal: '28 Oktober 2026',
    kategori: 'Bahan Habis Pakai & ATK' as ExpenseRecord['kategori'],
    uraian: '',
    volume: '1 Paket',
    nominal: '',
    noBukti: '',
    lampiran: 'Nota_Kuitansi_Belanja.pdf'
  });

  const colors = preset.config;

  // Determine sub-navigation tabs based on selected theme context: 'Catatan Harian' diganti 'Realisasi Anggaran'
  const subTabs = [
    { label: 'Usulan', icon: '📝' },
    { label: 'Perbaikan Usulan', icon: '🔄' },
    { label: 'Realisasi Anggaran', icon: '💰' },
    { label: 'Laporan Akhir', icon: '📑' },
    { label: 'Pengkinian Capaian Luaran', icon: '🎯' }
  ];

  // Realisasi Anggaran Budget Metrics
  const paguTotal = 25000000; // Rp 25.000.000
  const termin1Pencairan = 17500000; // 70% Rp 17.500.000
  const termin2Pencairan = 7500000; // 30% Rp 7.500.000

  const totalRealisasi = useMemo(() => {
    return expenses.reduce((acc, curr) => acc + curr.nominal, 0);
  }, [expenses]);

  const sisaAnggaran = paguTotal - totalRealisasi;
  const persentaseSerapan = Math.min(100, Math.round((totalRealisasi / paguTotal) * 100));
  const persentaseTermin1 = Math.min(100, Math.round((totalRealisasi / termin1Pencairan) * 100));

  const triggerToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(null);
    }, 4500);
  };

  // Filtered expenses
  const filteredExpenses = useMemo(() => {
    return expenses.filter(item => {
      const matchCategory = categoryFilter === 'Semua' || item.kategori === categoryFilter;
      const matchSearch = 
        item.uraian.toLowerCase().includes(expenseSearch.toLowerCase()) ||
        item.noBukti.toLowerCase().includes(expenseSearch.toLowerCase()) ||
        item.kategori.toLowerCase().includes(expenseSearch.toLowerCase());
      return matchCategory && matchSearch;
    });
  }, [expenses, categoryFilter, expenseSearch]);

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExpense.uraian.trim() || !newExpense.nominal) {
      alert('Mohon lengkapi uraian pengeluaran dan jumlah nominal.');
      return;
    }

    const nominalNum = parseInt(newExpense.nominal.replace(/[^0-9]/g, ''), 10) || 0;
    if (nominalNum <= 0) {
      alert('Nominal harus lebih dari Rp 0.');
      return;
    }

    const record: ExpenseRecord = {
      id: `EXP-${String(expenses.length + 1).padStart(3, '0')}`,
      tanggal: newExpense.tanggal,
      kategori: newExpense.kategori,
      uraian: newExpense.uraian,
      volume: newExpense.volume || '1 Paket',
      nominal: nominalNum,
      noBukti: newExpense.noBukti || `KW-${Date.now().toString().slice(-4)}/LPPM/2026`,
      status: 'Dalam Pemeriksaan',
      lampiran: newExpense.lampiran
    };

    setExpenses([record, ...expenses]);
    setShowAddModal(false);
    setNewExpense({
      tanggal: '28 Oktober 2026',
      kategori: 'Bahan Habis Pakai & ATK',
      uraian: '',
      volume: '1 Paket',
      nominal: '',
      noBukti: '',
      lampiran: 'Nota_Kuitansi_Belanja.pdf'
    });
    triggerToast(`Pengeluaran sebesar Rp ${nominalNum.toLocaleString('id-ID')} berhasil dicatat ke sistem Realisasi Anggaran!`);
  };

  const handleDeleteExpense = (id: string, nominal: number) => {
    if (confirm(`Yakin ingin menghapus item bukti belanja ini sebesar Rp ${nominal.toLocaleString('id-ID')}?`)) {
      setExpenses(expenses.filter(item => item.id !== id));
      triggerToast('Item bukti pengeluaran telah dihapus.');
    }
  };

  // Match the search filter against mock entries
  const filteredData = useMemo(() => {
    return preset.tableData.filter((item) => {
      const matchSearch = 
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.col1.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchYear = filterYear ? item.field3.includes(filterYear) : true;
      return matchSearch;
    });
  }, [preset, searchQuery, filterYear]);

  // Handle mock comment clicks
  const triggerComment = (rowTitle: string, user: string) => {
    setActiveComment({
      title: rowTitle,
      user: user,
      text: `Usulan draf ini memerlukan pelampiran dokumen luaran wajib yang ber-ISSN dan rincian anggaran terperinci sesuai SBU 2026.`
    });
  };

  // Border radius class helper
  const roundedClass = 
    controls.roundedMode === 'none' ? 'rounded-none' :
    controls.roundedMode === 'md' ? 'rounded-md' :
    controls.roundedMode === 'xl' ? 'rounded-xl' : 'rounded-2xl';

  return (
    <div className={`space-y-4 ${controls.layoutMode === 'compact' ? 'space-y-3' : 'space-y-4'}`}>
      
      {/* Toast Notification */}
      {notification && (
        <div className="bg-emerald-800 text-white text-xs font-bold px-4 py-2.5 rounded-lg shadow-md flex items-center justify-between animate-fade-in">
          <span className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-300" />
            {notification}
          </span>
          <button onClick={() => setNotification(null)} className="text-emerald-200 hover:text-white">✕</button>
        </div>
      )}

      {/* 1. Universal Tab Navigation Bar (Catatan Harian telah diganti Realisasi Anggaran) */}
      <div className="border-b border-gray-200 overflow-x-auto select-none scrollbar-none">
        <div className="flex gap-1.5 min-w-max pb-0.5">
          {subTabs.map((tab, idx) => {
            const isActive = activeTab === idx;
            return (
              <button
                key={idx}
                onClick={() => setActiveTab(idx)}
                id={`subtab-${idx}`}
                className={`text-xs px-3.5 py-2 font-semibold transition border-b-2 whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                  isActive
                    ? 'border-[#1e3a6e] text-[#1e3a6e] font-extrabold'
                    : 'border-transparent text-gray-500 hover:text-[#1e3a6e]'
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
                {tab.label === 'Realisasi Anggaran' && (
                  <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-black ${
                    isActive ? 'bg-[#1e3a6e] text-white' : 'bg-emerald-100 text-emerald-800'
                  }`}>
                    {persentaseSerapan}%
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* TAB CONTENT 2: REALISASI ANGGARAN */}
      {activeTab === 2 ? (
        <div className="space-y-5 animate-fade-in text-left">
          
          {/* Header Info Banner Realisasi Anggaran */}
          <div className="bg-gradient-to-r from-[#11244e] via-[#1e3a6e] to-[#254b8c] text-white p-5 rounded-xl shadow-xs relative overflow-hidden">
            <div className="absolute right-0 top-0 opacity-10 text-[160px] font-bold select-none pointer-events-none transform translate-y-[-40px] translate-x-[20px]">
              SPTB
            </div>
            <div className="relative z-10 max-w-3xl space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className="bg-amber-400 text-slate-900 font-black text-[9px] px-2 py-0.5 rounded-full uppercase tracking-wider">
                  Sistem Realisasi Anggaran & SPTB LPPM
                </span>
                <span className="bg-white/20 text-white font-extrabold text-[9px] px-2 py-0.5 rounded-full">
                  Tahun Anggaran 2026
                </span>
                <span className="bg-emerald-400/30 text-emerald-200 border border-emerald-400/40 text-[9px] font-bold px-2 py-0.5 rounded-full">
                  ✓ Sesuai SBU Dikti & ITSNU
                </span>
              </div>
              <h3 className="text-base md:text-lg font-black tracking-tight uppercase">
                Rekapitulasi Realisasi Belanja & Tanggung Jawab Anggaran
              </h3>
              <p className="text-[11.5px] text-blue-100 font-medium leading-relaxed">
                Pencatatan mutasi belanja dana hibah riset dan pengabdian secara akuntabel. Dilengkapi validasi bukti kuitansi belanja, verifikasi LPPM, dan penerbitan Surat Pernyataan Tanggung Jawab Belanja (SPTB) bermaterai.
              </p>
            </div>
          </div>

          {/* Metric Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
            {/* Card 1: Pagu Dana Hibah */}
            <div className="bg-white border border-gray-200 p-4 rounded-xl shadow-2xs space-y-2">
              <div className="flex items-center justify-between text-gray-500 text-[11px] font-bold">
                <span className="uppercase tracking-wider">Pagu Dana Total</span>
                <Wallet className="w-4 h-4 text-blue-600" />
              </div>
              <div className="text-lg font-black text-slate-900">
                Rp {paguTotal.toLocaleString('id-ID')}
              </div>
              <div className="text-[10px] text-gray-500 flex items-center justify-between pt-1 border-t border-gray-100">
                <span>Skema Terdaftar</span>
                <span className="font-bold text-blue-700">Penelitian Terapan</span>
              </div>
            </div>

            {/* Card 2: Total Belanja Terealisasi */}
            <div className="bg-white border border-emerald-200 bg-emerald-50/20 p-4 rounded-xl shadow-2xs space-y-2">
              <div className="flex items-center justify-between text-emerald-800 text-[11px] font-bold">
                <span className="uppercase tracking-wider">Total Realisasi Belanja</span>
                <DollarSign className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-lg font-black text-emerald-900">
                Rp {totalRealisasi.toLocaleString('id-ID')}
              </div>
              <div className="text-[10px] text-emerald-700 flex items-center justify-between pt-1 border-t border-emerald-100">
                <span>Serapan dari Pagu Total</span>
                <span className="font-extrabold">{persentaseSerapan}%</span>
              </div>
            </div>

            {/* Card 3: Sisa Anggaran */}
            <div className="bg-white border border-gray-200 p-4 rounded-xl shadow-2xs space-y-2">
              <div className="flex items-center justify-between text-gray-500 text-[11px] font-bold">
                <span className="uppercase tracking-wider">Sisa Saldo Pagu</span>
                <Clock className="w-4 h-4 text-amber-600" />
              </div>
              <div className="text-lg font-black text-amber-800">
                Rp {sisaAnggaran.toLocaleString('id-ID')}
              </div>
              <div className="text-[10px] text-gray-500 flex items-center justify-between pt-1 border-t border-gray-100">
                <span>Alokasi Termin 2 (30%)</span>
                <span className="font-bold text-slate-700">Rp {termin2Pencairan.toLocaleString('id-ID')}</span>
              </div>
            </div>

            {/* Card 4: Status Pencairan Termin */}
            <div className="bg-white border border-blue-200 bg-blue-50/30 p-4 rounded-xl shadow-2xs space-y-2">
              <div className="flex items-center justify-between text-blue-900 text-[11px] font-bold">
                <span className="uppercase tracking-wider">Pencairan Tahap I (70%)</span>
                <CheckCircle className="w-4 h-4 text-blue-600" />
              </div>
              <div className="text-lg font-black text-blue-900">
                Rp {termin1Pencairan.toLocaleString('id-ID')}
              </div>
              <div className="text-[10px] text-blue-700 flex items-center justify-between pt-1 border-t border-blue-100">
                <span>Serapan Termin I</span>
                <span className="font-extrabold text-emerald-700">{persentaseTermin1}% (Tercapai)</span>
              </div>
            </div>
          </div>

          {/* Progress bar and disbursement requirement status */}
          <div className="bg-white border border-gray-200 p-4 rounded-xl shadow-2xs space-y-2.5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs">
              <span className="font-black text-slate-800 uppercase tracking-tight flex items-center gap-1.5">
                <ArrowUpRight className="w-4 h-4 text-emerald-600" />
                Kemajuan Penyerapan Anggaran (Target SPTB Kemajuan: ≥ 70%)
              </span>
              <span className="text-[11px] font-extrabold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Terserap {persentaseSerapan}% dari Total Pagu Anggaran
              </span>
            </div>
            
            <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden flex">
              <div 
                className="bg-emerald-600 h-3 rounded-full transition-all duration-500 relative" 
                style={{ width: `${persentaseSerapan}%` }}
              >
                <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between text-[10.5px] text-gray-500 pt-1 font-medium">
              <span>Termin 1 (70%): Terverifikasi Lolos SPTB</span>
              <span>Ambang Termin 2: Siap Pencairan 30% setelah Review Laporan Kemajuan LPPM</span>
            </div>
          </div>

          {/* Action & Filter Bar */}
          <div className="bg-[#f8fafc] border border-gray-200 p-3.5 rounded-xl flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            
            {/* Category Filter Pills */}
            <div className="flex flex-wrap gap-1.5 items-center">
              <span className="text-[10.5px] font-black text-gray-500 uppercase tracking-wide mr-1">
                Pos Belanja:
              </span>
              {[
                'Semua',
                'Bahan Habis Pakai & ATK',
                'Operasional Lapangan & SPPD',
                'Honorarium',
                'Publikasi & HKI',
                'Konsumsi & FGD'
              ].map((cat) => {
                const isActive = categoryFilter === cat;
                return (
                  <button
                    key={cat}
                    onClick={() => setCategoryFilter(cat)}
                    className={`text-[10.5px] px-2.5 py-1 rounded font-bold transition cursor-pointer ${
                      isActive
                        ? 'bg-[#1e3a6e] text-white shadow-2xs'
                        : 'bg-white hover:bg-gray-100 text-gray-650 border border-gray-200'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>

            {/* Right: Search & Action Buttons */}
            <div className="flex flex-wrap items-center gap-2 justify-end">
              <div className="relative w-full sm:w-56">
                <span className="absolute inset-y-0 left-0 flex items-center pl-2.5 pointer-events-none">
                  <Search className="h-3.5 w-3.5 text-gray-400" />
                </span>
                <input
                  type="text"
                  placeholder="Cari uraian atau no bukti..."
                  value={expenseSearch}
                  onChange={(e) => setExpenseSearch(e.target.value)}
                  className="w-full text-xs bg-white border border-gray-250 rounded py-1.5 pl-8 pr-3 outline-none text-gray-700 focus:border-blue-500"
                />
              </div>

              {/* Unduh SPTB Button */}
              <button
                onClick={() => {
                  triggerToast('Surat Pernyataan Tanggung Jawab Belanja (SPTB) bermaterai Rp 10.000 telah disiapkan dan siap diunduh.');
                  alert(`[DOKUMEN RESMI SPTB LPPM ITSNU PEKALONGAN]\n\nJudul: Surat Pernyataan Tanggung Jawab Belanja (SPTB)\nKetua Peneliti: ${preset.brand.userName}\nTotal Realisasi: Rp ${totalRealisasi.toLocaleString('id-ID')}\nStatus: Siap Tanda Tangan & Materai Rp 10.000.`);
                }}
                className="flex items-center gap-1.5 bg-white hover:bg-slate-100 border border-gray-300 text-slate-800 text-[11px] font-extrabold px-3 py-1.5 rounded transition shadow-2xs cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-blue-700" />
                <span>Unduh Format SPTB</span>
              </button>

              {/* Tambah Belanja Button */}
              <button
                onClick={() => setShowAddModal(true)}
                className="flex items-center gap-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-[11px] font-black px-3.5 py-1.5 rounded transition shadow-2xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ Catat Belanja Baru</span>
              </button>
            </div>
          </div>

          {/* Table of Realisasi Anggaran */}
          <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[950px]">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-200 text-gray-600">
                    <th className="text-[10px] uppercase font-black py-3 px-3 text-center w-12">No</th>
                    <th className="text-[10px] uppercase font-black py-3 px-3 w-28">Tanggal</th>
                    <th className="text-[10px] uppercase font-black py-3 px-3 w-48">Pos Belanja SBU</th>
                    <th className="text-[10px] uppercase font-black py-3 px-4">Uraian Bukti Belanja</th>
                    <th className="text-[10px] uppercase font-black py-3 px-3 w-32">Kuantitas / Vol</th>
                    <th className="text-[10px] uppercase font-black py-3 px-3 text-right w-32">Jumlah (Rp)</th>
                    <th className="text-[10px] uppercase font-black py-3 px-3 text-center w-36">No. Bukti / Nota</th>
                    <th className="text-[10px] uppercase font-black py-3 px-3 text-center w-32">Status LPPM</th>
                    <th className="text-[10px] uppercase font-black py-3 px-3 text-center w-24">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 text-xs">
                  {filteredExpenses.length > 0 ? (
                    filteredExpenses.map((item, idx) => (
                      <tr key={item.id} className="hover:bg-slate-50/70 transition">
                        <td className="py-3 px-3 text-center text-gray-400 font-bold">{idx + 1}</td>
                        <td className="py-3 px-3 font-semibold text-gray-700 whitespace-nowrap">{item.tanggal}</td>
                        <td className="py-3 px-3">
                          <span className="inline-block bg-slate-100 text-slate-800 font-bold px-2 py-0.5 rounded text-[10px]">
                            {item.kategori}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-bold text-gray-900 leading-snug">{item.uraian}</div>
                          <div className="text-[10px] text-blue-600 font-mono mt-0.5 flex items-center gap-1">
                            <FileText className="w-3 h-3" /> {item.lampiran}
                          </div>
                        </td>
                        <td className="py-3 px-3 text-gray-600 font-medium">{item.volume}</td>
                        <td className="py-3 px-3 text-right font-black text-slate-900 font-mono whitespace-nowrap">
                          Rp {item.nominal.toLocaleString('id-ID')}
                        </td>
                        <td className="py-3 px-3 text-center font-mono text-[10px] text-gray-600 font-bold">
                          {item.noBukti}
                        </td>
                        <td className="py-3 px-3 text-center select-none">
                          {item.status === 'Terverifikasi' ? (
                            <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-black px-2 py-0.5 rounded-full">
                              <CheckCircle className="w-3 h-3 text-emerald-600" /> Terverifikasi
                            </span>
                          ) : item.status === 'Dalam Pemeriksaan' ? (
                            <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-800 border border-amber-200 text-[10px] font-black px-2 py-0.5 rounded-full">
                              <Clock className="w-3 h-3 text-amber-600" /> Audit LPPM
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 bg-gray-100 text-gray-700 text-[10px] font-black px-2 py-0.5 rounded-full">
                              Draf
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-3 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => alert(`Lampiran Bukti Nota: ${item.lampiran}\nNo Bukti: ${item.noBukti}\nNominal: Rp ${item.nominal.toLocaleString('id-ID')}`)}
                              title="Lihat Bukti Kuitansi"
                              className="p-1 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded transition cursor-pointer"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteExpense(item.id, item.nominal)}
                              title="Hapus Bukti"
                              className="p-1 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded transition cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={9} className="py-8 text-center text-gray-400 font-bold text-xs">
                        Tidak ada catatan pengeluaran belanja yang sesuai filter "{categoryFilter}".
                      </td>
                    </tr>
                  )}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-50 border-t-2 border-gray-200 font-bold text-xs text-gray-800">
                    <td colSpan={5} className="py-3 px-4 text-right uppercase tracking-wider font-extrabold">
                      Total Realisasi Terpilih:
                    </td>
                    <td className="py-3 px-3 text-right font-black text-emerald-800 font-mono text-sm">
                      Rp {filteredExpenses.reduce((sum, i) => sum + i.nominal, 0).toLocaleString('id-ID')}
                    </td>
                    <td colSpan={3} className="py-3 px-3 text-right text-[11px] text-gray-500 font-medium">
                      Akumulasi {filteredExpenses.length} Bukti Transaksi
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Modal / Popup Tambah Belanja Baru */}
          {showAddModal && (
            <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
              <div className="bg-white rounded-xl shadow-2xl border border-gray-200 w-full max-w-lg overflow-hidden animate-fade-in text-left">
                <div className="bg-[#1e3a6e] text-white px-5 py-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Receipt className="w-5 h-5 text-amber-400" />
                    <h3 className="font-black text-sm uppercase tracking-wide">
                      Catat Realisasi Pengeluaran Anggaran
                    </h3>
                  </div>
                  <button 
                    onClick={() => setShowAddModal(false)}
                    className="text-white/70 hover:text-white font-bold text-lg"
                  >
                    ✕
                  </button>
                </div>

                <form onSubmit={handleAddExpense} className="p-5 space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-extrabold text-gray-700 uppercase tracking-wide mb-1">
                        Tanggal Transaksi
                      </label>
                      <input
                        type="text"
                        value={newExpense.tanggal}
                        onChange={(e) => setNewExpense({ ...newExpense, tanggal: e.target.value })}
                        className="w-full text-xs border border-gray-300 rounded p-2 outline-none font-bold text-gray-800 focus:border-blue-500"
                        placeholder="Contoh: 28 Oktober 2026"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-extrabold text-gray-700 uppercase tracking-wide mb-1">
                        Pos Belanja SBU
                      </label>
                      <select
                        value={newExpense.kategori}
                        onChange={(e) => setNewExpense({ ...newExpense, kategori: e.target.value as ExpenseRecord['kategori'] })}
                        className="w-full text-xs border border-gray-300 rounded p-2 outline-none font-bold text-gray-800 focus:border-blue-500 bg-white"
                      >
                        <option value="Bahan Habis Pakai & ATK">Bahan Habis Pakai & ATK</option>
                        <option value="Operasional Lapangan & SPPD">Operasional Lapangan & SPPD</option>
                        <option value="Honorarium">Honorarium</option>
                        <option value="Publikasi & HKI">Publikasi & HKI</option>
                        <option value="Konsumsi & FGD">Konsumsi & FGD</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-extrabold text-gray-700 uppercase tracking-wide mb-1">
                      Uraian Rincian Belanja / Transaksi
                    </label>
                    <textarea
                      value={newExpense.uraian}
                      onChange={(e) => setNewExpense({ ...newExpense, uraian: e.target.value })}
                      rows={2}
                      className="w-full text-xs border border-gray-300 rounded p-2 outline-none text-gray-800 focus:border-blue-500 font-medium"
                      placeholder="Uraikan peruntukan belanja secara jelas sesuai dokumen proposal..."
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-extrabold text-gray-700 uppercase tracking-wide mb-1">
                        Jumlah Nominal (Rp)
                      </label>
                      <input
                        type="number"
                        min="1000"
                        value={newExpense.nominal}
                        onChange={(e) => setNewExpense({ ...newExpense, nominal: e.target.value })}
                        className="w-full text-xs border border-gray-300 rounded p-2 outline-none font-black text-gray-900 focus:border-blue-500"
                        placeholder="Contoh: 1500000"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-extrabold text-gray-700 uppercase tracking-wide mb-1">
                        Volume / Kuantitas
                      </label>
                      <input
                        type="text"
                        value={newExpense.volume}
                        onChange={(e) => setNewExpense({ ...newExpense, volume: e.target.value })}
                        className="w-full text-xs border border-gray-300 rounded p-2 outline-none font-medium text-gray-800 focus:border-blue-500"
                        placeholder="Contoh: 2 Orang x 1 Bulan"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-extrabold text-gray-700 uppercase tracking-wide mb-1">
                        Nomor Bukti / Kuitansi / Faktur
                      </label>
                      <input
                        type="text"
                        value={newExpense.noBukti}
                        onChange={(e) => setNewExpense({ ...newExpense, noBukti: e.target.value })}
                        className="w-full text-xs border border-gray-300 rounded p-2 outline-none font-mono text-gray-800 focus:border-blue-500"
                        placeholder="Contoh: KW-2026/ITSNU/X/012"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-extrabold text-gray-700 uppercase tracking-wide mb-1">
                        File Bukti (Scan PDF / Gambar)
                      </label>
                      <input
                        type="text"
                        value={newExpense.lampiran}
                        onChange={(e) => setNewExpense({ ...newExpense, lampiran: e.target.value })}
                        className="w-full text-xs border border-gray-300 rounded p-2 outline-none font-mono text-blue-700 focus:border-blue-500"
                        placeholder="Contoh: Kuitansi_Mitra.pdf"
                      />
                    </div>
                  </div>

                  <div className="pt-2 border-t border-gray-100 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowAddModal(false)}
                      className="px-4 py-2 border border-gray-300 rounded text-xs font-bold text-gray-600 hover:bg-gray-100 cursor-pointer"
                    >
                      Batal
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded text-xs font-black shadow-xs cursor-pointer"
                    >
                      Simpan Bukti Realisasi
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

        </div>
      ) : (
        /* STANDARD PROPOSALS TABLE VIEW FOR OTHER TABS (Usulan, Perbaikan Usulan, Laporan Akhir, Pengkinian Capaian Luaran) */
        <div className="space-y-4">
          {/* Status banner for specific tabs */}
          {activeTab !== 0 && (
            <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg flex items-center justify-between text-xs text-blue-900">
              <span className="font-bold flex items-center gap-1.5">
                <span>{subTabs[activeTab].icon}</span>
                <span>Modul Tab Aktif: <strong>{subTabs[activeTab].label}</strong></span>
              </span>
              <span className="text-[11px] text-blue-700 font-medium">
                {activeTab === 1 ? 'Menampilkan riwayat catatan perbaikan dari reviewer independen' :
                 activeTab === 3 ? 'Monitoring penyerahan dokumen berkas Laporan Akhir' :
                 'Pembaruan capaian luaran wajib publikasi, HKI, buku, dan prototipe'}
              </span>
            </div>
          )}

          {/* 2. Form Filter & Info Utility Bar */}
          <div className="flex flex-col sm:flex-row gap-3 justify-between items-stretch sm:items-center">
            <div className="flex gap-2">
              <button 
                onClick={() => alert(`Sistem status: Dosen atas nama ${preset.brand.userName} memiliki tingkat eligibilitas pengajuan yang sangat tinggi berdasarkan status SINTA Dikti.`)}
                className="flex items-center gap-1 bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold px-3 py-1.5 rounded transition shadow-xs cursor-pointer shrink-0"
              >
                <Info className="w-3.5 h-3.5" />
                <span>Info Eligibilitas</span>
              </button>
              
              {/* Quick search input */}
              <div className="relative w-full sm:w-64">
                <span className="absolute inset-y-0 left-0 flex items-center pl-2.5 pointer-events-none">
                  <Search className="h-3.5 w-3.5 text-gray-400" />
                </span>
                <input
                  type="text"
                  placeholder="Cari kata kunci..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full text-xs bg-white border border-gray-200 rounded py-1.5 pl-8 pr-3 outline-none text-gray-700 focus:border-blue-400 focus:ring-1 focus:ring-blue-100 placeholder:text-gray-400"
                />
              </div>
            </div>

            {/* Filter Inputs right aligned */}
            <div className="flex items-center gap-2 justify-end">
              <span className="text-[10px] sm:text-xs font-bold text-gray-600 uppercase tracking-wide flex items-center gap-1 shrink-0">
                <Filter className="w-3 h-3 text-[#1e3a6e]" /> Tahun Pelaksanaan:
              </span>
              <div className="flex items-center gap-1.5 bg-white border border-gray-200 rounded px-2 py-1 shadow-2xs">
                <span className="text-gray-400 text-xs">▼</span>
                <input
                  type="number"
                  min="2020"
                  max="2030"
                  value={filterYear}
                  onChange={(e) => setFilterYear(e.target.value)}
                  className="text-xs font-bold text-slate-800 outline-none w-14 text-center"
                />
              </div>
            </div>
          </div>

          {/* 3. High Fidelity Responsive Table Card */}
          <div className={`overflow-hidden bg-white border border-gray-200 ${roundedClass} shadow-xs text-left`}>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[900px]">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-100">
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 text-center w-12">No</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 w-52">Ketua Pengusul</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 w-[380px]">Informasi Judul Usulan</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3">Skema Program</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3">Fokus Penelitian</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3 text-center w-20">Tahun</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3 text-center">Peran</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3 text-center w-32">Status</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3 text-center w-36">Komentar</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 text-center w-14">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {filteredData.length > 0 ? (
                    filteredData.map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/50 transition">
                        {/* Column 1: No */}
                        <td className="py-4 px-4 text-xs font-bold text-gray-400 text-center select-none">{row.no}</td>
                        
                        {/* Column 2: Leader / Node */}
                        <td className="py-4 px-4 text-xs">
                          <div className="font-extrabold text-[#1e3a6e] uppercase tracking-tight">{row.col1}</div>
                          <div className="text-[10px] text-gray-400 font-bold font-mono pt-0.5">{row.col2}</div>
                        </td>

                        {/* Column 3: Title */}
                        <td className="py-4 px-4 text-xs leading-relaxed text-gray-700">
                          <div className="font-semibold text-gray-900 group-hover:text-blue-700 transition line-clamp-2 md:line-clamp-none">
                            {row.title}
                          </div>
                        </td>

                        {/* Column 4: Category */}
                        <td className="py-4 px-3 text-xs text-gray-600 font-medium">
                          <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded font-bold text-[10px]">
                            {row.category}
                          </span>
                        </td>

                        {/* Column 5: Focus */}
                        <td className="py-4 px-3 text-xs text-gray-600 font-medium">{row.focus}</td>

                        {/* Column 6: Year */}
                        <td className="py-4 px-3 text-xs font-bold text-gray-600 text-center font-mono">{row.field3}</td>

                        {/* Column 7: Role */}
                        <td className="py-4 px-3 text-xs text-center">
                          <span className="text-blue-800 font-bold bg-blue-50 px-2 py-0.5 rounded text-[10px]">
                            {row.role}
                          </span>
                        </td>

                        {/* Column 8: Badge status */}
                        <td className="py-4 px-3 text-xs text-center select-none">
                          {row.status === 'tidak' ? (
                            <span className={`inline-block border px-2 py-1 rounded text-[10px] font-black ${colors.badgeStyle} uppercase text-center w-full`}>
                              Tidak Didanai
                            </span>
                          ) : row.status === 'didandai' ? (
                            <span className="inline-block border px-2 py-1 rounded text-[10px] font-black bg-emerald-50 text-emerald-800 border-emerald-200 uppercase text-center w-full">
                              Danai / Setuju
                            </span>
                          ) : (
                            <span className="inline-block border px-2 py-1 rounded text-[10px] font-black bg-amber-50 text-amber-800 border-amber-200 uppercase text-center w-full">
                              Pending Audit
                            </span>
                          )}
                        </td>

                        {/* Column 9: Comment triggers */}
                        <td className="py-4 px-3 text-xs text-center space-y-1">
                          <button
                            onClick={() => triggerComment(row.title, row.col1)}
                            className={`text-[10px] text-white px-2.5 py-1 rounded font-bold transition shadow-2xs hover:scale-102 cursor-pointer w-full bg-[#1e3a6e] hover:bg-slate-800`}
                          >
                            LPPM Review
                          </button>
                        </td>

                        {/* Column 10: Action triggers */}
                        <td className="py-4 px-4 text-xs text-center">
                          <button
                            onClick={() => alert(`Detail draf usulan: "${row.title}"`)}
                            title="Lihat Detail Dokumen"
                            className="p-1.5 bg-blue-500 hover:bg-blue-600 text-white rounded transition shadow-2xs cursor-pointer hover:rotate-6"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={10} className="text-center py-8 text-xs text-gray-400 font-medium">
                        Tidak ada usulan data yang cocok dengan kriteria pencarian "{searchQuery}" di tahun {filterYear}.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Dynamic Comment Modal overlays under the table */}
          {activeComment && (
            <div className="p-4 bg-amber-50 border-l-4 border-amber-500 rounded shadow-xs text-xs space-y-1 animate-fade-in relative text-left">
              <button 
                onClick={() => setActiveComment(null)}
                className="absolute top-2 right-2 text-gray-400 hover:text-gray-700 font-bold"
              >
                ✕
              </button>
              <div className="flex items-center gap-1.5 text-amber-900 font-bold">
                <MessageSquare className="w-3.5 h-3.5 text-amber-600" />
                <span>Komentar & Catatan Reviewer Penelitian:</span>
              </div>
              <p className="text-gray-700 font-semibold">{activeComment.title}</p>
              <p className="text-gray-600 italic">{activeComment.text}</p>
            </div>
          )}
        </div>
      )}

    </div>
  );
}
