import React, { useState } from 'react';
import { ThemePreset, CustomControls } from '../types';
import { X, Copy, Check, FileCode, Terminal, HelpCircle, CheckCheck } from 'lucide-react';

interface CodeExporterProps {
  preset: ThemePreset;
  controls: CustomControls;
  onClose: () => void;
}

export default function CodeExporter({ preset, controls, onClose }: CodeExporterProps) {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'jsx' | 'tailwind' | 'usage'>('jsx');

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Build the code template depending on selected settings
  const radiusMapping = 
    controls.roundedMode === 'none' ? 'rounded-none' :
    controls.roundedMode === 'md' ? 'rounded-md' :
    controls.roundedMode === 'xl' ? 'rounded-xl' : 'rounded-2xl';

  const generatedCodeJSX = `import React, { useState } from 'react';
import { 
  Home, Search, Bell, User, LayoutGrid, BarChart2, 
  HelpCircle, ChevronDown, CheckCircle, Eye, Info 
} from 'lucide-react';

// Theme Presets: ${preset.name}
// Configured Primary Color: ${preset.config.primaryBg}
export default function DashboardTemplate() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('Home');

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-sans">
      
      {/* 1. TOP NAVBAR / HEADER */}
      <header className="bg-white border-b border-gray-200 py-3 px-6 sticky top-0 z-40 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 ${preset.config.primaryBg} ${radiusMapping} text-white font-extrabold flex items-center justify-center text-xs text-center leading-tight">
            ${preset.brand.logoInitials.replace('\n', ' ')}
          </div>
          <span className="font-extrabold text-[#1e3a6e] tracking-tight">${preset.brand.logoText}</span>
        </div>
        
        <div className="flex items-center gap-4">
          <button className="text-xs font-bold text-white ${preset.config.primaryBg} px-3 py-1.5 ${radiusMapping} transition">
            ${preset.brand.userRole}
          </button>
          <span className="text-xs font-semibold text-gray-700">🔔 ${preset.brand.userName}</span>
        </div>
      </header>

      {/* 2. SUB NAVIGATION LINKS */}
      <nav className="${preset.config.primaryBg} text-white px-6 py-1 flex items-center gap-1 overflow-x-auto">
        {${JSON.stringify(preset.navigation)}.map((navItem) => (
          <button
            key={navItem}
            onClick={() => setActiveTab(navItem)}
            className={\`text-xs px-4 py-3 font-semibold transition border-b-2 hover:text-white \${
              activeTab === navItem ? 'border-amber-400 text-white font-bold' : 'border-transparent text-white/70'
            }\`}
          >
            {navItem}
          </button>
        ))}
      </nav>

      {/* 3. MAIN CONTAINER GRID */}
      <main className="max-w-7xl mx-auto p-6 grid grid-cols-1 ${controls.layoutMode === 'split' ? 'lg:grid-cols-4' : 'grid-cols-1'} gap-6">
        
        {/* LEFT / MAIN COLUMN */}
        <div className="${controls.layoutMode === 'split' ? 'lg:col-span-3' : 'col-span-1'} space-y-6">
          
          {/* Welcome Banner Card */}
          <div className="${preset.config.primaryBg} ${radiusMapping} text-white p-6 shadow-sm relative overflow-hidden">
            <h2 className="text-xl font-bold">Selamat Datang, ${preset.brand.userName}!</h2>
            <p className="text-xs text-white/80 mt-1">Kelola publikasi dan draf usulan dengan praktis.</p>
          </div>

          ${controls.showStats ? `
          {/* Highlight Statistics Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="${preset.config.highlightColors.first} ${radiusMapping} text-white p-4 flex items-center justify-between">
              <div>
                <dt className="text-2xl font-black">${preset.stats[0]?.value || '0'}</dt>
                <dd className="text-xs font-bold uppercase">${preset.stats[0]?.title || 'Stats'}</dd>
              </div>
              <span className="text-xl">🔍</span>
            </div>
            <div className="${preset.config.highlightColors.second} ${radiusMapping} text-white p-4 flex items-center justify-between">
              <div>
                <dt className="text-2xl font-black">${preset.stats[1]?.value || '0'}</dt>
                <dd className="text-xs font-bold uppercase">${preset.stats[1]?.title || 'Stats'}</dd>
              </div>
              <span className="text-xl">🤝</span>
            </div>
            <div className="${preset.config.highlightColors.third} ${radiusMapping} text-white p-4 flex items-center justify-between">
              <div>
                <dt className="text-2xl font-black">${preset.stats[2]?.value || '0'}</dt>
                <dd className="text-xs font-bold uppercase">${preset.stats[2]?.title || 'Stats'}</dd>
              </div>
              <span className="text-xl">📦</span>
            </div>
          </div>` : ''}

          {/* Detailed Responsive Data Table */}
          <div className="bg-white border border-gray-200 ${radiusMapping} shadow-sm overflow-hidden">
            <div className="p-4 border-b border-gray-100 flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase text-gray-500">Usulan Kelola</h3>
              <div className="text-xs text-gray-400">Total ${preset.tableData.length} records</div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[700px]">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-100">
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 text-center">No</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4">Pengusul / Author</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4">Judul Dokumen</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4">Skema Program</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 text-xs">
                  {${JSON.stringify(preset.tableData)}.map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-50 transition">
                      <td className="py-4 px-4 text-center text-gray-400 font-bold">{row.no}</td>
                      <td className="py-4 px-4">
                        <div className="font-bold text-[#1e3a6e]">{row.col1}</div>
                        <div className="text-[10px] text-gray-400 font-mono">{row.col2}</div>
                      </td>
                      <td className="py-4 px-4 text-gray-700">{row.title}</td>
                      <td className="py-4 px-4 font-bold text-gray-600">{row.category}</td>
                      <td className="py-4 px-4">
                        <span className="px-2 py-1 rounded text-[10px] font-bold bg-amber-100 text-amber-700">
                          {row.status === 'tidak' ? 'Tidak Didanai' : 'Danai / Approved'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>

        {/* RIGHT SIDEBAR / ACCESSORIES */}
        ${controls.layoutMode === 'split' ? `
        <div className="space-y-6">
          <div className="bg-white border border-gray-200 p-4 ${radiusMapping} shadow-sm">
            <h4 className="text-xs font-bold uppercase text-gray-400 mb-3">User Profile Detail</h4>
            <div className="flex items-center gap-3 pb-3 border-b border-gray-100 mb-3">
              <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-base">
                ${preset.brand.userAvatar}
              </div>
              <div>
                <h5 className="text-xs font-bold text-gray-900">${preset.brand.userName}</h5>
                <p className="text-[10px] text-gray-400 font-mono">${preset.brand.userMeta.split('\n')[0]}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 text-center text-xs gap-2">
              <div className="bg-slate-50 p-2 rounded">
                <div className="font-extrabold text-[#1e3a6e]">${preset.brand.userSinta}</div>
                <div className="text-[9px] text-gray-400">Metrics Score</div>
              </div>
              <div className="bg-slate-50 p-2 rounded">
                <div className="font-extrabold text-amber-600">${preset.brand.userRank}</div>
                <div className="text-[9px] text-gray-400">Rank</div>
              </div>
            </div>
          </div>
        </div>` : ''}

      </main>

    </div>
  );
}`;

  const generatedTailwindConfig = `// tailwind.config.js
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        themePrimaryBg: '${preset.config.primaryBg.includes('#') ? preset.config.primaryBg : '#1e3a6e'}',
        themeAccent: '${preset.config.accentColor || '#3b82f6'}',
      },
      borderRadius: {
        custom: '${controls.roundedMode === 'none' ? '0px' : controls.roundedMode === 'md' ? '6px' : controls.roundedMode === 'xl' ? '12px' : '20px'}',
      }
    },
  },
  plugins: [],
}`;

  const instructionsText = `### Cara Memasang Template Ini Ke Website Lain:

1. **Instalasi Lucide-React**:
   Jalankan perintah ini di file project React Anda untuk mengunduh semua SVG icon:
   \`\`\`bash
   npm install lucide-react
   \`\`\`

2. **Gunakan Kelas Tailwind Terkait**:
   Pastikan konfigurasi build tailwind sudah terpasang. Anda cukup menyalin file \`DashboardTemplate.tsx\` di atas dan meletakkannya di folder komponen Anda.
   
3. **Multi-Tema Dinamis**:
   Gaya layout ini sudah responsif secara penuh dari resolusi HP hingga monitor ultra-wide desktop. Struktur list-history dan detail tabel sudah dioptimalkan agar tidak pecah saat dimuat ke sistem apa pun (seperti Laravel, Next-JS, Rails, dll.)`;

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4 z-[999] overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden animate-scale-up">
        
        {/* Header Modal */}
        <div className="bg-[#1e3a6e] px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileCode className="w-5 h-5 text-amber-300" />
            <div>
              <h2 className="text-sm font-black uppercase tracking-wider">Ekspor Template Code HTML/JSX</h2>
              <p className="text-[11px] text-white/70 font-semibold">Siap pakai untuk semua website dengan framework apa pun</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            id="close-exporter-modal"
            className="p-1 text-white/75 hover:text-white bg-white/10 hover:bg-white/20 rounded transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex bg-slate-100 border-b border-gray-200">
          <button
            onClick={() => setActiveTab('jsx')}
            className={`flex items-center gap-1.5 text-xs font-bold px-5 py-3 cursor-pointer border-b-2 transition ${
              activeTab === 'jsx' ? 'border-[#1e3a6e] bg-white text-[#1e3a6e]' : 'border-transparent text-gray-500 hover:text-slate-800'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" /> JSX Component Code
          </button>
          
          <button
            onClick={() => setActiveTab('tailwind')}
            className={`flex items-center gap-1.5 text-xs font-bold px-5 py-3 cursor-pointer border-b-2 transition ${
              activeTab === 'tailwind' ? 'border-[#1e3a6e] bg-white text-[#1e3a6e]' : 'border-transparent text-gray-500 hover:text-slate-800'
            }`}
          >
            Tailwind Token Config
          </button>

          <button
            onClick={() => setActiveTab('usage')}
            className={`flex items-center gap-1.5 text-xs font-bold px-5 py-3 cursor-pointer border-b-2 transition ${
              activeTab === 'usage' ? 'border-[#1e3a6e] bg-white text-[#1e3a6e]' : 'border-transparent text-gray-500 hover:text-slate-800'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" /> Panduan Pasang
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6 flex-1 overflow-y-auto bg-slate-900 text-slate-100 font-mono text-xs leading-relaxed max-h-[50vh]">
          {activeTab === 'jsx' && (
            <div className="relative">
              <button
                onClick={() => handleCopy(generatedCodeJSX)}
                id="copy-jsx-btn"
                className="absolute top-2 right-2 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1 text-[10px] rounded flex items-center gap-1 border border-slate-700 cursor-pointer active:scale-95"
              >
                {copied ? <CheckCheck className="w-3 h-3 text-emerald-400 animate-bounce" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Berhasil Disalin!' : 'Copy Code'}</span>
              </button>
              <pre className="whitespace-pre overflow-x-auto text-[11px] leading-snug pt-6">{generatedCodeJSX}</pre>
            </div>
          )}

          {activeTab === 'tailwind' && (
            <div className="relative">
              <button
                onClick={() => handleCopy(generatedTailwindConfig)}
                id="copy-tw-btn"
                className="absolute top-2 right-2 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1 text-[10px] rounded flex items-center gap-1 border border-slate-700 cursor-pointer"
              >
                {copied ? <CheckCheck className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Disalin!' : 'Copy Config'}</span>
              </button>
              <pre className="whitespace-pre overflow-x-auto pt-6 text-[11.5px]">{generatedTailwindConfig}</pre>
            </div>
          )}

          {activeTab === 'usage' && (
            <div className="space-y-4 font-sans text-xs bg-slate-800 p-5 rounded-lg text-slate-200">
              <div className="whitespace-pre-line leading-relaxed text-sm">
                {instructionsText}
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="bg-gray-50 border-t border-gray-100 px-6 py-3 flex items-center justify-between">
          <span className="text-[10px] text-gray-400 font-semibold font-sans">© 2026 Simlitabmas Template Generator - LPPM ITSNU Pekalongan</span>
          <button
            onClick={onClose}
            id="close-exporter-bottom-btn"
            className="bg-gray-200 hover:bg-gray-300 text-gray-700 font-bold px-4 py-2 rounded text-xs transition cursor-pointer"
          >
            Tutup Jendela
          </button>
        </div>

      </div>
    </div>
  );
}
