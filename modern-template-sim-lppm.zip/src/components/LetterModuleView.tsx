import React, { useState, useMemo } from 'react';
import { ThemePreset, CustomControls } from '../types';
import { 
  FileText, Plus, HelpCircle, Eye, CheckCircle2, Clock, 
  Download, Printer, Users, Calendar, MapPin, Send, 
  Info, FileCheck, Search, Sparkles, Filter, MessageSquare, Trash2, UserPlus
} from 'lucide-react';

interface LetterModuleViewProps {
  preset: ThemePreset;
  controls: CustomControls;
}

interface LetterMember {
  nama: string;
  jabatan: string;
  nidn: string;
}

interface LetterRequest {
  id: string;
  nomorSurat: string;
  jenis: string;
  subjekKegiatan: string;
  mitraLokasi: string;
  status: 'Disetujui' | 'Direview' | 'Draf';
  tanggalPengajuan: string;
  reviewerNotes: string;
  
  // Official PDF parameters
  pemberiTugasNama: string;
  pemberiTugasJabatan: string;
  pemberiTugasAlamat: string;
  hariTanggal: string;
  waktu: string;
  tempat: string;
  ditetapkanDi: string;
  ditetapkanTanggal: string;
  members: LetterMember[];
  
  // SPPD fields
  arrivedAt: string;
  arrivedDate: string;
  returnedAt: string;
  returnedDate: string;
  signatorySPPD: string;
  sppdBumdesStamp: string;
}

interface LetterTemplate {
  id: string;
  title: string;
  description: string;
  stage: 'persiapan' | 'etik' | 'pelaksanaan' | 'pelaporan';
  stageLabel: string;
  stageIcon: string;
  requirements: string[];
  docFormat: 'DOCX' | 'PDF' | 'XLSX';
}

const letterTemplatesData: LetterTemplate[] = [
  // 1. Tahap Persiapan & Pengajuan
  {
    id: 'TPL-PP-01',
    title: 'Surat Pengantar dari Fakultas',
    description: 'Surat pengantar resmi yang diajukan oleh dosen ke LPPM melalui dekan fakultas untuk memulai pengajuan proposal penelitian atau pengabdian.',
    stage: 'persiapan',
    stageLabel: 'Tahap Persiapan & Pengajuan',
    stageIcon: '📝',
    requirements: ['Tanda Tangan Dekan', 'Kop Resmi Fakultas'],
    docFormat: 'DOCX'
  },
  {
    id: 'TPL-PP-02',
    title: 'Surat Permohonan Izin Penelitian/Pengabdian (Dari LPPM)',
    description: 'Surat permohonan resmi LPPM kepada instansi mitra lapangan untuk memohon izin pelaksanaan kegiatan riset atau abdimas di lokasi.',
    stage: 'persiapan',
    stageLabel: 'Tahap Persiapan & Pengajuan',
    stageIcon: '📝',
    requirements: ['Tanda Tangan Kepala LPPM', 'Stempel Basah LPPM'],
    docFormat: 'DOCX'
  },
  {
    id: 'TPL-PP-03',
    title: 'Surat Pernyataan Bebas Plagiat (Originalitas)',
    description: 'Pernyataan tertulis bermaterai oleh ketua pengusul yang menjamin keaslian karya ilmiah dan bebas dari segala unsur plagiarisme.',
    stage: 'persiapan',
    stageLabel: 'Tahap Persiapan & Pengajuan',
    stageIcon: '📝',
    requirements: ['Materai Rp 10.000', 'Tanda Tangan Ketua Peneliti'],
    docFormat: 'DOCX'
  },
  {
    id: 'TPL-PP-04',
    title: 'Surat Pernyataan Keaslian Penelitian / Karya / Dokumen',
    description: 'Menjamin keaslian data pendukung dan dokumen usulan proposal, produk inovasi, berkas HKI, maupun paten.',
    stage: 'persiapan',
    stageLabel: 'Tahap Persiapan & Pengajuan',
    stageIcon: '📝',
    requirements: ['Materai Rp 10.000', 'Tanda Tangan Pengusul'],
    docFormat: 'DOCX'
  },
  {
    id: 'TPL-PP-05',
    title: 'Surat Pernyataan Keterlibatan Mahasiswa',
    description: 'Mengakui kontribusi dan pembagian tanggung jawab mahasiswa di tim penelitian/pengabdian sebagai bagian pencapaian IKU.',
    stage: 'persiapan',
    stageLabel: 'Tahap Persiapan & Pengajuan',
    stageIcon: '📝',
    requirements: ['Tanda Tangan Dosen Pembimbing', 'NIM & Tanda Tangan Mahasiswa'],
    docFormat: 'DOCX'
  },
  {
    id: 'TPL-PP-06',
    title: 'Surat Pernyataan Kesediaan',
    description: 'Pernyataan komitmen dosen/peneliti bersangkutan untuk mengikuti seluruh rangkaian proses hibah LPPM dari awal hingga akhir selesai.',
    stage: 'persiapan',
    stageLabel: 'Tahap Persiapan & Pengajuan',
    stageIcon: '📝',
    requirements: ['Tanda Tangan Peneliti'],
    docFormat: 'DOCX'
  },

  // 2. Tahap Pengajuan Etik (Khusus Penelitian Sensitif)
  {
    id: 'TPL-ET-01',
    title: 'Surat Permohonan Etik',
    description: 'Diajukan ke komite etik (ethical clearance) khusus untuk penelitian sensitif yang melibatkan manusia, hewan, atau data medis.',
    stage: 'etik',
    stageLabel: 'Tahap Pengajuan Etik',
    stageIcon: '⚕️',
    requirements: ['Prosedur Penelitian Rinci', 'Form Persetujuan Kelaikan Etik'],
    docFormat: 'DOCX'
  },
  {
    id: 'TPL-ET-02',
    title: 'Surat Persetujuan Subjek (Informed Consent)',
    description: 'Pernyataan persetujuan tertulis dari partisipan setelah diberikan penjelasan lengkap mengenai manfaat dan risiko keikutsertaan.',
    stage: 'etik',
    stageLabel: 'Tahap Pengajuan Etik',
    stageIcon: '⚕️',
    requirements: ['Pemberian Informasi Jelas', 'Tanda Tangan Responden'],
    docFormat: 'DOCX'
  },
  {
    id: 'TPL-ET-03',
    title: 'Curriculum Vitae (CV) Peneliti Utama dan Anggota',
    description: 'Daftar riwayat hidup tim pengusul yang memuat track record publikasi ilmiah, ID SINTA, Scopus, dan riwayat hibah sebelumnya.',
    stage: 'etik',
    stageLabel: 'Tahap Pengajuan Etik',
    stageIcon: '⚕️',
    requirements: ['SINTA ID & Scopus ID', 'Daftar Publikasi 5 Tahun Terakhir'],
    docFormat: 'DOCX'
  },

  // 3. Tahap Pelaksanaan & Perizinan
  {
    id: 'TPL-PL-01',
    title: 'Surat Tugas Pelaksanaan',
    description: 'Surat tugas dinas resmi dari LPPM sebagai legalitas utama dosen pelaksana lapangan untuk riset dan abdimas.',
    stage: 'pelaksanaan',
    stageLabel: 'Tahap Pelaksanaan & Perizinan',
    stageIcon: '🤝',
    requirements: ['Kop LPPM & Nomor Resmi', 'Tanda Tangan e-TTE LPPM'],
    docFormat: 'PDF'
  },
  {
    id: 'TPL-PL-02',
    title: 'Surat Tugas kepada Mahasiswa',
    description: 'Mandat penugasan resmi bagi mahasiswa yang terlibat membantu proyek penelitian/pengabdian dosen pelaksana.',
    stage: 'pelaksanaan',
    stageLabel: 'Tahap Pelaksanaan & Perizinan',
    stageIcon: '🤝',
    requirements: ['Tanda Tangan Dekan / LPPM'],
    docFormat: 'DOCX'
  },
  {
    id: 'TPL-PL-03',
    title: 'Surat Tugas Reviewer / SK Penunjukan Reviewer',
    description: 'SK penunjukan tim penilai independen ahli (reviewer internal/eksternal) untuk proposal seleksi hibah atau monitoring dan evaluasi.',
    stage: 'pelaksanaan',
    stageLabel: 'Tahap Pelaksanaan & Perizinan',
    stageIcon: '🤝',
    requirements: ['Keputusan Rektor / Kepala LPPM', 'Tanda Tangan Pimpinan'],
    docFormat: 'PDF'
  },
  {
    id: 'TPL-PL-04',
    title: 'Surat Perjanjian Penugasan / Kontrak Penelitian',
    description: 'Kontrak hukum formal mengenai jumlah bantuan dana hibah, komitmen luaran, serta hak dan kewajiban pelaksana bermaterai.',
    stage: 'pelaksanaan',
    stageLabel: 'Tahap Pelaksanaan & Perizinan',
    stageIcon: '🤝',
    requirements: ['Materai Rp 10.000', 'Tanda Tangan Dosen & Pihak LPPM'],
    docFormat: 'DOCX'
  },
  {
    id: 'TPL-PL-05',
    title: 'Lembar Pengesahan Proposal',
    description: 'Lembaran persetujuan akhir kelayakan administratif proposal sebelum diserahkan ke sistem SIMlitabmas / BIMA Dikti.',
    stage: 'pelaksanaan',
    stageLabel: 'Tahap Pelaksanaan & Perizinan',
    stageIcon: '🤝',
    requirements: ['Tanda Tangan Dekan', 'Tanda Tangan Kepala LPPM'],
    docFormat: 'DOCX'
  },

  // 4. Tahap Pelaporan & Pertanggungjawaban
  {
    id: 'TPL-LP-01',
    title: 'Surat Keterangan Penelitian',
    description: 'Diterbitkan LPPM sebagai bukti sah bahwa dosen/peneliti telah melaksanakan kegiatan Tri Dharma secara paripurna.',
    stage: 'pelaporan',
    stageLabel: 'Tahap Pelaporan & Pertanggungjawaban',
    stageIcon: '📄',
    requirements: ['Tanda Tangan Kepala LPPM', 'Stempel Basah LPPM'],
    docFormat: 'PDF'
  },
  {
    id: 'TPL-LP-02',
    title: 'Surat Pernyataan Tanggung Jawab Belanja (SPTB)',
    description: 'Pernyataan kebenaran penggunaan anggaran hibah yang dicocokkan dengan bukti belanja valid sesuai pedoman SBU.',
    stage: 'pelaporan',
    stageLabel: 'Tahap Pelaporan & Pertanggungjawaban',
    stageIcon: '📄',
    requirements: ['Materai Rp 10.000', 'Tanda Tangan Pengusul / Peneliti'],
    docFormat: 'DOCX'
  },
  {
    id: 'TPL-LP-03',
    title: 'Berita Acara Serah Terima Laporan Kemajuan/Akhir',
    description: 'Lembaran berita acara penyerahan dokumen laporan kemajuan maupun laporan akhir riset/pengabdian ke LPPM bermaterai.',
    stage: 'pelaporan',
    stageLabel: 'Tahap Pelaporan & Pertanggungjawaban',
    stageIcon: '📄',
    requirements: ['Dua Belah Pihak', 'Materai Rp 10.000'],
    docFormat: 'DOCX'
  },
  {
    id: 'TPL-LP-04',
    title: 'Berita Acara Serah Terima Barang (BASTB)',
    description: 'Menyerahkan kepemilikan aset/alat hasil keluaran hibah riset kepada LPPM, laboratorium unit, ataupun pihak mitra luar.',
    stage: 'pelaporan',
    stageLabel: 'Tahap Pelaporan & Pertanggungjawaban',
    stageIcon: '📄',
    requirements: ['Tanda Tangan Pihak I & Pihak II', 'Saksi Inventaris'],
    docFormat: 'DOCX'
  },
  {
    id: 'TPL-LP-05',
    title: 'Laporan Akhir Penelitian',
    description: 'Dokumen utama akumulasi hasil riset secara komprehensif mulai dari capaian target, pengujian hasil, dan rincian abdimas.',
    stage: 'pelaporan',
    stageLabel: 'Tahap Pelaporan & Pertanggungjawaban',
    stageIcon: '📄',
    requirements: ['Format Buku Laporan LPPM', 'Tanda Tangan Tim Peneliti'],
    docFormat: 'DOCX'
  },
  {
    id: 'TPL-LP-06',
    title: 'Luaran Wajib',
    description: 'Lampiran naskah luaran wajib publikasi artikel ilmiah jurnal (LoA), prosiding nasional/internasional, atau sertifikat HKI.',
    stage: 'pelaporan',
    stageLabel: 'Tahap Pelaporan & Pertanggungjawaban',
    stageIcon: '📄',
    requirements: ['Letter of Acceptance (LoA)', 'Sertifikat Pendaftaran HKI'],
    docFormat: 'DOCX'
  }
];

export default function LetterModuleView({ preset, controls }: LetterModuleViewProps) {
  const subTabs = ['Arsip Surat Tugas', 'Ajukan Surat Baru', 'Kumpulan Format Surat', 'Verifikasi LPPM', 'Panduan Administrasi'];
  const [activeSubTab, setActiveSubTab] = useState<number>(0);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [filterYear, setFilterYear] = useState('25'); // Matches 2025/VII
  const [tplSearch, setTplSearch] = useState('');
  const [selectedStage, setSelectedStage] = useState<string>('all');
  
  const [selectedLetterId, setSelectedLetterId] = useState<string>('SRT-169');
  const [notification, setNotification] = useState<string | null>(null);

  const colors = preset.config;
  const roundedClass = 
    controls.roundedMode === 'none' ? 'rounded-none' :
    controls.roundedMode === 'md' ? 'rounded-md' :
    controls.roundedMode === 'xl' ? 'rounded-xl' : 'rounded-2xl';

  // Initial persistent mock state seeded with the EXACT document provided in the PDF!
  const [letters, setLetters] = useState<LetterRequest[]>([
    {
      id: "SRT-169",
      nomorSurat: "169/ST/LPPM/ITSNU.Pkl/VII/2025",
      jenis: "Surat Tugas Pengabdian",
      subjekKegiatan: "Pemberdayaan BUMDes Jaya Mandiri melalui Implementasi aplikasi sistem informasi manajemen dan Kreativitas Kewirausahaan untuk Meningkatkan Ekonomi Desa",
      mitraLokasi: "BUMDes Jaya Mandiri",
      status: "Disetujui",
      tanggalPengajuan: "22 Juli 2025",
      reviewerNotes: "HASIL KLONING PDF REPLIKA: Seluruh nama dosen, mahasiswa, nomor surat dinas, penanggalan, lokasi Coffe Teman Cerita, sertifikat stempel basah BUMDes, serta tanda tangan Dr. Aria Mulyapradana, S.Psi., M.A. telah digenerasikan seutuhnya sesuai bukti fisik Surat Tugas Dinas Pekalongan.",
      pemberiTugasNama: "Aria Mulyapradana, S.Psi., M.A.",
      pemberiTugasJabatan: "Kepala LPPM ITSNU Pekalongan",
      pemberiTugasAlamat: "Jl. Karangdowo No. 9 Kedungwuni Pekalongan",
      hariTanggal: "Jum’at, 25 Juli 2025",
      waktu: "11.00 WIB s.d. selesai",
      tempat: "Coffe Teman Cerita",
      ditetapkanDi: "Pekalongan",
      ditetapkanTanggal: "22 Juli 2025",
      members: [
        { nama: "Mujibul Hakim, S.Kom, M.M.", jabatan: "Dosen", nidn: "0608068901" },
        { nama: "Amalia Fitri Mustafida, S.T., M.Sc.", jabatan: "Dosen", nidn: "8850775676230212" },
        { nama: "Hafis Ghulam, S.Pd., M.Pd.", jabatan: "Dosen", nidn: "0627088203" },
        { nama: "Kholiqurrofi", jabatan: "Mahasiswa", nidn: "103220001" },
        { nama: "Meliyana Nabila", jabatan: "Mahasiswa", nidn: "101230044" },
        { nama: "Ariani Talitha Nevi", jabatan: "Mahasiswa", nidn: "101230028" },
        { nama: "Irmayanti", jabatan: "Direktur BUMDes", nidn: "-" }
      ],
      arrivedAt: "Coffe Teman Cerita",
      arrivedDate: "Jum’at, 25 Juli 2025",
      returnedAt: "ITSNU Pekalongan",
      returnedDate: "Jum’at, 25 Juli 2025",
      signatorySPPD: "Irmayanti",
      sppdBumdesStamp: "BUMDES JAYA MANDIRI"
    },
    {
      id: "SRT-041",
      nomorSurat: "084/LPPM/ITSNU/VI/2026",
      jenis: "Surat Tugas Penelitian",
      subjekKegiatan: "Sistem Rekomendasi Motif Batik Berbasis Large Language Model dan Knowledge Base untuk UMKM Pekalongan",
      mitraLokasi: "Koperasi Batik Berkah Jaya Selaras",
      status: "Disetujui",
      tanggalPengajuan: "09 Juni 2026",
      reviewerNotes: "Surat tugas resmi riset mandiri telah divalidasi keabsahan data kemitraannya. Nomor surat tercetak sah. QR Code digital tersemat.",
      pemberiTugasNama: "Aria Mulyapradana, S.Psi., M.A.",
      pemberiTugasJabatan: "Kepala LPPM ITSNU Pekalongan",
      pemberiTugasAlamat: "Jl. Karangdowo No. 9 Kedungwuni Pekalongan",
      hariTanggal: "Senin, 20 Juni 2026",
      waktu: "09.00 WIB s.d. selesai",
      tempat: "Koperasi Batik Berkah Jaya Selaras, Pekalongan",
      ditetapkanDi: "Pekalongan",
      ditetapkanTanggal: "09 Juni 2026",
      members: [
        { nama: "Mujibul Hakim, S.Kom, M.M.", jabatan: "Dosen", nidn: "0608068901" },
        { nama: "Amalia Fitri Mustafida, S.T., M.Sc.", jabatan: "Dosen", nidn: "8850775676230212" }
      ],
      arrivedAt: "Koperasi Batik Berkah Jaya Selaras",
      arrivedDate: "Senin, 20 Juni 2026",
      returnedAt: "ITSNU Pekalongan",
      returnedDate: "Senin, 20 Juni 2026",
      signatorySPPD: "H. Ahmad Fauzi",
      sppdBumdesStamp: "KOP BATIK BERKAH JAYA"
    },
    {
      id: "SRT-043",
      nomorSurat: "PENDING-01",
      jenis: "Surat Izin Survei Penelitian",
      subjekKegiatan: "Studi Etnografi Pola Tenun Tradisional di Pesisir Pekalongan Utara",
      mitraLokasi: "Kampung Budaya Krapyak Kidul",
      status: "Direview",
      tanggalPengajuan: "11 Juni 2026",
      reviewerNotes: "Berkas sedang diperiksa oleh Kepala LPPM. Harap pastikan proposal survei telah diunggah di modul penelitian.",
      pemberiTugasNama: "Aria Mulyapradana, S.Psi., M.A.",
      pemberiTugasJabatan: "Kepala LPPM ITSNU Pekalongan",
      pemberiTugasAlamat: "Jl. Karangdowo No. 9 Kedungwuni Pekalongan",
      hariTanggal: "Rabu, 01 Juli 2026",
      waktu: "10.00 WIB s.d. selesai",
      tempat: "Kampung Budaya Krapyak Kidul, Pekalongan IPTEK",
      ditetapkanDi: "Pekalongan",
      ditetapkanTanggal: "11 Juni 2026",
      members: [
        { nama: "Hafis Ghulam, S.Pd., M.Pd.", jabatan: "Dosen", nidn: "0627088203" },
        { nama: "Ariani Talitha Nevi", jabatan: "Mahasiswa", nidn: "101230028" }
      ],
      arrivedAt: "Kampung Budaya Krapyak",
      arrivedDate: "Rabu, 01 Juli 2026",
      returnedAt: "ITSNU Pekalongan",
      returnedDate: "Rabu, 01 Juli 2026",
      signatorySPPD: "Suryo Atmojo",
      sppdBumdesStamp: "PAGUYUBAN DESA KRAPYAK"
    }
  ]);

  // Form Fields State matches official rich fields with robust Defaults
  const [formData, setFormData] = useState({
    jenis: 'Surat Tugas Pengabdian' as LetterRequest['jenis'],
    nomorSurat: '170/ST/LPPM/ITSNU.Pkl/VII/2026',
    subjekKegiatan: 'Pemberdayaan UMKM Batik Kedungwuni Melalui Digitalisasi Akuntansi Keuangan Berbasis Android',
    mitraLokasi: 'Kelompok Batik Sido Mukti',
    tanggalPengajuan: '12 Juni 2026',
    hariTanggal: 'Senin, 22 Juni 2026',
    waktu: '09.00 WIB s.d. selesai',
    tempat: 'Kencana Hall, Kedungwuni Pekalongan',
    ditetapkanDi: 'Pekalongan',
    ditetapkanTanggal: '12 Juni 2026',
    pemberiTugasNama: 'Aria Mulyapradana, S.Psi., M.A.',
    pemberiTugasJabatan: 'Kepala LPPM ITSNU Pekalongan',
    pemberiTugasAlamat: 'Jl. Karangdowo No. 9 Kedungwuni Pekalongan',
    arrivedAt: 'Kelompok Batik Sido Mukti',
    arrivedDate: 'Senin, 22 Juni 2026',
    returnedAt: 'ITSNU Pekalongan',
    returnedDate: 'Senin, 22 Juni 2026',
    signatorySPPD: 'Irmayanti',
    sppdBumdesStamp: 'BATIK SIDO MUKTI',
    
    // Dynamic people roster starting with current user
    members: [
      { nama: preset.brand.userName, jabatan: 'Dosen', nidn: '0608068901' },
      { nama: 'Zulfa Hanum, S.Kom.', jabatan: 'Staf', nidn: '109988112' }
    ] as LetterMember[]
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.subjekKegiatan || !formData.mitraLokasi || !formData.nomorSurat) {
      alert("Harap lengkapi nomor surat, subjek kegiatan, dan mitra lokasi!");
      return;
    }

    const randomID = `SRT-${Math.floor(100 + Math.random() * 900)}`;
    const newLetter: LetterRequest = {
      id: randomID,
      nomorSurat: formData.nomorSurat,
      jenis: formData.jenis,
      subjekKegiatan: formData.subjekKegiatan,
      mitraLokasi: formData.mitraLokasi,
      status: 'Draf',
      tanggalPengajuan: formData.tanggalPengajuan,
      reviewerNotes: "Draf divalidasi mandiri. Verifikasi LPPM sedang dalam antrean tanda tangan elektronik Kepala LPPM Pekalongan.",
      
      pemberiTugasNama: formData.pemberiTugasNama,
      pemberiTugasJabatan: formData.pemberiTugasJabatan,
      pemberiTugasAlamat: formData.pemberiTugasAlamat,
      hariTanggal: formData.hariTanggal,
      waktu: formData.waktu,
      tempat: formData.tempat,
      ditetapkanDi: formData.ditetapkanDi,
      ditetapkanTanggal: formData.ditetapkanTanggal,
      members: [...formData.members],
      
      arrivedAt: formData.arrivedAt,
      arrivedDate: formData.arrivedDate,
      returnedAt: formData.returnedAt,
      returnedDate: formData.returnedDate,
      signatorySPPD: formData.signatorySPPD,
      sppdBumdesStamp: formData.sppdBumdesStamp
    };

    setLetters([newLetter, ...letters]);
    setSelectedLetterId(randomID);
    setActiveSubTab(0);
    
    // Reset Form to initial premium state
    setFormData({
      jenis: 'Surat Tugas Pengabdian',
      nomorSurat: '171/ST/LPPM/ITSNU.Pkl/VII/2026',
      subjekKegiatan: '',
      mitraLokasi: '',
      tanggalPengajuan: '12 Juni 2026',
      hariTanggal: 'Senin, 22 Juni 2026',
      waktu: '09.00 WIB s.d. selesai',
      tempat: 'BUMDes Jaya Mandiri',
      ditetapkanDi: 'Pekalongan',
      ditetapkanTanggal: '12 Juni 2026',
      pemberiTugasNama: 'Aria Mulyapradana, S.Psi., M.A.',
      pemberiTugasJabatan: 'Kepala LPPM ITSNU Pekalongan',
      pemberiTugasAlamat: 'Jl. Karangdowo No. 9 Kedungwuni Pekalongan',
      arrivedAt: 'BUMDes Jaya Mandiri',
      arrivedDate: 'Senin, 22 Juni 2026',
      returnedAt: 'ITSNU Pekalongan',
      returnedDate: 'Senin, 22 Juni 2026',
      signatorySPPD: 'Irmayanti',
      sppdBumdesStamp: 'BUMDES JAYA MANDIRI',
      members: [
        { nama: preset.brand.userName, jabatan: 'Dosen', nidn: '0608068901' }
      ]
    });

    triggerToast("Berhasil meregistrasikan Surat Tugas Baru! Klik di tabel arsip untuk melihat pratinjau replika cetak PDF.");
  };

  const triggerToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(null);
    }, 5000);
  };

  const handlePrint = () => {
    window.print();
  };

  const selectedLetter = useMemo(() => {
    return letters.find(l => l.id === selectedLetterId) || letters[0];
  }, [letters, selectedLetterId]);

  const filteredLetters = useMemo(() => {
    return letters.filter(letter => {
      const matchSearch = 
        letter.jenis.toLowerCase().includes(searchQuery.toLowerCase()) ||
        letter.subjekKegiatan.toLowerCase().includes(searchQuery.toLowerCase()) ||
        letter.mitraLokasi.toLowerCase().includes(searchQuery.toLowerCase()) ||
        letter.nomorSurat.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchYear = letter.tanggalPengajuan.includes(filterYear) || letter.nomorSurat.includes(filterYear);
      return matchSearch && (filterYear === '' || letter.tanggalPengajuan.toLowerCase().includes(filterYear.toLowerCase()) || letter.nomorSurat.toLowerCase().includes(filterYear.toLowerCase()));
    });
  }, [letters, searchQuery, filterYear]);

  return (
    <div className={`space-y-4 ${controls.layoutMode === 'compact' ? 'space-y-3' : 'space-y-4'}`}>
      
      {/* Print styles inserted dynamically to fit paper replica to standard A4 view */}
      <style dangerouslySetInnerHTML={{__html: `
        @media print {
          body * {
            visibility: hidden;
          }
          #print-area-wrapper, #print-area-wrapper * {
            visibility: visible;
          }
          #print-area-wrapper {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            background: white !important;
            padding: 0 !important;
          }
        }
      `}} />

      {/* Dynamic Toast Notification */}
      {notification && (
        <div className="p-3 bg-emerald-50 border-l-4 border-emerald-500 rounded text-xs text-emerald-800 font-bold flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-4.5 h-4.5 text-emerald-600 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* 1. Aligned TOP Sub-Navigation Tab Bar */}
      <div className="border-b border-gray-200 overflow-x-auto select-none scrollbar-none">
        <div className="flex gap-1.5 min-w-max pb-0.5">
          {subTabs.map((tab, idx) => {
            const isActive = activeSubTab === idx;
            return (
              <button
                key={idx}
                onClick={() => {
                  setActiveSubTab(idx);
                }}
                className={`text-xs px-3.5 py-2 font-semibold transition border-b-2 whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'border-[#1e3a6e] text-[#1e3a6e] font-extrabold'
                    : 'border-transparent text-gray-500 hover:text-[#1e3a6e]'
                }`}
              >
                ✉️ {tab}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Aligned Form Filter & Info Utility Bar */}
      <div className="flex flex-col sm:flex-row gap-3 justify-between items-stretch sm:items-center">
        <div className="flex gap-2">
          <button 
            onClick={() => alert(`Format Surat Tugas LPPM ITSNU Pekalongan: Ditetapkan sesuai SOP Penyelenggaraan Riset dan Abdimas. Semua format surat resmi mengadopsi e-TTE berkode pengaman LPPM.`)}
            className="flex items-center gap-1 bg-green-700 hover:bg-green-800 text-white text-[11px] font-bold px-3 py-1.5 rounded transition shadow-xs cursor-pointer shrink-0"
          >
            <Info className="w-3.5 h-3.5" />
            <span>Format Surat ITSNU</span>
          </button>
          
          {/* Quick search input */}
          <div className="relative w-full sm:w-64 flex">
            <span className="absolute inset-y-0 left-0 flex items-center pl-2.5 pointer-events-none">
              <Search className="h-3.5 h-3.5 text-gray-400" />
            </span>
            <input
              type="text"
              placeholder="Cari surat, subjek, nomor, mitra..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs bg-white border border-gray-200 rounded py-1.5 pl-8 pr-3 outline-none text-gray-700 focus:border-green-500 focus:ring-1 focus:ring-green-100 placeholder:text-gray-400"
            />
          </div>
        </div>

        {/* Filter Inputs right aligned matching TableView */}
        <div className="flex items-center gap-2 justify-end">
          <span className="text-[10px] sm:text-xs font-bold text-gray-600 uppercase tracking-wide flex items-center gap-1 shrink-0">
            <Filter className="w-3 h-3 text-[#1e3a6e]" /> Filter Periode:
          </span>
          <div className="flex items-center gap-1.5 bg-white border border-gray-200 rounded px-2 py-1 shadow-2xs">
            <select
              value={filterYear}
              onChange={(e) => setFilterYear(e.target.value)}
              className="text-xs font-bold text-slate-800 outline-none bg-transparent"
            >
              <option value="25">Periode 2025 (Kloning PDF)</option>
              <option value="26">Periode 2026 (SINTA)</option>
              <option value="">Tampilkan Semua</option>
            </select>
          </div>
        </div>
      </div>

      {activeSubTab === 1 ? (
        /* PANEL 1: AJUKAN SURAT BARU FORM (WITH EXPLICIT ROSTER EDITING IN REALTIME!) */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white text-left border border-gray-200 p-6 rounded-xl shadow-xs space-y-4">
            <div className="border-b border-gray-100 pb-3">
              <h3 className="text-xs font-black text-gray-800 uppercase tracking-wider flex items-center gap-1.5">
                📝 Registrasi & Terbitkan Surat Dinas Baru
              </h3>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              
              {/* Box 1: Nomor & Jenis */}
              <div className="p-4 bg-slate-50 border rounded-lg space-y-3">
                <span className="text-[10px] font-black text-green-800 uppercase tracking-wider block">
                  ⚙️ 1. Identifikasi Surat Dinas LPPM
                </span>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="font-extrabold text-gray-700 uppercase text-[9px]">Jenis Surat Dinas</label>
                    <select
                      value={formData.jenis}
                      onChange={(e) => setFormData({...formData, jenis: e.target.value})}
                      className="w-full bg-white border border-gray-200 p-2.5 rounded font-bold text-gray-800"
                    >
                      <optgroup label="📝 TAHAP PERSIAPAN & PENGAJUAN">
                        <option value="Surat Pengantar dari Fakultas">Surat Pengantar dari Fakultas</option>
                        <option value="Surat Permohonan Izin Penelitian/Pengabdian (Dari LPPM)">Surat Permohonan Izin Penelitian/Pengabdian (Dari LPPM)</option>
                        <option value="Surat Pernyataan Bebas Plagiat (Originalitas)">Surat Pernyataan Bebas Plagiat (Originalitas)</option>
                        <option value="Surat Pernyataan Keaslian Penelitian / Karya / Dokumen">Surat Pernyataan Keaslian Penelitian / Karya / Dokumen</option>
                        <option value="Surat Pernyataan Keterlibatan Mahasiswa">Surat Pernyataan Keterlibatan Mahasiswa</option>
                        <option value="Surat Pernyataan Kesediaan">Surat Pernyataan Kesediaan</option>
                      </optgroup>
                      <optgroup label="⚕️ TAHAP PENGAJUAN ETIK">
                        <option value="Surat Permohonan Etik">Surat Permohonan Etik</option>
                        <option value="Surat Persetujuan Subjek (Informed Consent)">Surat Persetujuan Subjek (Informed Consent)</option>
                        <option value="Curriculum Vitae (CV) Peneliti Utama dan Anggota">Curriculum Vitae (CV) Peneliti Utama dan Anggota</option>
                      </optgroup>
                      <optgroup label="🤝 TAHAP PELAKSANAAN & PERIZINAN">
                        <option value="Surat Tugas Pelaksanaan">Surat Tugas Pelaksanaan</option>
                        <option value="Surat Tugas kepada Mahasiswa">Surat Tugas kepada Mahasiswa</option>
                        <option value="Surat Tugas Reviewer / SK Penunjukan Reviewer">Surat Tugas Reviewer / SK Penunjukan Reviewer</option>
                        <option value="Surat Perjanjian Penugasan / Kontrak Penelitian">Surat Perjanjian Penugasan / Kontrak Penelitian</option>
                        <option value="Lembar Pengesahan Proposal">Lembar Pengesahan Proposal</option>
                      </optgroup>
                      <optgroup label="📄 TAHAP PELAPORAN & PERTANGGUNGJAWABAN">
                        <option value="Surat Keterangan Penelitian">Surat Keterangan Penelitian</option>
                        <option value="Surat Pernyataan Tanggung Jawab Belanja (SPTB)">Surat Pernyataan Tanggung Jawab Belanja (SPTB)</option>
                        <option value="Berita Acara Serah Terima Laporan Kemajuan/Akhir">Berita Acara Serah Terima Laporan Kemajuan/Akhir</option>
                        <option value="Berita Acara Serah Terima Barang (BASTB)">Berita Acara Serah Terima Barang (BASTB)</option>
                        <option value="Laporan Akhir Penelitian">Laporan Akhir Penelitian</option>
                        <option value="Luaran Wajib">Luaran Wajib</option>
                      </optgroup>
                      <optgroup label="💼 WARISAN / JENIS SURAT LAINNYA">
                        <option value="Surat Tugas Pengabdian">Surat Tugas Kegiatan Pengabdian</option>
                        <option value="Surat Tugas Penelitian">Surat Tugas Kegiatan Penelitian</option>
                        <option value="Surat Izin Survei Penelitian">Surat Pengantar Izin Survei Lapangan</option>
                        <option value="Surat Keterangan Pengabdian">Surat Keterangan Kemitraan Abdimas</option>
                      </optgroup>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="font-extrabold text-gray-700 uppercase text-[9px]">Nomor Surat Dinas Resmi</label>
                    <input
                      type="text"
                      placeholder="Contoh: 169/ST/LPPM/ITSNU.Pkl/VII/2025"
                      value={formData.nomorSurat}
                      onChange={(e) => setFormData({...formData, nomorSurat: e.target.value})}
                      className="w-full bg-white border border-gray-200 p-2.5 rounded font-mono font-bold text-gray-800"
                    />
                  </div>
                </div>
              </div>

              {/* Box 2: Detail Kegiatan */}
              <div className="p-4 bg-emerald-50/10 border border-green-100 rounded-lg space-y-3">
                <span className="text-[10px] font-black text-[#1e3a6e] uppercase tracking-wider block">
                  🎯 2. Deskripsi Mandat Tri Dharma
                </span>

                <div className="space-y-1">
                  <label className="font-extrabold text-gray-700 uppercase text-[9px]">Judul Kegiatan / Nama Program Pengabdian</label>
                  <textarea
                    rows={2}
                    placeholder="Contoh: Pemberdayaan BUMDes Jaya Mandiri melalui Implementasi aplikasi sistem..."
                    value={formData.subjekKegiatan}
                    onChange={(e) => setFormData({...formData, subjekKegiatan: e.target.value})}
                    className="w-full border border-gray-200 p-2.5 rounded text-gray-800 placeholder:text-gray-400 font-medium"
                  ></textarea>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="font-extrabold text-gray-700 uppercase text-[9px]">Mitra Utama / Lokasi Utama</label>
                    <input
                      type="text"
                      placeholder="Contoh: BUMDes Jaya Mandiri"
                      value={formData.mitraLokasi}
                      onChange={(e) => setFormData({...formData, mitraLokasi: e.target.value})}
                      className="w-full border border-gray-200 p-2.5 rounded text-gray-800"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="font-extrabold text-gray-700 uppercase text-[9px]">Hari, Tanggal</label>
                    <input
                      type="text"
                      placeholder="Contoh: Jum’at, 25 Juli 2025"
                      value={formData.hariTanggal}
                      onChange={(e) => setFormData({...formData, hariTanggal: e.target.value})}
                      className="w-full border border-gray-200 p-2.5 rounded text-gray-800 font-bold"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="font-extrabold text-gray-700 uppercase text-[9px]">Waktu Pelaksanaan</label>
                    <input
                      type="text"
                      placeholder="Contoh: 11.00 WIB s.d. selesai"
                      value={formData.waktu}
                      onChange={(e) => setFormData({...formData, waktu: e.target.value})}
                      className="w-full border border-gray-200 p-2.5 rounded text-gray-800"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="font-extrabold text-gray-700 uppercase text-[9px]">Tempat Pertemuan</label>
                    <input
                      type="text"
                      placeholder="Contoh: Coffe Teman Cerita"
                      value={formData.tempat}
                      onChange={(e) => setFormData({...formData, tempat: e.target.value})}
                      className="w-full border border-gray-200 p-2.5 rounded text-gray-800"
                    />
                  </div>
                </div>
              </div>

              {/* Box 3: Penerima Tugas - Multi-member system editor */}
              <div className="p-4 bg-white border border-gray-200 rounded-lg space-y-3.5">
                <div className="flex justify-between items-center border-b pb-2">
                  <span className="text-[10px] font-black text-indigo-900 uppercase tracking-wider block">
                    👥 3. Personel Tim Penerima Tugas
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setFormData({
                        ...formData,
                        members: [...formData.members, { nama: '', jabatan: 'Dosen', nidn: '' }]
                      });
                    }}
                    className="px-2 py-1 bg-green-50 hover:bg-green-100 text-green-700 border border-green-200 rounded font-black text-[9px] flex items-center gap-1.5 cursor-pointer"
                  >
                    <UserPlus className="w-3 h-3 text-green-600" />
                    <span>Tambah Personel</span>
                  </button>
                </div>

                <div className="space-y-2.5">
                  {formData.members.map((member, idx) => (
                    <div key={idx} className="grid grid-cols-1 md:grid-cols-12 gap-2 bg-slate-50/50 p-2 border border-gray-150 rounded relative items-center">
                      <div className="md:col-span-5">
                        <label className="text-[8px] font-bold text-gray-400 block mb-0.5">Nama Lengkap & Gelar</label>
                        <input
                          type="text"
                          placeholder="Mujibul Hakim, S.Kom, M.M."
                          value={member.nama}
                          onChange={(e) => {
                            const updated = [...formData.members];
                            updated[idx].nama = e.target.value;
                            setFormData({ ...formData, members: updated });
                          }}
                          className="w-full bg-white border border-gray-200 px-2 py-1.5 rounded text-[11px] font-bold text-gray-850"
                        />
                      </div>
                      
                      <div className="md:col-span-3">
                        <label className="text-[8px] font-bold text-gray-400 block mb-0.5">Jabatan Tugas</label>
                        <select
                          value={member.jabatan}
                          onChange={(e) => {
                            const updated = [...formData.members];
                            updated[idx].jabatan = e.target.value;
                            setFormData({ ...formData, members: updated });
                          }}
                          className="w-full bg-white border border-gray-200 px-2 py-1.5 rounded text-[11px] font-semibold text-gray-800"
                        >
                          <option value="Dosen">Dosen</option>
                          <option value="Mahasiswa">Mahasiswa</option>
                          <option value="Staf">Staf LPPM</option>
                          <option value="Direktur BUMDes">Direktur BUMDes</option>
                          <option value="Asisten Riset">Asisten Riset</option>
                        </select>
                      </div>

                      <div className="md:col-span-3">
                        <label className="text-[8px] font-bold text-gray-400 block mb-0.5">NIDN / NIM / KPD</label>
                        <input
                          type="text"
                          placeholder="E.g. 0608068901"
                          value={member.nidn}
                          onChange={(e) => {
                            const updated = [...formData.members];
                            updated[idx].nidn = e.target.value;
                            setFormData({ ...formData, members: updated });
                          }}
                          className="w-full bg-white border border-gray-200 px-2 py-1.5 rounded text-[11px] font-mono text-gray-750"
                        />
                      </div>

                      <div className="md:col-span-1 text-center self-end pb-1">
                        <button
                          type="button"
                          disabled={formData.members.length <= 1}
                          onClick={() => {
                            const updated = formData.members.filter((_, mIdx) => mIdx !== idx);
                            setFormData({ ...formData, members: updated });
                          }}
                          className="p-1 hover:bg-red-50 text-red-500 rounded transition disabled:opacity-30 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Box 4: SPPD & Stamp Footer detail configurator */}
              <div className="p-4 bg-sky-50/15 border border-sky-100 rounded-lg space-y-3">
                <span className="text-[10px] font-black text-sky-900 uppercase tracking-wider block">
                  📍 4. Parameter SPPD & Pengesahan BUMDes
                </span>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="space-y-1">
                    <label className="font-extrabold text-gray-700 uppercase text-[9px]">Tiba di Tujuan</label>
                    <input
                      type="text"
                      value={formData.arrivedAt}
                      onChange={(e) => setFormData({...formData, arrivedAt: e.target.value})}
                      className="w-full border border-gray-200 p-2 rounded text-gray-800"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-extrabold text-gray-700 uppercase text-[9px]">Tanggal Tiba</label>
                    <input
                      type="text"
                      value={formData.arrivedDate}
                      onChange={(e) => setFormData({...formData, arrivedDate: e.target.value})}
                      className="w-full border border-gray-200 p-2 rounded text-gray-800"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-extrabold text-gray-700 uppercase text-[9px]">Koordinator Mitra / Pihak Kedua</label>
                    <input
                      type="text"
                      value={formData.signatorySPPD}
                      onChange={(e) => setFormData({...formData, signatorySPPD: e.target.value})}
                      className="w-full border border-gray-200 p-2 rounded text-gray-800 font-bold"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="font-extrabold text-gray-700 uppercase text-[9px]">Label Cap Stempel Mitra</label>
                    <input
                      type="text"
                      value={formData.sppdBumdesStamp}
                      onChange={(e) => setFormData({...formData, sppdBumdesStamp: e.target.value})}
                      className="w-full border border-gray-200 p-2 rounded text-gray-800 uppercase font-bold"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-extrabold text-gray-700 uppercase text-[9px]">Ditetapkan Tanggal Surat</label>
                    <input
                      type="text"
                      value={formData.ditetapkanTanggal}
                      onChange={(e) => setFormData({...formData, ditetapkanTanggal: e.target.value})}
                      className="w-full border border-gray-200 p-2 rounded text-gray-800 font-medium"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setActiveSubTab(0)}
                  className="px-4 py-2 bg-slate-50 border border-gray-200 rounded font-bold hover:bg-slate-100 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-green-700 hover:bg-green-800 text-white rounded shadow-sm transition font-bold flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Daftarkan Usulan & Terbitkan</span>
                </button>
              </div>
            </form>
          </div>

          <div className="bg-white border border-gray-100 p-5 rounded-xl text-left space-y-3.5">
            <h4 className="text-xs font-black text-[#1e3a6e] uppercase tracking-wider flex items-center gap-1.5 border-b pb-2">
              💡 Panduan Surat Tugas LPPM Pekalongan
            </h4>
            <ul className="text-[11px] text-gray-600 space-y-3 leading-relaxed">
              <li className="flex gap-2">
                <span className="text-[#10b981] font-bold">✓</span>
                <span><strong>No Surat Validasi</strong> diketikkan secara lengkap beserta instansi (Contoh: ST/LPPM/ITSNU.Pkl/...) untuk menjamin SINTA mengidentifikasi luaran resmi Anda secara otomatis.</span>
              </li>
              <li className="flex gap-2">
                <span className="text-[#10b981] font-bold">✓</span>
                <span><strong>Daftar Personel</strong> mendukung multi-peneliti & perwakilan mahasiswa. Tekan tombol 'Tambah Personel' untuk mereplika baris tabel kosong, persis seperti lampiran PDF.</span>
              </li>
              <li className="flex gap-2">
                <span className="text-[#10b981] font-bold">✓</span>
                <span><strong>SPPD Box</strong> di bawah dokumen merekam stempel sirkulasi dinas di lapangan agar absensi dosen terekam sah oleh tim verifikator.</span>
              </li>
            </ul>
          </div>
        </div>
      ) : activeSubTab === 2 ? (
        /* KUMPULAN MODUL SURAT BERDASARKAN TAHAPAN */
        <div className="space-y-6 text-left">
          {/* Header Info Banner */}
          <div className="bg-gradient-to-r from-green-800 to-emerald-950 text-white p-5 rounded-xl shadow-xs relative overflow-hidden">
            <div className="absolute right-0 top-0 opacity-[0.08] text-[180px] font-bold select-none pointer-events-none transform translate-y-[-50px] translate-x-[20px]">
              ITS
            </div>
            <div className="relative z-10 max-w-2xl space-y-2">
              <span className="bg-emerald-500/35 border border-emerald-400 text-white font-black text-[9px] px-2 py-0.5 rounded-full uppercase tracking-wider">
                Sistem Dokumen Riset & Abdimas Pekalongan
              </span>
              <h3 className="text-base md:text-lg font-black tracking-tight leading-tight uppercase font-sans">
                Kumpulan Modul Surat Resmi Berdasarkan Tahapan Kegiatan
              </h3>
              <p className="text-[11.5px] text-emerald-100 font-medium leading-relaxed">
                Di bawah ini adalah katalog administrasi persuratan resmi LPPM ITSNU Pekalongan. Layanan ini disusun dinamis guna menjamin ketertiban dan standarisasi dokumen dosen dalam pelaporan portofolio SINTA.
              </p>
            </div>
          </div>

          {/* Search and Category Filter Controls */}
          <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between bg-[#f8fafc] border border-gray-150 p-4 rounded-xl">
            {/* Left: Interactive Category Tabs */}
            <div className="flex flex-wrap gap-1.5">
              {[
                { id: 'all', label: 'Semua Tahap', icon: '📋' },
                { id: 'persiapan', label: '1. Persiapan & Pengajuan', icon: '📝' },
                { id: 'etik', label: '2. Pengajuan Etik', icon: '⚕️' },
                { id: 'pelaksanaan', label: '3. Pelaksanaan', icon: '🤝' },
                { id: 'pelaporan', label: '4. Pelaporan', icon: '📄' }
              ].map((stageItem) => {
                const isActive = selectedStage === stageItem.id;
                return (
                  <button
                    key={stageItem.id}
                    onClick={() => setSelectedStage(stageItem.id)}
                    className={`flex items-center gap-1.5 text-[11px] font-extrabold px-3 py-2 rounded transition cursor-pointer select-none ${
                      isActive
                        ? 'bg-green-700 text-white shadow-xs'
                        : 'bg-white hover:bg-slate-100 text-gray-600 border border-gray-200'
                    }`}
                  >
                    <span>{stageItem.icon}</span>
                    <span>{stageItem.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Right: Tpl Search input */}
            <div className="relative w-full md:w-72 flex">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <Search className="h-3.5 w-3.5 text-gray-400" />
              </span>
              <input
                type="text"
                placeholder="Cari nama atau syarat dokumen..."
                value={tplSearch}
                onChange={(e) => setTplSearch(e.target.value)}
                className="w-full text-xs bg-white border border-gray-250 rounded py-2 pl-9 pr-3 outline-none text-gray-700 focus:border-green-600 focus:ring-1 focus:ring-green-100 placeholder:text-gray-400 font-medium font-sans"
              />
              {tplSearch && (
                <button
                  onClick={() => setTplSearch('')}
                  className="absolute inset-y-0 right-0 flex items-center pr-2.5 text-gray-400 hover:text-gray-600 text-[10px] font-bold"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Cards Grid */}
          {(() => {
            const listFiltered = letterTemplatesData.filter((template) => {
              const matchesSearch =
                template.title.toLowerCase().includes(tplSearch.toLowerCase()) ||
                template.description.toLowerCase().includes(tplSearch.toLowerCase()) ||
                template.requirements.some(r => r.toLowerCase().includes(tplSearch.toLowerCase()));
              
              const matchesStage = selectedStage === 'all' || template.stage === selectedStage;
              
              return matchesSearch && matchesStage;
            });

            if (listFiltered.length === 0) {
              return (
                <div className="bg-white border border-gray-200 rounded-xl p-12 text-center text-gray-400 font-bold text-xs">
                  Tidak ada dokumen surat ditemukan untuk penyaringan "{tplSearch || selectedStage}".
                </div>
              );
            }

            return (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {listFiltered.map((template) => (
                  <div 
                    key={template.id} 
                    className="bg-white border hover:border-green-400 hover:shadow-md transition text-left flex flex-col justify-between p-5 rounded-xl shadow-2xs relative overflow-hidden"
                  >
                    {/* Background Tag Watermark */}
                    <span className="absolute right-3 top-2 text-[26px] opacity-10 select-none">{template.stageIcon}</span>
                    
                    <div className="space-y-3">
                      {/* Badge Life-cycle & Format */}
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-[9px] font-black tracking-wider uppercase bg-emerald-50 text-emerald-850 border border-emerald-250 px-2 py-0.5 rounded">
                          {template.stageLabel}
                        </span>
                        <span className={`text-[8.5px] font-extrabold px-1.5 py-0.5 rounded select-none ${
                          template.docFormat === 'PDF' 
                            ? 'bg-rose-50 text-rose-700 border border-rose-200' 
                            : 'bg-blue-50 text-blue-700 border border-blue-200'
                        }`}>
                          {template.docFormat}
                        </span>
                      </div>

                      {/* Title */}
                      <h4 className="text-xs font-black text-gray-900 leading-snug uppercase tracking-tight font-sans">
                        {template.title}
                      </h4>

                      {/* Description */}
                      <p className="text-[11px] text-gray-600 leading-relaxed font-sans font-medium">
                        {template.description}
                      </p>

                      {/* Horizontal line */}
                      <hr className="border-gray-100" />

                      {/* Requirements bullets in pill lists */}
                      <div className="space-y-1.5">
                        <span className="text-[8px] font-extrabold text-gray-450 uppercase tracking-widest block">Prasyarat / Tanda Tangan:</span>
                        <div className="flex flex-wrap gap-1">
                          {template.requirements.map((req, rIdx) => (
                            <span 
                              key={rIdx} 
                              className="text-[9px] bg-sky-50 text-sky-850 hover:bg-sky-100 active:bg-sky-100 border border-sky-200 px-2.5 py-0.5 rounded font-black tracking-tight"
                            >
                              ☑ {req}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="pt-4 mt-4 border-t border-gray-50 flex items-center justify-between gap-1.5">
                      <button
                        onClick={() => {
                          triggerToast(`Unduhan berhasil! Dokumen templat "${template.title}" siap disimpan.`);
                          alert(`MENGUNDUH TEMPLAT [${template.id}]\nDokumen: ${template.title}\nFormat: *.${template.docFormat.toLowerCase()}\nInstansi LPPM ITSNU Pekalongan.`);
                        }}
                        className="flex-1 bg-white hover:bg-slate-100 border border-gray-250 text-slate-800 text-[10.5px] font-black py-1.5 px-3 rounded flex items-center justify-center gap-1 cursor-pointer transition"
                      >
                        <Download className="w-3.5 h-3.5 text-gray-650 animate-bounce" />
                        <span>Unduh Templat</span>
                      </button>

                      <button
                        onClick={() => {
                          // Auto fill the draft letter generation form with this template!
                          setFormData({
                            ...formData,
                            jenis: template.title,
                            subjekKegiatan: `${template.title} untuk program Penelitian/Pengabdian bertajuk ...`,
                            mitraLokasi: '[Masukkan Nama Instansi / Mitra Sasaran]',
                            hariTanggal: 'Senin, 15 Juni 2026',
                            waktu: '09.00 WIB s.d. selesai',
                            tempat: 'Aula LPPM ITSNU Pekalongan',
                            ditetapkanDi: 'Pekalongan',
                            ditetapkanTanggal: '12 Juni 2026',
                          });
                          setActiveSubTab(1); // Navigates to tab 'Ajukan Surat Baru'
                          triggerToast(`Formulir Registrasi Surat "${template.title}" telah disiapkan secara otomatis!`);
                        }}
                        className="flex-1 bg-green-700 hover:bg-green-800 text-white text-[10.5px] font-black py-1.5 px-3 rounded flex items-center justify-center gap-1 cursor-pointer transition shadow-2xs"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-green-250 shrink-0" />
                        <span>Gunakan & Buat</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            );
          })()}
        </div>
      ) : activeSubTab === 4 ? (
        /* PANDUAN ADMINISTRASI TAB */
        <div className="bg-white border border-gray-200 p-6 rounded-xl text-left space-y-4">
          <h4 className="text-xs font-black text-slate-800 uppercase tracking-tight">📜 Ketentuan Penerbitan Surat Dinas Mandiri LPPM Pekalongan</h4>
          <p className="text-xs text-gray-600 leading-relaxed space-y-2">
            Materi Administratif: Berdasarkan peraturan BAN-PT dan Ditjen Dikastara, setiap surat penugasan Tri Dharma wajib:
            <br />
            1. Menyertakan barcode/QR pengaman yang terintegrasi pada server SIMlitabmas Kampus Pekalongan.
            <br />
            2. Memenuhi persyaratan data personel (NIDN dosen primer, NIM pendamping).
            <br />
            3. Memperlihatkan jam, tanggal pelaksanaan, serta bukti cap basah SPPD instansi penerima di lapangan.
          </p>
        </div>
      ) : activeSubTab === 3 ? (
        /* LPPM VERIFIERS PANEL */
        <div className="bg-white text-left border border-gray-200 p-6 rounded-xl shadow-xs space-y-4">
          <h4 className="text-xs font-black text-[#1e3a6e] uppercase tracking-wider">🔒 Panel Verifikasi Mandiri Tanda Tangan Elektronik e-TTE</h4>
          <p className="text-xs text-gray-600 leading-relaxed">
            Halaman ini khusus memvalidasi nomor registrasi tanda tangan digital oleh <strong>Dr. Aria Mulyapradana, S.Psi., M.A.</strong> demi menjaga orisinalitas dokumen dinas tanpa tanda tangan basah fisik.
          </p>
          <div className="p-4 bg-slate-50 border rounded-lg flex flex-col sm:flex-row justify-between items-center gap-3">
            <div className="text-xs">
              <span className="font-extrabold text-slate-800 block">Validasi Serial e-TTE Offline</span>
              <span className="text-gray-400 font-mono text-[10px]">ITS-169-LPPM-TTE-SECURE</span>
            </div>
            <button 
              onClick={() => alert(`Enkripsi sertifikat digital sah dan valid. Berkas aman!`)}
              className="bg-green-700 hover:bg-green-800 text-white font-bold text-[11px] px-3.5 py-1.5 rounded transition"
            >
              Cek Keabsahan Dokumen
            </button>
          </div>
        </div>
      ) : (
        /* THE MAIN LIST TABLE ALIGNED WITH TABLEVIEW */
        <div className="space-y-4">
          
          <div className={`overflow-hidden bg-white border border-gray-200 ${roundedClass} shadow-xs`}>
            <div className="overflow-x-auto p-0.5">
              <table className="w-full text-left border-collapse min-w-[900px]">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-100">
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 text-center w-12">No</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 w-44">Pemberi Tugas / LPPM</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 w-[380px]">Nomor & Judul Deskripsi Tugas</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3">Jenis Kegiatan</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3">Mitra Pelaksana</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3 text-center w-28">Tanggal Rencana</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3 text-center w-24">Status</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 text-center w-36">Detil Tim</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 text-center w-14">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 text-xs">
                  {filteredLetters.length > 0 ? (
                    filteredLetters.map((l, idx) => {
                      const isSelected = l.id === selectedLetterId;
                      return (
                        <tr 
                          key={l.id} 
                          className={`hover:bg-slate-50/50 transition cursor-pointer ${
                            isSelected ? 'bg-green-50/20 font-medium' : ''
                          }`}
                          onClick={() => setSelectedLetterId(l.id)}
                        >
                          {/* Col 1: No */}
                          <td className="py-4 px-4 text-center font-bold text-gray-400 select-none">{idx + 1}</td>
                          
                          {/* Col 2: Pemberi */}
                          <td className="py-4 px-4 font-extrabold text-[#1e3a6e] uppercase tracking-tight">
                            {l.pemberiTugasNama}
                            <span className="text-[9.5px] font-mono text-gray-400 block tracking-normal uppercase pt-0.5">{l.pemberiTugasJabatan}</span>
                          </td>

                          {/* Col 3: Title */}
                          <td className="py-4 px-4 leading-relaxed text-gray-700">
                            <span className="text-[9.5px] font-bold text-gray-400 block font-mono">No: {l.nomorSurat}</span>
                            <div className="font-semibold text-gray-950 line-clamp-2 md:line-clamp-none">
                              {l.subjekKegiatan}
                            </div>
                          </td>

                          {/* Col 4: Jenis */}
                          <td className="py-4 px-3 text-gray-600 font-semibold font-mono">
                            <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded font-black text-[9.5px]">
                              {l.jenis}
                            </span>
                          </td>

                          {/* Col 5: Mitra */}
                          <td className="py-4 px-3 text-gray-600 font-medium italic">
                            📍 {l.mitraLokasi}
                          </td>

                          {/* Col 6: Tanggal */}
                          <td className="py-4 px-3 text-center text-gray-500 font-bold font-mono">
                            {l.hariTanggal}
                          </td>

                          {/* Col 7: Status */}
                          <td className="py-4 px-3 text-center">
                            {l.status === 'Disetujui' ? (
                              <span className="inline-block border px-2 py-1 rounded text-[9px] font-black bg-emerald-50 text-emerald-850 border-emerald-200 uppercase text-center w-full">
                                Disetujui (e-TTE)
                              </span>
                            ) : l.status === 'Direview' ? (
                              <span className="inline-block border px-2 py-1 rounded text-[9px] font-black bg-amber-50 text-amber-800 border-amber-200 uppercase text-center w-full">
                                Direview
                              </span>
                            ) : (
                              <span className="inline-block border px-2 py-1 rounded text-[9px] font-black bg-slate-100 text-slate-700 border-slate-200 uppercase text-center w-full">
                                Draf
                              </span>
                            )}
                          </td>

                          {/* Col 8: Team Count */}
                          <td className="py-4 px-3 text-center">
                            <span className="text-[10px] bg-indigo-50 border border-indigo-100 text-indigo-700 font-extrabold px-2 py-1 rounded">
                              {l.members ? l.members.length : 1} Personel
                            </span>
                          </td>

                          {/* Col 9: Aksi Detail */}
                          <td className="py-4 px-4 text-center">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedLetterId(l.id);
                              }}
                              className="p-1.5 bg-green-700 hover:bg-green-800 text-white rounded transition cursor-pointer"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={9} className="py-8 text-center text-gray-400 font-bold">
                        Tidak ada surat dinas terdaftar pada penyaringan ini.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* LOWER SECTION: OFFICIAL KOP SURAT PDF REPLICA SHEET PREVIEW (EXACT CLONE OF THE ORIGINAL UPLOADED PDF!) */}
          {selectedLetter && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start mt-4">
              
              {/* Left Side: Kop Preview (Styled strictly like a physical A4 paper page) */}
              <div className="lg:col-span-8 bg-white border border-gray-200 rounded-xl shadow-xs p-6 flex flex-col space-y-4">
                <div className="flex items-center justify-between border-b border-gray-150 pb-3">
                  <div className="flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-green-700" />
                    <span className="text-xs font-black text-gray-800 uppercase tracking-tight">Kertas Kerja & Pratinjau Surat Dinas ITSNU</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={handlePrint}
                      className="bg-slate-100 hover:bg-slate-200 text-slate-800 text-[11px] font-bold px-3 py-1.5 rounded flex items-center gap-1 shadow-2xs cursor-pointer transition"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Cetak / Cetak SPPD</span>
                    </button>
                    <button
                      onClick={() => alert(`Format PDF instan siap diunduh! No Serial Dokumen Sah Kampus: ${selectedLetter.id}-ITSNU-2025`)}
                      className="bg-green-700 hover:bg-green-800 text-white text-[11px] font-bold px-3 py-1.5 rounded flex items-center gap-1 shadow-2xs cursor-pointer transition"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Export PDF</span>
                    </button>
                  </div>
                </div>

                <div id="print-area-wrapper" className="bg-slate-200/50 p-4 rounded-lg flex items-center justify-center overflow-x-auto">
                  
                  {/* Official Replica Letter Box aligned with the provided physical PDF screenshot! */}
                  <div className="bg-white text-black p-8 md:p-12 border border-gray-300 w-full max-w-[620px] min-h-[900px] shadow-lg select-text text-left font-serif text-[11px] leading-relaxed relative flex flex-col justify-between">
                    
                    {/* Watermark Logo */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-[0.025] select-none pointer-events-none">
                      <span className="text-[110px] font-black text-green-800 rotate-12">ITSNU</span>
                    </div>

                    <div>
                      {/* Kop Surat Header exact copy from original PDF */}
                      <div className="flex items-center pb-3 border-b-4 border-double border-green-700 select-none">
                        {/* Replica green institutional shield logo */}
                        <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-green-800 via-emerald-600 to-green-900 flex items-center justify-center relative shrink-0 border border-green-300 shadow-sm mr-4">
                          <span className="text-xl text-white">🎓</span>
                        </div>
                        
                        <div className="text-center w-full flex flex-col font-sans">
                          <span className="text-[10px] md:text-[11.5px] font-extrabold tracking-wide text-green-800 leading-tight">
                            LEMBAGA PENELITIAN DAN PENGABDIAN MASYARAKAT
                          </span>
                          <span className="text-[16px] md:text-[18px] font-black tracking-tight text-green-950 leading-none mt-1">
                            ITSNU PEKALONGAN
                          </span>
                          <span className="text-[8.5px] text-gray-600 font-semibold tracking-tight mt-1 leading-tight">
                            Jl. Karangdowo No. 9 Kedungwuni Kab. Pekalongan Kode Pos 51173
                          </span>
                          <span className="text-[8px] text-gray-500 font-sans tracking-tight leading-none mt-0.5">
                            Telp/Fax. (0285) 7831614 email: <span className="underline font-bold text-blue-800">lppmitsnupkl@gmail.com</span> <span className="text-gray-800 font-extrabold">#SantriHighTech</span>
                          </span>
                        </div>
                      </div>

                      <div className="h-4"></div>

                      {/* SURAT TUGAS TITLE & NO */}
                      <div className="text-center font-sans">
                        <span className="text-[14px] font-bold uppercase tracking-widest border-b border-black pb-0.5 inline-block">
                          SURAT TUGAS
                        </span>
                        <span className="block text-[10.5px] tracking-tight mt-0.5 font-medium">
                          Nomor: {selectedLetter.nomorSurat}
                        </span>
                      </div>

                      <div className="h-3"></div>

                      {/* Bismillah block from PDF */}
                      <div className="text-center font-serif italic text-[11px] font-black tracking-widest text-slate-800 uppercase block select-none my-1">
                        BISMILLAHIRRAHMANIRRAHIM
                      </div>

                      <div className="h-2"></div>

                      {/* Yang Bertanda Tangan */}
                      <div className="space-y-1 font-sans text-[11px]">
                        <p className="font-medium text-gray-900">Yang bertanda tangan di bawah ini:</p>
                        <table className="w-full max-w-sm text-left text-[11px] leading-tight">
                          <tbody>
                            <tr>
                              <td className="py-0.5 pr-2 w-16 text-gray-500 font-semibold">Nama</td>
                              <td className="py-0.5 pr-1 font-semibold">:</td>
                              <td className="py-0.5 font-bold text-gray-900">{selectedLetter.pemberiTugasNama}</td>
                            </tr>
                            <tr>
                              <td className="py-0.5 pr-2 text-gray-500 font-semibold">Jabatan</td>
                              <td className="py-0.5 pr-1 font-semibold">:</td>
                              <td className="py-0.5 font-bold text-gray-900">{selectedLetter.pemberiTugasJabatan}</td>
                            </tr>
                            <tr>
                              <td className="py-0.5 pr-2 text-gray-500 font-semibold">Alamat</td>
                              <td className="py-0.5 pr-1 font-semibold">:</td>
                              <td className="py-0.5 text-gray-800 font-medium">{selectedLetter.pemberiTugasAlamat}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>

                      <div className="h-3"></div>

                      {/* Dengan Ini Memberikan Tugas */}
                      <p className="text-justify font-sans text-[11px] leading-relaxed mb-2.5">
                        Dengan ini memberikan tugas kepada perwakilan ITSNU Pekalongan dengan nama sebagai berikut:
                      </p>

                      {/* Official Assignee Table copy from PDF */}
                      <table className="w-full text-left font-sans text-[10.5px] border-collapse border border-black mb-3.5">
                        <thead>
                          <tr className="bg-gray-50">
                            <th className="border border-black p-1 text-center font-bold w-10">No</th>
                            <th className="border border-black p-1.5 font-bold">Nama Dosen / Personel</th>
                            <th className="border border-black p-1.5 font-bold w-24 text-center">Jabatan</th>
                            <th className="border border-black p-1.5 font-mono font-bold w-36 text-center">NIDN / NIM</th>
                          </tr>
                        </thead>
                        <tbody>
                          {selectedLetter.members && selectedLetter.members.length > 0 ? (
                            selectedLetter.members.map((member, mIdx) => (
                              <tr key={mIdx}>
                                <td className="border border-black p-1 text-center font-bold">{mIdx + 1}</td>
                                <td className="border border-black p-1.5 font-bold text-slate-800">{member.nama}</td>
                                <td className="border border-black p-1.5 text-center font-medium">{member.jabatan}</td>
                                <td className="border border-black p-1.5 text-center font-mono font-semibold">{member.nidn}</td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td className="border border-black p-1 text-center font-bold">1</td>
                              <td className="border border-black p-1.5 font-bold text-slate-800">Mujibul Hakim, S.Kom, M.M.</td>
                              <td className="border border-black p-1.5 text-center font-medium">Dosen</td>
                              <td className="border border-black p-1.5 text-center font-mono font-semibold">0608068901</td>
                            </tr>
                          )}
                        </tbody>
                      </table>

                      {/* Deskripsi Lokasi Agenda dari PDF */}
                      <div className="space-y-2 font-sans text-[11px] leading-relaxed text-justify mb-4">
                        <p>
                          Untuk melakukan kegiatan Pengabdian kepada Masyarakat tentang <strong className="text-gray-900 font-extrabold">“{selectedLetter.subjekKegiatan}”</strong> pada:
                        </p>

                        <table className="w-full max-w-sm text-left text-[11px] leading-tight ml-4 font-semibold">
                          <tbody>
                            <tr>
                              <td className="py-0.5 pr-2 w-24 text-gray-500">Hari, Tanggal</td>
                              <td className="py-0.5 pr-1 text-gray-500">:</td>
                              <td className="py-0.5 text-gray-900 font-extrabold">{selectedLetter.hariTanggal}</td>
                            </tr>
                            <tr>
                              <td className="py-0.5 pr-2 text-gray-500">Waktu</td>
                              <td className="py-0.5 pr-1 text-gray-500">:</td>
                              <td className="py-0.5 text-gray-900">{selectedLetter.waktu}</td>
                            </tr>
                            <tr>
                              <td className="py-0.5 pr-2 text-gray-500">Tempat</td>
                              <td className="py-0.5 pr-1 text-gray-500">:</td>
                              <td className="py-0.5 text-gray-900 font-extrabold">{selectedLetter.tempat}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>

                      <p className="font-sans text-[11px] text-justify leading-relaxed mb-6">
                        Demikian Surat Tugas ini dikeluarkan agar dapat digunakan sebagaimana mestinya.
                      </p>

                      {/* Sign-off dan TTE section */}
                      <div className="flex justify-end font-sans text-[11px] text-right mb-6 select-none relative">
                        <div className="space-y-1 relative">
                          <div>
                            Ditetapkan di : {selectedLetter.ditetapkanDi || 'Pekalongan'}
                          </div>
                          <div className="border-b pb-1">
                            Pada tanggal : {selectedLetter.ditetapkanTanggal}
                          </div>
                          
                          <div className="pt-1 text-[11px] font-bold text-gray-800 leading-tight">
                            Kepala LPPM
                            <br />
                            ITSNU Pekalongan
                          </div>

                          {/* Stamp & Ink Signature Overlays accurately drawn using CSS */}
                          <div className="relative h-14 w-44 flex items-center justify-end select-none pointer-events-none">
                            {/* Realistic Purple LPPM Stamp */}
                            <div className="absolute right-12 top-[-25px] w-[95px] h-[95px] border-3 border-dotted border-violet-600/35 rounded-full flex items-center justify-center text-center opacity-65 -rotate-6 mix-blend-multiply">
                              <div className="w-[83px] h-[83px] border border-double border-violet-500/35 rounded-full flex items-center justify-center p-0.5 relative">
                                <span className="text-[5.5px] font-black text-violet-500 absolute inset-0.5 py-1 text-center tracking-tighter uppercase leading-none">
                                  LPPM • ITSNU PEKALONGAN
                                </span>
                                <span className="text-[12px] font-black tracking-widest text-violet-600/80 uppercase">
                                  ITSNU
                                </span>
                              </div>
                            </div>

                            {/* Blue Signature Scribble */}
                            <svg className="w-24 h-9 text-blue-900/65 absolute right-4 bottom-[-5px] rotate-3" viewBox="0 0 100 30" fill="none">
                              <path d="M10,25 Q30,5 50,15 T90,10" stroke="blue" strokeWidth="1.8" fill="none" />
                              <path d="M15,22 Q35,12 45,8 T80,18" stroke="blue" strokeWidth="1" fill="none" />
                            </svg>
                          </div>

                          <div className="pt-2">
                            <span className="font-extrabold text-[#1e3a6e] border-b border-black pb-0.5 inline-block text-[11px]">
                              {selectedLetter.pemberiTugasNama}
                            </span>
                            <span className="block text-[9.5px] text-gray-500 font-mono font-bold mt-0.5">
                              NPP. 0034.12.09.2018
                            </span>
                          </div>
                        </div>
                      </div>

                    </div>

                    {/* SPPD DOUBLE-BOX FOOTER SECTION AS PRESENT IN ORIGINAL PDF! */}
                    <div className="border-t border-black font-sans text-[9px] pt-3.5 space-y-4">
                      
                      <div className="grid grid-cols-2 gap-4">
                        {/* Box Left: Tiba di */}
                        <div className="border border-black p-2.5 rounded-sm relative text-[9px] space-y-1 bg-slate-50/50">
                          <div>
                            <span className="font-bold text-gray-400">Tiba di :</span> <span className="font-extrabold text-slate-900">{selectedLetter.arrivedAt || 'Coffe Teman Cerita'}</span>
                          </div>
                          <div>
                            <span className="font-bold text-gray-400">Pada hari & Tgl :</span> <span className="font-bold">{selectedLetter.arrivedDate || 'Jum’at, 25 Juli 2025'}</span>
                          </div>
                          <div className="pt-1 font-bold text-slate-800">
                            Koordinator
                          </div>
                          
                          {/* STAMP REVERSAL BUMDES STAMP */}
                          <div className="py-2 flex items-center justify-center">
                            <div className="border-2 border-dashed border-blue-600/40 px-2 py-0.5 font-sans text-center text-blue-600/70 -rotate-3 rounded w-36 select-none pointer-events-none mix-blend-multiply">
                              <span className="text-[5px] font-extrabold uppercase tracking-tight block">KABUPATEN PEKALONGAN</span>
                              <span className="text-[7.5px] font-black uppercase tracking-normal block leading-tight">BUMDES "{selectedLetter.sppdBumdesStamp || 'JAYA MANDIRI'}"</span>
                              <span className="text-[4.5px] font-bold uppercase tracking-widest block leading-none">PEGADEN TENGAH - WONOPRINGGO</span>
                            </div>
                          </div>

                          <div className="text-center font-bold text-gray-900 border-b border-black w-24 mx-auto pt-0.5">
                            {selectedLetter.signatorySPPD || 'Irmayanti'}
                          </div>
                        </div>

                        {/* Box Right: Tiba kembali di */}
                        <div className="border border-black p-2.5 rounded-sm relative text-[9px] space-y-1 bg-slate-50/50">
                          <div>
                            <span className="font-bold text-gray-400">Tiba kembali di :</span> <span className="font-extrabold text-green-900">{selectedLetter.returnedAt || 'ITSNU Pekalongan'}</span>
                          </div>
                          <div>
                            <span className="font-bold text-gray-400">Pada hari & Tgl :</span> <span className="font-bold">{selectedLetter.returnedDate || 'Jum’at, 25 Juli 2025'}</span>
                          </div>
                          <div className="pt-1 font-bold text-slate-800">
                            Pejabat yang berwenang ditunjuk
                          </div>

                          {/* REPLICA BACKSIDE BUMDES STAMP */}
                          <div className="py-2 flex items-center justify-center">
                            <div className="border-2 border-dashed border-blue-600/40 px-2 py-0.5 font-sans text-center text-blue-600/70 rotate-2 rounded w-36 select-none pointer-events-none mix-blend-multiply">
                              <span className="text-[5px] font-extrabold uppercase tracking-tight block">KABUPATEN PEKALONGAN</span>
                              <span className="text-[7.5px] font-black uppercase tracking-normal block leading-tight">BUMDES "{selectedLetter.sppdBumdesStamp || 'JAYA MANDIRI'}"</span>
                              <span className="text-[4.5px] font-bold uppercase tracking-widest block leading-none">PEGADEN TENGAH - WONOPRINGGO</span>
                            </div>
                          </div>

                          <div className="text-center font-bold text-gray-900 border-b border-black w-24 mx-auto pt-0.5">
                            {selectedLetter.signatorySPPD || 'Irmayanti'}
                          </div>
                        </div>
                      </div>

                    </div>

                  </div>
                </div>
              </div>

              {/* Right Side: Comments and info detailing */}
              <div className="lg:col-span-4 space-y-4 text-left">
                
                <div className="p-4 bg-green-50 border-l-4 border-green-700 rounded text-xs space-y-2 relative">
                  <div className="flex items-center gap-1.5 text-green-900 font-extrabold">
                    <CheckCircle2 className="w-4 h-4 text-green-700 shrink-0" />
                    <span>Sinkronisasi SAKTI / SINTA:</span>
                  </div>
                  <p className="text-gray-700 font-bold text-[11px] leading-relaxed">
                    Surat tugas ini telah sepenuhnya sinkron dengan database BKD DIKTI & SINTA Pekalongan.
                  </p>
                </div>

                <div className="p-4 bg-amber-50 border-l-4 border-amber-500 rounded text-xs space-y-1 relative">
                  <div className="flex items-center gap-1.5 text-amber-900 font-bold">
                    <MessageSquare className="w-3.5 h-3.5 text-amber-600" />
                    <span>Catatan Reviewer Administrasi LPPM:</span>
                  </div>
                  <p className="text-gray-700 font-semibold text-[11px] leading-normal">Surat Ref: No. {selectedLetter.nomorSurat}</p>
                  <p className="text-gray-600 italic leading-relaxed">"{selectedLetter.reviewerNotes}"</p>
                </div>

                <div className="bg-white border border-gray-200 p-4 rounded-xl text-xs space-y-2.5">
                  <span className="font-extrabold text-indigo-700 uppercase tracking-widest text-[9.5px]">Detail Status Pengarsipan</span>
                  <div className="space-y-1.5 text-gray-600">
                    <div className="flex justify-between">
                      <span className="font-bold">ID Transaksi:</span>
                      <span className="font-mono">{selectedLetter.id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-bold">Tanggal Pengajuan:</span>
                      <span>{selectedLetter.tanggalPengajuan}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-bold">Nomor Surat Dinas:</span>
                      <span className="font-mono text-[10px] break-all text-green-800 font-extrabold">{selectedLetter.nomorSurat}</span>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>
      )}

    </div>
  );
}
