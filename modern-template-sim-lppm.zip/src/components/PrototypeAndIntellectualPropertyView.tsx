import React, { useState, useMemo } from 'react';
import { ThemePreset, CustomControls } from '../types';
import { 
  CheckCircle2, Clock, Send, Info, Plus, Award, GitMerge, FileText, 
  Search, RefreshCw, Layers, ArrowRight, ShieldCheck, Download, 
  HelpCircle, Eye, Check, ExternalLink, AlertTriangle, FileSpreadsheet, Filter, MessageSquare,
  Upload, Trash2, UserPlus, AlertCircle, FileCheck
} from 'lucide-react';

interface PrototypeAndIntellectualPropertyViewProps {
  preset: ThemePreset;
  controls: CustomControls;
  activeMenu: string;
}

export interface SinergiRecord {
  id: string;
  namaPrototipe: string;
  tktLevel: number; // 1-9 (Tingkat Kesiapterapan Teknologi / TRL)
  asalPenelitian: string;
  tahunPenelitian: string;
  skemaPenelitian: string;
  implementasiPengabdian: string;
  tahunPengabdian: string;
  skemaPengabdian: string;
  mitraAbdimas: string;
  jenisHKI: 'Paten Sederhana' | 'Hak Cipta (Software)' | 'Hak Cipta (Buku/Panduan)' | 'Desain Industri' | 'Merek Dagang';
  judulHKI: string;
  statusPengajuan: 'Sudah Diajukan' | 'Belum Diajukan' | 'Draf Berkas';
  nomorRegistrasiHKI: string;
  skTerbit: 'Terbit' | 'Dalam Proses' | 'Belum Diajukan';
  nomorSK: string;
  tanggalSK: string;
  reviewerNotes: string;
}

export interface HkiDocumentRequirement {
  id: string;
  name: string;
  description: string;
  required: boolean;
  format: string;
}

export const HKI_DOCS_METADATA: Record<string, HkiDocumentRequirement[]> = {
  'Paten Sederhana': [
    { id: 'deskripsi_paten', name: 'Dokumen Spesifikasi Paten', description: 'Terdiri dari Abstrak, Deskripsi Invensi, Klaim Paten, dan Gambar Teknik (jika ada)', required: true, format: 'PDF' },
    { id: 'pernyataan_kepemilikan', name: 'Surat Pernyataan Kepemilikan Invensi', description: 'Ditandatangani seluruh inventor di atas meterai Rp 10.000', required: true, format: 'PDF' },
    { id: 'pengalihan_hak', name: 'Surat Pengalihan Hak Invensi', description: 'Dari Inventor ke ITSNU Pekalongan (opsional jika paten atas nama kampus)', required: false, format: 'PDF' },
    { id: 'ktp_inventor', name: 'KTP Seluruh Inventor', description: 'Gabungkan seluruh KTP inventor ke dalam satu file PDF', required: true, format: 'PDF' },
  ],
  'Hak Cipta (Software)': [
    { id: 'pernyataan_hak', name: 'Surat Pernyataan Ciptaan', description: 'Bermeterai Rp 10.000, menyatakan keaslian karya cipta program komputer', required: true, format: 'PDF' },
    { id: 'pengalihan_hak_cipta', name: 'Surat Pengalihan Hak Cipta', description: 'Jika pemegang hak dialihkan ke institusi (ITSNU Pekalongan)', required: false, format: 'PDF' },
    { id: 'ktp_pencipta', name: 'KTP Seluruh Pencipta', description: 'Scan KTP seluruh pencipta program komputer', required: true, format: 'PDF' },
    { id: 'kode_sumber', name: 'Kode Sumber / Teks Kode Program', description: 'Kutipan minimal 50 halaman pertama & terakhir atau full code jika kurang', required: true, format: 'PDF/TXT/ZIP' },
    { id: 'manual_book', name: 'Buku Panduan / Manual Penggunaan', description: 'Dokumen panduan instalasi dan pengoperasian software', required: true, format: 'PDF' },
  ],
  'Hak Cipta (Buku/Panduan)': [
    { id: 'pernyataan_hak', name: 'Surat Pernyataan Hak Cipta', description: 'Mencantumkan judul buku dan seluruh pencipta di atas meterai Rp 10.000', required: true, format: 'PDF' },
    { id: 'berkas_buku', name: 'Naskah / Karya Tulis Utuh', description: 'File buku/panduan lengkap mulai dari Cover, Prakata, Daftar Isi, Bab 1-Penutup', required: true, format: 'PDF' },
    { id: 'ktp_pencipta', name: 'KTP Seluruh Pencipta', description: 'Scan KTP seluruh penulis/pencipta buku', required: true, format: 'PDF' },
    { id: 'pengalihan_hak_cipta', name: 'Surat Pengalihan Hak Cipta', description: 'Pernyataan pelimpahan hak cipta ke institusi ITSNU Pekalongan', required: false, format: 'PDF' },
  ],
  'Desain Industri': [
    { id: 'pernyataan_desain', name: 'Surat Pernyataan Kepemilikan Desain', description: 'Bermeterai Rp 10.000, menyatakan keaslian desain industri', required: true, format: 'PDF' },
    { id: 'gambar_desain', name: 'Gambar Visual Desain Industri', description: 'Gambar tampak depan, belakang, samping, atas, bawah, dan perspektif', required: true, format: 'PDF/JPG' },
    { id: 'penjelasan_desain', name: 'Uraian Penjelasan Desain Industri', description: 'Deskripsi mengenai bentuk, konfigurasi, estetika, dan inovasi visual produk', required: true, format: 'PDF' },
    { id: 'ktp_desainer', name: 'KTP Seluruh Desainer', description: 'Scan KTP seluruh desainer produk terkait', required: true, format: 'PDF' },
  ],
  'Merek Dagang': [
    { id: 'pernyataan_merek', name: 'Surat Pernyataan Kepemilikan Merek', description: 'Menjamin merek belum pernah terdaftar sebelumnya oleh pihak lain', required: true, format: 'PDF' },
    { id: 'etiket_merek', name: 'Label / Etiket Merek Dagang', description: 'Gambar visual logo merek berwarna resolusi tinggi', required: true, format: 'JPG/PNG' },
    { id: 'bukti_umkm', name: 'Surat Pengantar UMKM / Bina Mandiri', description: 'Surat pengisi keringanan biaya pendaftaran merek khusus binaan lppm', required: false, format: 'PDF' },
    { id: 'ktp_pemilik', name: 'KTP Pemilik Merek', description: 'Scan KTP ketua kelompok pengusul atau perwakilan lembaga', required: true, format: 'PDF' },
  ]
};

export const HKI_TEMPLATES_CONTENT: Record<string, { title: string; text: string }> = {
  'pernyataan_hak': {
    title: 'Surat Pernyataan Hak Cipta / Invensi Ber-meterai',
    text: `SURAT PERNYATAAN\n\nYang bertanda tangan di bawah ini:\nNama\t: [Nama Ketua Pengusul]\nNIDN/NIM\t: [NIDN/NIM]\nJabatan\t: Dosen / Mahasiswa ITSNU Pekalongan\nAlamat\t: Jl. Karangdowo No. 9, Kedungwuni, Kab. Pekalongan\n\nDengan ini menyatakan dengan sebenarnya bahwa:\n1. Karya Cipta / Invensi berupa Program Komputer / Buku / Paten yang berjudul:\n   "[Judul Luaran HKI]"\n   adalah benar-benar merupakan hasil karya cipta asli/orisinal saya beserta tim pencipta, seluruhnya dirancang tanpa melakukan plagiarisme atau meniru hak cipta milik orang lain.\n2. Seluruh data pendukung, spesifikasi, dan dokumentasi yang dilampirkan adalah benar adanya dan siap dipertanggungjawabkan di hadapan hukum.\n\nPernyataan ini dibuat dengan sadar demi kelancaran proses pengajuan Sertifikat Paten/Hak Cipta di Ditjen KI Kemenkumham RI.\n\nPekalongan, [Tanggal Pengajuan]\n\n\n(Meterai Rp10.000 beserta Tanda Tangan)\n\n\n[Nama Ketua Pengusul]`
  },
  'pengalihan_hak': {
    title: 'Surat Pengalihan Hak Milik Ciptaan / Paten',
    text: `SURAT PENGALIHAN HAK CIPTA / PATEN\n\nKami yang bertanda tangan di bawah ini:\n\nPIHAK PERTAMA (Pencipta / Inventor)\nNama\t: [Nama Ketua Pengusul]\nNIDN/NIM\t: [NIDN/NIM]\nAlamat\t: Kedungwuni, Pekalongan\n\nPIHAK KEDUA (Pemegang Hak Cipta)\nLembaga\t: Lembaga Penelitian dan Pengabdian Masyarakat (LPPM) ITSNU Pekalongan\nAlamat\t: Jl. Karangdowo No. 9, Kedungwuni, Kab. Pekalongan\n\nDengan ini PIHAK PERTAMA menyatakan menyerahkan/mengalihkan hak ekonomi atas karya ciptaan / desain / merek / paten berjudul:\n"[Judul Luaran HKI]"\nkepada PIHAK KEDUA guna keperluan akreditasi institusi, sinkronisasi portal SINTA, dan hilirisasi produk iptek perguruan tinggi.\n\nPekalongan, [Tanggal Pengajuan]\n\nPIHAK PERTAMA,                      PIHAK KEDUA,\n\n(TTD)                               (Stempel LPPM + TTD)\n[Nama Ketua Pengusul]               Dr. Aria Mulyapradana, S.Psi., M.A.`
  },
  'deskripsi_paten': {
    title: 'Spesifikasi Paten Sederhana (Abstrak, Deskripsi, Klaim)',
    text: `DESKRIPSI PATEN SEDERHANA\n\n1. JUDUL INVENSI\n   [Judul Luaran HKI]\n\n2. BIDANG TEKNIK INVENSI\n   Invensi ini berhubungan dengan [Sektor Invensi, misal: irigasi pertanian otomatis, IoT, keamanan cyber, dll], khususnya berkaitan dengan rancangan sistem terpadu berbiaya rendah.\n\n3. LATAR BELAKANG INVENSI\n   Menjelaskan kekurangan sistem/alat pembanding terdahulu di masyarakat Pekalongan. Kelemahan alat pembanding meliputi penggunaan daya yang boros dan ketidakmampuan beroperasi secara grid nirkabel.\n\n4. RINGKASAN INVENSI\n   Invensi ini menawarkan peningkatan keandalan dengan konsumsi arus sangat rendah.\n\n5. KLAIM YANG DIMINTAKAN PELINDUNGAN\n   Klaim 1: Unit sistem dicirikan oleh adanya sirkuit pembatas catu daya otomatis...\n   Klaim 2: Topologi nirkabel dicirikan oleh..."`
  },
  'etiket_merek': {
    title: 'Etiket Merek Dagang & Desain Industri (Logo & Dimensi)',
    text: `PETUNJUK ETIKET / LABEL MEREK\n\nKetentuan Label/Etiket Merek Dagang:\n1. Format file Gambar JPG atau PNG beresolusi minimal 150-300 DPI.\n2. Ukuran etiket merek maksimal berbentuk bujur sangkar (min 2x2 cm s.d 9x9 cm).\n3. Mencantumkan tulisan nama merek secara jelas.\n4. Memiliki kombinasi warna yang kontras.\n5. Tidak boleh menyertakan logo lembaga negara atau bendera terkecuali ada izin khusus.\n6. Wajib mencantumkan jenis barang/jasa sesuai klasifikasi kelas merek Kemenkumham.`
  }
};

export default function PrototypeAndIntellectualPropertyView({ 
  preset, 
  controls, 
  activeMenu 
}: PrototypeAndIntellectualPropertyViewProps) {
  
  const colors = preset.config;
  const roundedClass = 
    controls.roundedMode === 'none' ? 'rounded-none' :
    controls.roundedMode === 'md' ? 'rounded-md' :
    controls.roundedMode === 'xl' ? 'rounded-xl' : 'rounded-2xl';

  // Aligned Sub Tabs Mapping
  const subTabs = ['Monitoring Sinergi', 'Daftarkan Hilirisasi', 'Ajukan Pendaftaran HKI', 'Ditjen KI Sinkronisasi', 'Aturan Luaran Terpadu'];
  const [activeSubTab, setActiveSubTab] = useState<number>(0);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [filterYear, setFilterYear] = useState('2026');
  
  const [selectedRecordId, setSelectedRecordId] = useState<string>('SYN-01');
  
  // Interactive simulations
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);

  // Initial persistent state for the synchronized records
  const [records, setRecords] = useState<SinergiRecord[]>([
    {
      id: 'SYN-01',
      namaPrototipe: 'Smart Soil & Crop Moisture IoT Grid Node v2.1',
      tktLevel: 7,
      asalPenelitian: 'Rancang Bangun Sistem Grid IoT Pertanian Pekalongan Mandiri Berkelanjutan',
      tahunPenelitian: '25/26',
      skemaPenelitian: 'Penelitian Fundamental',
      implementasiPengabdian: 'Pendampingan & Pemasangan Sensor Grid Pertanian Kelompok Tani Pekalongan Utara',
      tahunPengabdian: '2026',
      skemaPengabdian: 'Program Kemitraan Kemitraan Wilayah',
      mitraAbdimas: 'Kelompok Tani Rejo Mulyo, Pekalongan Utara',
      jenisHKI: 'Paten Sederhana',
      judulHKI: 'Alat Pemantau Kelembaban Tanah Berbasis Jaringan Grid Sensor Nirkabel Menggunakan Protokol Rendah Daya',
      statusPengajuan: 'Sudah Diajukan',
      nomorRegistrasiHKI: 'S00202603841',
      skTerbit: 'Terbit',
      nomorSK: 'SK-PATEN/DJKI/2408-2026',
      tanggalSK: '18 Mei 2026',
      reviewerNotes: 'Paten telah disetujui secara substantif oleh DJKI Kemenkumham. Sertifikat fisik diterbitkan dan siap diimplementasikan untuk pelaporan luaran wajib dana hibah.'
    },
    {
      id: 'SYN-02',
      namaPrototipe: 'Chatbot Generative AI Fiqh Da\'wah Syariah v1.0',
      tktLevel: 5,
      asalPenelitian: 'Rancang Bangun Chatbot Konsultasi Hukum Islam dan Kemasyarakatan menggunakan Generative AI',
      tahunPenelitian: '25/26',
      skemaPenelitian: 'Penelitian Terapan',
      implementasiPengabdian: 'Edukasi Digital Syariah & Penyusunan Aplikasi Konsultasi Hukum Islam di Madrasah Pekalongan',
      tahunPengabdian: '2026',
      skemaPengabdian: 'Pengabdian Dosen Pemula (PDP)',
      mitraAbdimas: 'Madrasah Aliyah Salafiyah Pekalongan',
      jenisHKI: 'Hak Cipta (Software)',
      judulHKI: 'Sistem Integrasi Chatbot Fiqh & Fatwa MUI Berbasis Model Bahasa Besar Llama-3-70B',
      statusPengajuan: 'Sudah Diajukan',
      nomorRegistrasiHKI: 'EC00202688102',
      skTerbit: 'Dalam Proses',
      nomorSK: '-',
      tanggalSK: '-',
      reviewerNotes: 'Berkas permohonan Hak Cipta Program Komputer telah dinyatakan lengkap di portal e-HakCipta. Menunggu validasi akhir & antrean tanda tangan elektronik SK Ditjen KI.'
    },
    {
      id: 'SYN-03',
      namaPrototipe: 'E-Museum & Batik Culture Interactive Gamification Portal',
      tktLevel: 6,
      asalPenelitian: 'Revitalisasi Motif Batik Pesisiran Pekalongan Bermakna Filosofis Lokal Melalui Media Interaktif Digital',
      tahunPenelitian: '25/26',
      skemaPenelitian: 'Program Kemitraan Wilayah',
      implementasiPengabdian: 'Pendampingan Hak Paten Merek Dagang Pengrajin Batik Krapyak & Sosialisasi Catalog Digital',
      tahunPengabdian: '2026',
      skemaPengabdian: 'Pemberdayaan Kemitraan Masyarakat',
      mitraAbdimas: 'Paguyuban Kreatif Pengrajin Batik Krapyak Kidul',
      jenisHKI: 'Hak Cipta (Buku/Panduan)',
      judulHKI: 'Buku Panduan Inventarisasi Visual & Filosofi 45 Motif Batik Kuno Pesisiran Pekalongan',
      statusPengajuan: 'Belum Diajukan',
      nomorRegistrasiHKI: '-',
      skTerbit: 'Belum Diajukan',
      nomorSK: '-',
      tanggalSK: '-',
      reviewerNotes: 'Draft buku panduan hasil pengabdian sedang difinalisasi oleh tim dosen. Berkas administrasi surat pernyataan hak milik belum ditandatangani oleh Ketua Pengusul.'
    }
  ]);

  // Form State
  const [formData, setFormData] = useState({
    namaPrototipe: '',
    tktLevel: 5,
    asalPenelitian: 'Riset Komparatif Pengamanan Sistem Transaksi Elektronik Pekalongan',
    tahunPenelitian: '25/26',
    skemaPenelitian: 'Penelitian fundamental',
    implementasiPengabdian: 'Sosialisasi & Implementasi Aplikasi Pengamanan Data Data UMKM Batik Pekalongan',
    tahunPengabdian: '2026',
    skemaPengabdian: 'Pengabdian Kepada Masyarakat Terpadu',
    mitraAbdimas: 'Koperasi Batik Krapyak Makmur',
    jenisHKI: 'Hak Cipta (Software)' as SinergiRecord['jenisHKI'],
    judulHKI: '',
    statusPengajuan: 'Sudah Diajukan' as SinergiRecord['statusPengajuan'],
    skTerbit: 'Dalam Proses' as SinergiRecord['skTerbit'],
    nomorRegistrasiHKI: '',
    nomorSK: '',
  });

  // HKI Application Form state
  const [hkiFormData, setHkiFormData] = useState({
    jenisHKI: 'Hak Cipta (Software)' as SinergiRecord['jenisHKI'],
    judulHKI: '',
    namaPrototipe: 'Prototipe Hilirisasi Mandiri',
    deskripsiHKI: '',
    asalPenelitian: 'Rancang Bangun Sistem Grid IoT Pertanian Pekalongan Mandiri Berkelanjutan',
    tktLevel: 5,
    mitraAbdimas: 'Kelompok Tani Rejo Mulyo, Pekalongan Utara',
    statusPengajuan: 'Sudah Diajukan' as SinergiRecord['statusPengajuan'],
    inventors: [
      { nama: preset.brand.userName, jabatan: 'Ketua Inventor (Dosen)', nidn: '0608068901' }
    ] as { nama: string; jabatan: string; nidn: string; }[]
  });

  // Simulation of uploaded files
  const [uploadedFiles, setUploadedFiles] = useState<Record<string, { name: string; size: string; date: string }>>({});
  const [uploadingId, setUploadingId] = useState<string | null>(null);
  const [uploadingProgress, setUploadingProgress] = useState<number>(0);
  const [showTemplateModal, setShowTemplateModal] = useState<string | null>(null);

  const handleCreateHkiApplication = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hkiFormData.judulHKI) {
      alert("Mohon lengkapi Judul/Nama Karya Hak Kekayaan Intelektual!");
      return;
    }

    // Checking if all required files for that HKI type are uploaded
    const requirements = HKI_DOCS_METADATA[hkiFormData.jenisHKI] || [];
    const missingDocs = requirements.filter(req => {
      if (!req.required) return false;
      const fileKey = `${hkiFormData.jenisHKI}_${req.id}`;
      return !uploadedFiles[fileKey];
    });

    if (missingDocs.length > 0) {
      alert(`Mohon lengkapi dan unggah seluruh berkas persyaratan wajib terlebih dahulu! Masih kurang: ${missingDocs.map(d => d.name).join(', ')}`);
      return;
    }

    const randomId = `SYN-${Math.floor(100 + Math.random() * 900)}`;
    const newRecord: SinergiRecord = {
      id: randomId,
      namaPrototipe: hkiFormData.namaPrototipe,
      tktLevel: Number(hkiFormData.tktLevel),
      asalPenelitian: hkiFormData.asalPenelitian,
      tahunPenelitian: '25/26',
      skemaPenelitian: 'Penelitian Terapan',
      implementasiPengabdian: `Penyuluhan dlm rangka hilirisasi produk ${hkiFormData.judulHKI}`,
      tahunPengabdian: '2026',
      skemaPengabdian: 'PKM Kemitraan',
      mitraAbdimas: hkiFormData.mitraAbdimas,
      jenisHKI: hkiFormData.jenisHKI,
      judulHKI: hkiFormData.judulHKI,
      statusPengajuan: 'Sudah Diajukan',
      nomorRegistrasiHKI: `REG${Math.floor(100000 + Math.random() * 900000)}`,
      skTerbit: 'Dalam Proses',
      nomorSK: '-',
      tanggalSK: '-',
      reviewerNotes: `Pendaftaran HKI mandiri dosen berhasil divalidasi oleh LPPM. Berkas lengkap (${requirements.length} file terunggah). Dikirim ke Ditjen KI untuk verifikasi e-TTE.`
    };

    setRecords([newRecord, ...records]);
    setSelectedRecordId(randomId);
    setActiveSubTab(0); // Switch to Monitoring Sinergi
    setSyncMessage(`Sukses meregistrasikan pengusulan HKI Baru! Silakan verifikasi nomor registrasi berkas ${newRecord.id} Anda di bawah.`);
  };

  const handleSimulateUpload = (docId: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadingId(docId);
    setUploadingProgress(10);

    const interval = setInterval(() => {
      setUploadingProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setUploadedFiles(prevFiles => ({
            ...prevFiles,
            [`${hkiFormData.jenisHKI}_${docId}`]: {
              name: file.name,
              size: (file.size / 1024).toFixed(1) + ' KB',
              date: new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })
            }
          }));
          setUploadingId(null);
          return 100;
        }
        return prev + 30;
      });
    }, 150);
  };

  const handleRemoveUpload = (docId: string) => {
    setUploadedFiles(prevFiles => {
      const copy = { ...prevFiles };
      delete copy[`${hkiFormData.jenisHKI}_${docId}`];
      return copy;
    });
  };

  const handleCreateRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.namaPrototipe || !formData.judulHKI) {
      alert("Mohon lengkapi Nama Produk Prototipe dan Judul Rekor HKI!");
      return;
    }

    const randomId = `SYN-${Math.floor(100 + Math.random() * 900)}`;
    const newRecord: SinergiRecord = {
      id: randomId,
      namaPrototipe: formData.namaPrototipe,
      tktLevel: Number(formData.tktLevel),
      asalPenelitian: formData.asalPenelitian,
      tahunPenelitian: formData.tahunPenelitian,
      skemaPenelitian: formData.skemaPenelitian,
      implementasiPengabdian: formData.implementasiPengabdian,
      tahunPengabdian: formData.tahunPengabdian,
      skemaPengabdian: formData.skemaPengabdian,
      mitraAbdimas: formData.mitraAbdimas,
      jenisHKI: formData.jenisHKI,
      judulHKI: formData.judulHKI,
      statusPengajuan: formData.statusPengajuan,
      nomorRegistrasiHKI: formData.statusPengajuan === 'Sudah Diajukan' ? (formData.nomorRegistrasiHKI || `REG${Math.floor(100000 + Math.random() * 900000)}`) : '-',
      skTerbit: formData.skTerbit,
      nomorSK: formData.skTerbit === 'Terbit' ? (formData.nomorSK || `SK-HKI/${Math.floor(1000 + Math.random() * 9000)}-2026`) : '-',
      tanggalSK: formData.skTerbit === 'Terbit' ? '12 Juni 2026' : '-',
      reviewerNotes: 'Data hilirisasi diusulkan secara mandiri oleh pengusul melalui Form Sinergi SIM LPPM. Menunggu proses verifikasi keabsahan dokumen oleh admin.'
    };

    setRecords([newRecord, ...records]);
    setSelectedRecordId(randomId);
    setActiveSubTab(0);
    
    // Reset Form
    setFormData({
      namaPrototipe: '',
      tktLevel: 6,
      asalPenelitian: 'Riset Komparatif Pengamanan Sistem Transaksi Elektronik Pekalongan',
      tahunPenelitian: '25/26',
      skemaPenelitian: 'Penelitian fundamental',
      implementasiPengabdian: 'Sosialisasi & Implementasi Aplikasi Pengamanan Data Data UMKM Batik Pekalongan',
      tahunPengabdian: '2026',
      skemaPengabdian: 'Pengabdian Kepada Masyarakat Terpadu',
      mitraAbdimas: 'Koperasi Batik Krapyak Makmur',
      jenisHKI: 'Hak Cipta (Software)',
      judulHKI: '',
      statusPengajuan: 'Sudah Diajukan',
      skTerbit: 'Dalam Proses',
      nomorRegistrasiHKI: '',
      nomorSK: '',
    });

    setSyncMessage("Sukses meregistrasi sinergi hilirisasi prototipe baru!");
  };

  // DJKI Database Synchronization Simulation Action
  const handleDatabaseSync = () => {
    setIsSyncing(true);
    setSyncMessage("Menghubungkan ke API Hub Ditjen KI Kemenkumham & SINTA Dikti...");
    
    setTimeout(() => {
      setSyncMessage("Sinkronisasi database sedang berlangsung... Memverifikasi 3 usulan aktif.");
    }, 1550);

    setTimeout(() => {
      // Transition SYN-02 (Chatbot AI) from 'Dalam Proses' to 'Terbit'
      setRecords(prev => prev.map(rec => {
        if (rec.id === 'SYN-02') {
          return {
            ...rec,
            skTerbit: 'Terbit',
            nomorSK: 'SK-CICTA/DJKI/1502-2026',
            tanggalSK: '12 Juni 2026',
            reviewerNotes: 'HASIL SINKRONISASI OTOMATIS: Kementerian Hukum dan HAM telah merilis Surat Keputusan & Sertifikat Hak Cipta Komputer untuk chatbot syariah ini! SINTA Dikti terupdate secara realtime.'
          };
        }
        return rec;
      }));
      setIsSyncing(false);
      setSyncMessage("SINKRONISASI SELESAI! 1 Surat Keputusan (SK) HKI Baru telah terverifikasi & Sertifikat Hak Cipta terbit secara otomatis.");
    }, 3000);
  };

  const selectedRecord = useMemo(() => {
    return records.find(rec => rec.id === selectedRecordId) || records[0];
  }, [records, selectedRecordId]);

  const filteredRecords = useMemo(() => {
    return records.filter(rec => {
      const matchSearch = 
        rec.namaPrototipe.toLowerCase().includes(searchQuery.toLowerCase()) ||
        rec.asalPenelitian.toLowerCase().includes(searchQuery.toLowerCase()) ||
        rec.judulHKI.toLowerCase().includes(searchQuery.toLowerCase()) ||
        rec.jenisHKI.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchYear = rec.tahunPenelitian.includes(filterYear) || rec.id.includes(filterYear);
      return matchSearch;
    });
  }, [records, searchQuery, filterYear]);

  return (
    <div className={`space-y-4 ${controls.layoutMode === 'compact' ? 'space-y-3' : 'space-y-4'}`}>

      {/* Sync Warning / Toast Banner */}
      {syncMessage && (
        <div className={`p-4 ${isSyncing ? 'bg-blue-50 border-blue-500 text-blue-800' : 'bg-emerald-50 border-emerald-500 text-emerald-800'} border-l-4 rounded text-xs font-bold flex items-center justify-between shadow-xs animate-fade-in`}>
          <div className="flex items-center gap-2">
            {isSyncing ? <RefreshCw className="w-4 h-4 animate-spin text-blue-600" /> : <ShieldCheck className="w-4 h-4 text-emerald-600" />}
            <span>{syncMessage}</span>
          </div>
          {!isSyncing && (
            <button onClick={() => setSyncMessage(null)} className="text-[10px] bg-white/50 hover:bg-white border rounded px-1.5 py-0.5 ml-2">Tutup</button>
          )}
        </div>
      )}

      {/* 1. Aligned TOP Sub-Navigation Tab Bar */}
      <div className="border-b border-gray-200 overflow-x-auto select-none scrollbar-none">
        <div className="flex gap-1.5 min-w-max pb-0.5">
          {subTabs.map((tab, idx) => {
            const isActive = activeSubTab === idx;
            return (
              <button
                key={idx}
                onClick={() => {
                  setActiveSubTab(idx);
                }}
                className={`text-xs px-3.5 py-2 font-semibold transition border-b-2 whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'border-[#1e3a6e] text-[#1e3a6e] font-extrabold'
                    : 'border-transparent text-gray-500 hover:text-[#1e3a6e]'
                }`}
              >
                📦 {tab}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Aligned Form Filter & Info Utility Bar */}
      <div className="flex flex-col sm:flex-row gap-3 justify-between items-stretch sm:items-center">
        <div className="flex gap-2">
          <button 
            onClick={handleDatabaseSync}
            disabled={isSyncing}
            className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold px-3 py-1.5 rounded transition shadow-xs cursor-pointer shrink-0"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>Sinkronisasi Ditjen KI</span>
          </button>
          
          {/* Quick search input */}
          <div className="relative w-full sm:w-64">
            <span className="absolute inset-y-0 left-0 flex items-center pl-2.5 pointer-events-none">
              <Search className="h-3.5 w-3.5 text-gray-400" />
            </span>
            <input
              type="text"
              placeholder="Cari prototipe, HKI, judul..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs bg-white border border-gray-200 rounded py-1.5 pl-8 pr-3 outline-none text-gray-700 focus:border-blue-400 focus:ring-1 focus:ring-blue-100 placeholder:text-gray-400"
            />
          </div>
        </div>

        {/* Filter Inputs right aligned matching TableView */}
        <div className="flex items-center gap-2 justify-end">
          <span className="text-[10px] sm:text-xs font-bold text-gray-600 uppercase tracking-wide flex items-center gap-1 shrink-0">
            <Filter className="w-3 h-3 text-[#1e3a6e]" /> Tahun Sinergi:
          </span>
          <div className="flex items-center gap-1.5 bg-white border border-gray-200 rounded px-2 py-1 shadow-2xs">
            <span className="text-gray-400 text-xs text-[10px]">▼</span>
            <select 
              value={filterYear}
              onChange={(e) => setFilterYear(e.target.value)}
              className="text-xs font-bold text-slate-800 outline-none bg-transparent"
            >
              <option value="25/26">2025/2026</option>
              <option value="24/25">2024/2025</option>
            </select>
          </div>
        </div>
      </div>

      {activeSubTab === 1 ? (
        /* PANEL 1: REGISTER HILIRISASI FORM */
        <div className="max-w-3xl bg-white border border-gray-200 p-6 rounded-xl text-left space-y-4">
          <div className="border-b border-gray-100 pb-3">
            <h3 className="text-xs font-black text-gray-800 uppercase tracking-wider flex items-center gap-2">
              <GitMerge className="w-4 h-4 text-green-700" /> Form Hilirisasi & Sinergi Luaran Terpadu
            </h3>
          </div>

          <form onSubmit={handleCreateRecord} className="space-y-4 text-xs">
            
            <div className="p-4 bg-slate-50/50 rounded-lg space-y-3 border border-slate-100">
              <span className="text-[10px] font-black text-[#1e3a6e] uppercase tracking-wider block">
                ⚙️ 1. Hasil Luaran Prototipe / Produk Fisik
              </span>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2 space-y-1">
                  <label className="font-bold text-gray-700">Nama Produk Prototipe</label>
                  <input
                    type="text"
                    placeholder="Contoh: Router Pengaman Smart Gateway v1.0"
                    value={formData.namaPrototipe}
                    onChange={(e) => setFormData({...formData, namaPrototipe: e.target.value})}
                    className="w-full border border-gray-200 p-2.5 rounded text-gray-800"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-gray-700 block">Tingkat TKT / TRL (1-9)</label>
                  <select
                    value={formData.tktLevel}
                    onChange={(e) => setFormData({...formData, tktLevel: Number(e.target.value)})}
                    className="w-full bg-white border border-gray-200 p-2.5 rounded font-bold text-gray-700"
                  >
                    <option value="5">TKT 5 - Validasi Lab</option>
                    <option value="6">TKT 6 - Komponen Lapangan Terbatas</option>
                    <option value="7">TKT 7 - Demo Lapangan Operasional</option>
                    <option value="8">TKT 8 - Sistem Seutuhnya Teruji</option>
                    <option value="9">TKT 9 - Komersialisasi Luas</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="p-4 bg-blue-50/20 rounded-lg space-y-3.5 border border-blue-100">
              <span className="text-[10px] font-black text-blue-900 uppercase tracking-wider block">
                📖 2. Hulu Penelitian Origin
              </span>
              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="font-bold text-gray-700">Judul Penelitian Asal</label>
                  <input
                    type="text"
                    value={formData.asalPenelitian}
                    onChange={(e) => setFormData({...formData, asalPenelitian: e.target.value})}
                    className="w-full border border-gray-200 p-2.5 rounded text-gray-800"
                  />
                </div>
              </div>
            </div>

            <div className="p-4 bg-emerald-50/10 rounded-lg space-y-3 border border-emerald-100">
              <span className="text-[10px] font-black text-emerald-900 uppercase tracking-wider block">
                🔒 3. Pendaftaran Kekayaan Intelektual (HKI)
              </span>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-gray-700">Jenis Hak KI / Paten</label>
                  <select
                    value={formData.jenisHKI}
                    onChange={(e) => setFormData({...formData, jenisHKI: e.target.value as SinergiRecord['jenisHKI']})}
                    className="w-full bg-white border border-gray-200 p-2.5 rounded font-extrabold text-gray-700"
                  >
                    <option value="Paten Sederhana">Paten Sederhana</option>
                    <option value="Hak Cipta (Software)">Hak Cipta (Software / Web)</option>
                    <option value="Hak Cipta (Buku/Panduan)">Hak Cipta (Buku / Karya Tulis)</option>
                    <option value="Desain Industri">Desain Industri</option>
                    <option value="Merek Dagang">Merek Dagang</option>
                  </select>
                </div>

                <div className="md:col-span-2 space-y-1">
                  <label className="font-bold text-gray-700">Nama/Judul di Berkas HKI</label>
                  <input
                    type="text"
                    placeholder="Contoh: Modul Perangkat Keras irigasi cerdas..."
                    value={formData.judulHKI}
                    onChange={(e) => setFormData({...formData, judulHKI: e.target.value})}
                    className="w-full border border-gray-200 p-2.5 rounded text-gray-800"
                  />
                </div>
              </div>
            </div>

            <div className="pt-4 border-t flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setActiveSubTab(0)}
                className="px-4 py-2 bg-slate-100 border border-gray-200 hover:bg-slate-200 text-gray-600 rounded transition font-bold"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-[#1e3a6e] hover:bg-slate-900 text-white rounded shadow-sm transition font-bold flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Simpan Hilirisasi</span>
              </button>
            </div>
          </form>
        </div>
      ) : activeSubTab === 2 ? (
        /* PANEL 2: NEW AJUKAN PENDAFTARAN HKI FORM & GUIDELINES BRIEF CO-INVENTORS AND DYNAMIC DOCUMENT UPLOADERS */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start text-left animate-fade-in text-xs">
          
          {/* Main Form (Left Column, Span 8) */}
          <div className="lg:col-span-8 bg-white border border-gray-200 rounded-xl shadow-xs p-5 sm:p-6 space-y-5">
            <div className="border-b border-gray-100 pb-3">
              <h3 className="text-sm font-black text-[#1e3a6e] uppercase tracking-wider flex items-center gap-2">
                <Award className="w-5 h-5 text-[#1e3a6e]" /> Formulir Pengajuan Pendaftaran Hak Kekayaan Intelektual (HKI)
              </h3>
              <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                Sentra Kekayaan Intelektual LPPM ITSNU Pekalongan memfasilitasi pelindungan hukum invensi & karya cipta sivitas akademika. Isi data di bawah ini beserta lampiran dokumen administrasi wajib.
              </p>
            </div>

            <form onSubmit={handleCreateHkiApplication} className="space-y-5">
              
              {/* Seksyen 1: Identitas & Jenis HKI */}
              <div className="p-4 bg-slate-50/50 rounded-lg space-y-3.5 border border-slate-100">
                <span className="text-[10px] font-black text-indigo-900 uppercase tracking-wider block">
                  ⚙️ Seksyen 1: Rincian & Kategori Hak Kekayaan Intelektual
                </span>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="font-bold text-gray-700 block">Kategori / Jenis HKI <span className="text-rose-600">*</span></label>
                    <select
                      value={hkiFormData.jenisHKI}
                      onChange={(e) => {
                        setHkiFormData({
                          ...hkiFormData,
                          jenisHKI: e.target.value as SinergiRecord['jenisHKI']
                        });
                      }}
                      className="w-full bg-white border border-gray-200 p-2 text-gray-800 font-extrabold focus:ring-1 focus:ring-indigo-100 outline-none"
                    >
                      <option value="Hak Cipta (Software)">Hak Cipta (Software / Web)</option>
                      <option value="Hak Cipta (Buku/Panduan)">Hak Cipta (Buku / Karya Tulis)</option>
                      <option value="Paten Sederhana">Paten Sederhana</option>
                      <option value="Desain Industri">Desain Industri</option>
                      <option value="Merek Dagang">Merek Dagang</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-gray-700 block">Nama Prototipe / Produk Hasil Riset <span className="text-rose-600">*</span></label>
                    <input
                      type="text"
                      value={hkiFormData.namaPrototipe}
                      onChange={(e) => setHkiFormData({...hkiFormData, namaPrototipe: e.target.value})}
                      className="w-full border border-gray-200 p-2 rounded text-gray-800 outline-none focus:border-indigo-400"
                      placeholder="Contoh: Router Pengaman Smart Gateway v1.0"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1 col-span-2">
                  <label className="font-bold text-gray-700 block">Judul Resmi Karya HKI (Sesuai berkas permohonan) <span className="text-rose-600">*</span></label>
                  <input
                    type="text"
                    value={hkiFormData.judulHKI}
                    onChange={(e) => setHkiFormData({...hkiFormData, judulHKI: e.target.value})}
                    className="w-full border border-gray-200 p-2 rounded text-gray-800 font-bold outline-none focus:border-indigo-400"
                    placeholder="Contoh: ALAT DETEKSI BANJIR PEKALONGAN UTARA BERBASIS RADAR INTERAKTIF..."
                    required
                  />
                  <span className="text-[10px] text-gray-400 font-medium block">Tulis lengkap dalam HURUF KAPITAL. Judul ini akan tercetak langsung di sertifikat resmi Kemenkumham.</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="font-bold text-gray-700 block">Hulu Penelitian Origin (SINTA terkait)</label>
                    <input
                      type="text"
                      value={hkiFormData.asalPenelitian}
                      onChange={(e) => setHkiFormData({...hkiFormData, asalPenelitian: e.target.value})}
                      className="w-full border border-gray-200 p-2 rounded text-gray-800 outline-none bg-white"
                      placeholder="Judul penelitian hibah asal..."
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-gray-700 block">Hilir Mitra Sasaran (Penerapan Abdimas)</label>
                    <input
                      type="text"
                      value={hkiFormData.mitraAbdimas}
                      onChange={(e) => setHkiFormData({...hkiFormData, mitraAbdimas: e.target.value})}
                      className="w-full border border-gray-200 p-2 rounded text-gray-800 outline-none bg-white"
                      placeholder="Kelompok tani, UMKM, sekolah, dll..."
                    />
                  </div>
                </div>
              </div>

              {/* Seksyen 2: Inventor / Pencipta Roster */}
              <div className="p-4 bg-indigo-50/10 rounded-lg space-y-3.5 border border-indigo-100">
                <div className="flex justify-between items-center flex-wrap gap-2">
                  <span className="text-[10px] font-black text-indigo-900 uppercase tracking-wider block">
                    👥 Seksyen 2: Daftar Pencipta / Inventor ({hkiFormData.inventors.length} Orang)
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setHkiFormData({
                        ...hkiFormData,
                        inventors: [
                          ...hkiFormData.inventors,
                          { nama: '', jabatan: 'Anggota (Dosen)', nidn: '' }
                        ]
                      });
                    }}
                    className="flex items-center gap-1 text-[10px] bg-indigo-50 hover:bg-indigo-100 text-indigo-800 font-bold px-2 py-1.5 rounded transition border border-indigo-200 cursor-pointer"
                  >
                    <UserPlus className="w-3.5 h-3.5 text-indigo-700" /> Tambah Pencipta/Inventor Baru
                  </button>
                </div>

                <div className="space-y-2">
                  {hkiFormData.inventors.map((inv, idx) => (
                    <div key={idx} className="flex flex-col sm:flex-row gap-2.5 bg-white p-3 rounded border border-gray-150 items-start">
                      <div className="flex-1 space-y-1">
                        <label className="text-[9.5px] font-bold text-gray-500 uppercase">Nama Pencipta & Gelar <span className="text-rose-600">*</span></label>
                        <input
                          type="text"
                          value={inv.nama}
                          onChange={(e) => {
                            const newInventors = [...hkiFormData.inventors];
                            newInventors[idx].nama = e.target.value;
                            setHkiFormData({ ...hkiFormData, inventors: newInventors });
                          }}
                          placeholder="Nama lengkap dan gelar..."
                          className="w-full border border-gray-200 p-1.5 rounded text-gray-800 outline-none focus:border-indigo-350 font-bold"
                          required
                        />
                      </div>
                      
                      <div className="w-full sm:w-44 space-y-1">
                        <label className="text-[9.5px] font-bold text-gray-500 uppercase">Peran / Jabatan</label>
                        <select
                          value={inv.jabatan}
                          onChange={(e) => {
                            const newInventors = [...hkiFormData.inventors];
                            newInventors[idx].jabatan = e.target.value;
                            setHkiFormData({ ...hkiFormData, inventors: newInventors });
                          }}
                          className="w-full bg-white border border-gray-200 p-1.5 rounded text-gray-700 outline-none"
                        >
                          <option value="Ketua Inventor (Dosen)">Ketua Pencipta / Inventor</option>
                          <option value="Anggota (Dosen)">Anggota Dosen</option>
                          <option value="Anggota (Mahasiswa)">Anggota Mahasiswa</option>
                        </select>
                      </div>

                      <div className="w-full sm:w-40 space-y-1">
                        <label className="text-[9.5px] font-bold text-gray-500 uppercase">NIDN / NIM <span className="text-rose-600">*</span></label>
                        <input
                          type="text"
                          value={inv.nidn}
                          onChange={(e) => {
                            const newInventors = [...hkiFormData.inventors];
                            newInventors[idx].nidn = e.target.value;
                            setHkiFormData({ ...hkiFormData, inventors: newInventors });
                          }}
                          placeholder="Sesuai SINTA/PDDIKTI..."
                          className="w-full border border-gray-200 p-1.5 rounded text-gray-800 outline-none focus:border-indigo-350 font-mono"
                          required
                        />
                      </div>

                      {idx > 0 && (
                        <button
                          type="button"
                          onClick={() => {
                            const newInventors = hkiFormData.inventors.filter((_, i) => i !== idx);
                            setHkiFormData({ ...hkiFormData, inventors: newInventors });
                          }}
                          className="sm:self-end p-1.5 text-rose-600 hover:bg-rose-50 rounded transition border border-rose-100 hover:border-rose-200 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Seksyen 3: Unggah Berkas Dynamic Section */}
              <div className="p-4 bg-emerald-50/10 rounded-lg space-y-4 border border-emerald-100/60">
                <span className="text-[10px] font-black text-emerald-900 uppercase tracking-wider block">
                  📂 Seksyen 3: Dokumen Syarat Unggah ({hkiFormData.jenisHKI})
                </span>

                <div className="bg-emerald-50 p-3 rounded-lg border border-emerald-150 text-emerald-950 flex items-start gap-2.5">
                  <Info className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                  <div className="space-y-0.5 leading-relaxed font-semibold">
                    <p className="font-extrabold text-[11.5px]">Petunjuk Pengunggahan Berkas Administrasi:</p>
                    <p>
                      Masing-masing jenis Hak Kekayaan Intelektual memerlukan berkas spesifik berbeda. Silakan tinjau dan penuhi berkas wajib (<span className="text-rose-600 font-bold">*</span>) di bawah ini. Anda dapat mengunduh format draf baku di sidebar sebelah kanan jika belum memilikinya.
                    </p>
                  </div>
                </div>

                {/* Requirements Cards */}
                <div className="space-y-3">
                  {(HKI_DOCS_METADATA[hkiFormData.jenisHKI] || []).map((reqDoc) => {
                    const fileKey = `${hkiFormData.jenisHKI}_${reqDoc.id}`;
                    const fileData = uploadedFiles[fileKey];
                    const hasUploaded = !!fileData;
                    const isDocUploading = uploadingId === reqDoc.id;

                    return (
                      <div 
                        key={reqDoc.id} 
                        className={`p-3.5 rounded-lg border transition flex flex-col md:flex-row md:items-center justify-between gap-3 ${
                          hasUploaded 
                            ? 'bg-emerald-50/30 border-emerald-300' 
                            : 'bg-white border-gray-200 hover:border-indigo-150'
                        }`}
                      >
                        <div className="space-y-1 max-w-xl">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-bold text-gray-800 text-xs">{reqDoc.name}</span>
                            {reqDoc.required ? (
                              <span className="bg-rose-50 text-rose-600 text-[10px] font-black px-1.5 py-0.5 rounded border border-rose-100 uppercase">Wajib *</span>
                            ) : (
                              <span className="bg-slate-100 text-gray-500 text-[10px] font-bold px-1.5 py-0.5 rounded border border-gray-150">Opsional</span>
                            )}
                            <span className="bg-blue-50 text-blue-900 text-[9.5px] font-mono font-black border border-blue-200 px-1.5 rounded uppercase">{reqDoc.format}</span>
                          </div>
                          <p className="text-gray-500 font-medium leading-relaxed font-sans">{reqDoc.description}</p>
                        </div>

                        {/* Upload Controls */}
                        <div className="shrink-0 flex items-center gap-2">
                          {isDocUploading ? (
                            <div className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 border border-indigo-200 rounded text-indigo-800 font-semibold text-[11px] animate-pulse">
                              <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-600" />
                              <span>Mengunggah ({uploadingProgress}%)</span>
                            </div>
                          ) : hasUploaded ? (
                            <div className="flex items-center gap-2">
                              <span className="bg-emerald-100 text-emerald-800 border-emerald-250 border flex items-center gap-1 font-bold text-[10px] py-1 px-2.5 rounded-md">
                                <FileCheck className="w-3.5 h-3.5 text-emerald-700" />
                                {fileData.name.length > 20 ? fileData.name.slice(0, 20) + '...' : fileData.name} ({fileData.size})
                              </span>
                              <button
                                type="button"
                                onClick={() => handleRemoveUpload(reqDoc.id)}
                                className="p-1 px-1.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-600 rounded transition cursor-pointer"
                                title="Hapus berkas"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ) : (
                            <div className="relative">
                              <input
                                id={`file-input-${reqDoc.id}`}
                                type="file"
                                onChange={(e) => handleSimulateUpload(reqDoc.id, e)}
                                className="hidden"
                              />
                              <label
                                htmlFor={`file-input-${reqDoc.id}`}
                                className="flex items-center gap-1.5 bg-[#16a34a] hover:bg-[#15803d] text-white font-bold text-[11px] px-3.5 py-1.5 rounded shadow-2xs transition cursor-pointer select-none"
                              >
                                <Upload className="w-3.5 h-3.5" />
                                <span>Unggah Berkas</span>
                              </label>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t flex justify-end gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setActiveSubTab(0)}
                  className="px-4 py-2 bg-slate-100 border border-gray-200 hover:bg-slate-200 text-gray-600 font-bold transition rounded shadow-2xs"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#1e3a6e] hover:bg-slate-900 text-white font-bold transition rounded shadow-sm flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Kirim Pendaftaran HKI</span>
                </button>
              </div>
            </form>
          </div>

          {/* Quick sidebar templates & guidelines (Right Column, Span 4) */}
          <div className="lg:col-span-4 space-y-4">
            
            {/* Download Templates Panel */}
            <div className="bg-white border border-gray-200 rounded-xl p-5 space-y-4 shadow-xs">
              <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5 border-b pb-2">
                <Download className="w-4 h-4 text-[#1e3a6e]" /> Panduan & Templat Baku Resmi
              </h4>
              <p className="text-[10.5px] font-medium text-gray-500 leading-relaxed font-sans">
                Gunakan draf baku legal yang disediakan LPPM di bawah ini agar berkas administrasi langsung lolos validasi administrasi Ditjen KI.
              </p>

              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => setShowTemplateModal('pernyataan_hak')}
                  className="w-full bg-slate-50 hover:bg-indigo-50 border border-slate-150 p-2.5 rounded-lg text-left transition block flex items-start gap-2.5 group cursor-pointer"
                >
                  <FileText className="w-4.5 h-4.5 text-indigo-700 shrink-0 mt-0.5 group-hover:scale-110 transition" />
                  <div>
                    <span className="font-extrabold text-gray-800 text-[11px] block leading-snug group-hover:text-indigo-900">Surat Pernyataan Hak Cipta / Invensi</span>
                    <span className="text-[9.5px] text-gray-400 block font-normal pt-0.5">Format MS Word dengan Meterai Rp 10kr</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setShowTemplateModal('pengalihan_hak')}
                  className="w-full bg-slate-50 hover:bg-indigo-55 border border-slate-150 p-2.5 rounded-lg text-left transition block flex items-start gap-2.5 group cursor-pointer"
                >
                  <GitMerge className="w-4.5 h-4.5 text-indigo-700 shrink-0 mt-0.5 group-hover:scale-110 transition" />
                  <div>
                    <span className="font-extrabold text-gray-800 text-[11px] block leading-snug group-hover:text-indigo-900">Surat Pengalihan Hak Milik (TS)</span>
                    <span className="text-[9.5px] text-gray-400 block font-normal pt-0.5">Format pelimpahan hak ekonomi ke ITSNU</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setShowTemplateModal('deskripsi_paten')}
                  className="w-full bg-slate-50 hover:bg-indigo-50 border border-slate-150 p-2.5 rounded-lg text-left transition block flex items-start gap-2.5 group cursor-pointer"
                >
                  <Award className="w-4.5 h-4.5 text-indigo-700 shrink-0 mt-0.5 group-hover:scale-110 transition" />
                  <div>
                    <span className="font-extrabold text-gray-800 text-[11px] block leading-snug group-hover:text-indigo-900">SOP Spesifikasi Deskripsi Paten</span>
                    <span className="text-[9.5px] text-gray-400 block font-normal pt-0.5">Panduan penulisan Abstrak, Klaim, & Gambar</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setShowTemplateModal('etiket_merek')}
                  className="w-full bg-slate-50 hover:bg-indigo-50 border border-slate-150 p-2.5 rounded-lg text-left transition block flex items-start gap-2.5 group cursor-pointer"
                >
                  <Layers className="w-4.5 h-4.5 text-indigo-705 shrink-0 mt-0.5 group-hover:scale-110 transition" />
                  <div>
                    <span className="font-extrabold text-gray-800 text-[11px] block leading-snug group-hover:text-indigo-900">Aturan Etiket Gambar Merek</span>
                    <span className="text-[9.5px] text-gray-400 block font-normal pt-0.5">Ukuran, pixel, ketajaman, dan kombinasi kelas</span>
                  </div>
                </button>
              </div>
            </div>

            {/* SOP Flow card banner */}
            <div className="bg-[#1e3a6e] text-white rounded-xl p-5 space-y-3.5 shadow-xs text-left relative overflow-hidden">
              <div className="absolute right-0 bottom-0 opacity-10 font-black text-6xl select-none leading-none translate-y-3 translate-x-3">SENTRA KI</div>
              <h4 className="text-xs font-black uppercase tracking-wider flex items-center gap-1.5 text-emerald-400">
                <ShieldCheck className="w-4.5 h-4.5" /> Jaminan Sinkronisasi Terpadu:
              </h4>
              <p className="text-[10px] leading-relaxed font-medium text-emerald-50">
                Setiap permohonan yang berkasnya dinyatakan lengkap oleh LPPM akan diajukan ke portal e-HakCipta / portal SIPP Ditjen KI Kemenkumham RI secara terpadu.
              </p>
              <div className="p-2.5 bg-slate-950/45 rounded-lg text-[9.5px] leading-snug space-y-1.5 font-sans font-medium text-slate-100">
                <div className="flex gap-1.5">
                  <span className="text-emerald-400 font-bold font-mono">1.</span>
                  <span><strong>Unggah Lengkap:</strong> Seluruh file yang bertanda bintang wajib terunggah.</span>
                </div>
                <div className="flex gap-1.5">
                  <span className="text-emerald-400 font-bold font-mono">2.</span>
                  <span><strong>Validasi LPPM:</strong> Validasi administrasi tanda tangan basah & dokumen penunjang.</span>
                </div>
                <div className="flex gap-1.5">
                  <span className="text-emerald-400 font-bold font-mono">3.</span>
                  <span><strong>E-Certificate DJKI:</strong> SK Menteri Hukum & HAM terbit elektronik dan diunduh di SULTAN.</span>
                </div>
              </div>
            </div>

            {/* Contact administrator info */}
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg text-xs flex items-start gap-2 text-left">
              <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <div className="space-y-0.5 leading-relaxed text-slate-800">
                <span className="font-extrabold text-amber-950 block">Butuh Bantuan Draft Klaim Paten?</span>
                <span className="font-medium text-slate-700">Konsultasikan langsung dengan Sentra HKI LPPM (Kontak admin: <strong>Zulfa Hanum, S.Kom.</strong> atau Kepala LPPM Gedung Rektorat Lt. 2 ITSNU Pekalongan).</span>
              </div>
            </div>

          </div>

        </div>
      ) : activeSubTab === 4 ? (
        /* ATURAN LUARAN TERPADU PANEL */
        <div className="bg-white border border-gray-200 p-6 rounded-xl text-left space-y-3">
          <h4 className="text-xs font-black text-[#1e3a6e] uppercase tracking-tight">💡 Aturan Sinergi hilirisasi Penelitian & Pengabdian</h4>
          <p className="text-xs text-gray-500 leading-relaxed font-semibold">
            Sinergi Hilirisasi Terpadu (SUT) mengukur seberapa jauh hasil luaran riset murni dikembangkan menjadi prototipe fungsional (TRL level 5-8), diterapkan langsung dalam pengabdian kemitraan masyarakat, lalu diamankan hak ciptanya di portal Kemenkumham Ditjen KI.
          </p>
        </div>
      ) : (
        /* MAIN LIST TABLE ALIGNED WITH TABLEVIEW */
        <div className="space-y-4">
          
          <div className={`overflow-hidden bg-white border border-gray-200 ${roundedClass} shadow-xs`}>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[950px]">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-100">
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 text-center w-12">No</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 w-32">Id Sinergi</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 w-80">Produk Prototipe Fungsional</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3 w-28 text-center">TKT Level</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3">Judul Luaran HKI (Jenis)</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3">Hulu Penelitian</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3">Hilir Pengabdian (Mitra)</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3 text-center w-36">Status DJKI</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 text-center w-36">Catatan LPPM</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 text-center w-14">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 text-xs text-left">
                  {filteredRecords.length > 0 ? (
                    filteredRecords.map((rec, idx) => {
                      const isSelected = rec.id === selectedRecordId;
                      const matchesTabFilter = 
                        activeSubTab === 0 
                        ? true // Semua monitoring
                        : activeSubTab === 2 
                        ? rec.skTerbit === 'Dalam Proses' // Sedang sinkronisasi / proses
                        : true;

                      if (!matchesTabFilter) return null;

                      return (
                        <tr 
                          key={rec.id} 
                          className={`hover:bg-slate-50/50 transition cursor-pointer ${
                            isSelected ? 'bg-blue-50/30' : ''
                          }`}
                          onClick={() => setSelectedRecordId(rec.id)}
                        >
                          {/* Col 1: No */}
                          <td className="py-4 px-4 text-center font-bold text-gray-400 select-none">{idx + 1}</td>
                          
                          {/* Col 2: ID */}
                          <td className="py-4 px-4 font-mono font-bold text-sky-850">
                            {rec.id}
                          </td>

                          {/* Col 3: Prototype Name */}
                          <td className="py-4 px-4 font-extrabold text-gray-950">
                            {rec.namaPrototipe}
                          </td>

                          {/* Col 4: TKT Level */}
                          <td className="py-4 px-3 text-center">
                            <span className="bg-indigo-50 text-indigo-700 border border-indigo-200 font-extrabold px-2.5 py-0.5 rounded text-[10px] font-mono whitespace-nowrap">
                              LEVEL {rec.tktLevel}
                            </span>
                          </td>

                          {/* Col 5: HKI */}
                          <td className="py-4 px-3 font-semibold text-gray-700">
                            <div className="text-[#1e3a6e] font-extrabold leading-snug">{rec.judulHKI}</div>
                            <span className="text-[9.5px] font-medium text-gray-400 block font-sans pt-0.5 uppercase">({rec.jenisHKI})</span>
                          </td>

                          {/* Col 6: Research */}
                          <td className="py-4 px-3 text-gray-500 line-clamp-2 md:line-clamp-none leading-relaxed italic max-w-[200px]">
                            "{rec.asalPenelitian}"
                          </td>

                          {/* Col 7: Abdimas */}
                          <td className="py-4 px-3 text-gray-600 font-medium leading-relaxed max-w-[200px]">
                            📍 {rec.mitraAbdimas}
                          </td>

                          {/* Col 8: Status DJKI */}
                          <td className="py-4 px-3 text-center">
                            {rec.skTerbit === 'Terbit' ? (
                              <span className="inline-block border px-2 py-0.5 rounded text-[9.5px] font-black bg-emerald-50 text-emerald-800 border-emerald-300 uppercase text-center w-full">
                                SK TERBIT
                              </span>
                            ) : rec.skTerbit === 'Dalam Proses' ? (
                              <span className="inline-block border px-2 py-0.5 rounded text-[9.5px] font-black bg-amber-50 text-amber-800 border-amber-300 uppercase text-center w-full">
                                PROSES
                              </span>
                            ) : (
                              <span className="inline-block border px-2 py-0.5 rounded text-[9.5px] font-black bg-slate-100 text-slate-700 border-slate-200 uppercase text-center w-full">
                                DRAF
                              </span>
                            )}
                          </td>

                          {/* Col 9: Catatan LPPM */}
                          <td className="py-4 px-3 text-center">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedRecordId(rec.id);
                              }}
                              className="text-[9.5px] bg-[#1e3a6e] hover:bg-slate-800 text-white font-bold px-2.5 py-1 rounded transition w-full"
                            >
                              Catatan LPPM
                            </button>
                          </td>

                          {/* Col 10: Action detail */}
                          <td className="py-4 px-4 text-center">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedRecordId(rec.id);
                              }}
                              className="p-1.5 bg-blue-500 hover:bg-blue-600 text-white rounded transition cursor-pointer"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={10} className="py-8 text-center text-gray-400 font-bold">
                        Tidak ada hilirisasi terdaftar.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* LOWER SECTION: DETAIL METRIC VISUALIZER AND DJKI SINTA CONNECTION NOTES */}
          {selectedRecord && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start mt-4">
              
              {/* Left detail grid card */}
              <div className="lg:col-span-8 bg-white border border-gray-200 rounded-xl shadow-xs p-5 space-y-4 text-left">
                <div className="flex justify-between items-center border-b pb-2">
                  <span className="text-xs font-black text-slate-800 uppercase tracking-tight flex items-center gap-1">
                    🔍 Detil Kematangan & Progress Alur Sinergi ({selectedRecord.id})
                  </span>
                  <span className="text-[9px] font-mono bg-blue-50 text-blue-900 border px-2 py-0.5 rounded font-bold uppercase">SINTA READY</span>
                </div>

                {/* TRL Level visualizer scale bar */}
                <div className="bg-slate-50 p-4 rounded-lg border border-gray-150 space-y-2">
                  <div className="flex justify-between items-center text-[10px] font-black text-slate-700 uppercase tracking-tight">
                    <span>Tingkat Kesiapterapan Teknologi (TRL / TKT)</span>
                    <span className="text-indigo-700 font-extrabold">Level {selectedRecord.tktLevel} dari 9</span>
                  </div>
                  
                  {/* Visual bar container */}
                  <div className="w-full h-2.5 bg-gray-200 rounded-full overflow-hidden flex">
                    {Array.from({ length: 9 }).map((_, idx) => {
                      const level = idx + 1;
                      const isActive = level <= selectedRecord.tktLevel;
                      return (
                        <div 
                          key={idx}
                          className={`h-full flex-1 border-r border-white last:border-0 ${
                            isActive 
                              ? 'bg-gradient-to-r from-indigo-500 to-blue-600' 
                              : 'bg-gray-200'
                          }`}
                        />
                      );
                    })}
                  </div>
                  
                  <p className="text-[10.5px] text-gray-500 font-medium leading-relaxed pt-0.5">
                    {selectedRecord.tktLevel >= 7 
                      ? '✓ Hasil luaran prototipe fisik fungsional telah terpasang dan beroperasi penuh di kalangan mitra masyarakat.' 
                      : '✓ Model sistem fungsional telah divalidasi dan lolos pengujian laboratorium terbatas.'}
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-medium">
                  <div className="p-3 bg-blue-50/20 border rounded space-y-1.5">
                    <span className="text-[#1e3a6e] font-extrabold text-[9.5px] uppercase block">1. Hulu Penelitian Origin</span>
                    <p className="text-slate-800 leading-relaxed font-bold">"{selectedRecord.asalPenelitian}"</p>
                    <div className="pt-1 text-[10px] text-gray-400 font-mono font-bold leading-none">Skema: {selectedRecord.skemaPenelitian}</div>
                  </div>

                  <div className="p-3 bg-orange-50/20 border rounded space-y-1.5">
                    <span className="text-amber-800 font-extrabold text-[9.5px] uppercase block">2. Hilir Penerapan Abdimas</span>
                    <p className="text-slate-800 leading-relaxed font-bold">"{selectedRecord.implementasiPengabdian}"</p>
                    <div className="pt-1 text-[10px] text-gray-400 font-mono font-bold leading-none">Mitra: {selectedRecord.mitraAbdimas}</div>
                  </div>
                </div>
              </div>

              {/* Right Comments panel */}
              <div className="lg:col-span-4 space-y-4 text-left">
                <div className="p-4 bg-amber-50 border-l-4 border-amber-500 rounded text-xs space-y-1 relative">
                  <div className="flex items-center gap-1.5 text-amber-950 font-bold">
                    <MessageSquare className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span>Ulasan / Reviewer Komentar LPPM:</span>
                  </div>
                  <p className="text-gray-900 leading-relaxed font-semibold">"{selectedRecord.reviewerNotes}"</p>
                </div>

                <div className="p-4 bg-white border rounded-xl text-xs space-y-2">
                  <span className="font-extrabold text-indigo-700 uppercase tracking-widest text-[9.5px]">Status Registrasi DJKI</span>
                  <div className="space-y-1 text-gray-600 font-medium">
                    <div className="flex justify-between">
                      <span>No Registrasi:</span>
                      <strong className="font-mono">{selectedRecord.nomorRegistrasiHKI}</strong>
                    </div>
                    {selectedRecord.skTerbit === 'Terbit' && (
                      <div className="space-y-1 pt-1.5 border-t">
                        <div className="flex justify-between">
                          <span>Nomor SK KI:</span>
                          <strong className="font-mono text-emerald-800">{selectedRecord.nomorSK}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span>Tanggal SK:</span>
                          <span>{selectedRecord.tanggalSK}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>
      )}

    </div>
  );
}
