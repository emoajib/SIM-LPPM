import React from 'react';
import { ThemePreset, CustomControls } from '../types';
import { themePresets } from '../data/presets';
import { Palette, Layout, Sliders, Code, Eye, RefreshCw, Layers } from 'lucide-react';

interface ThemeSelectorProps {
  selectedPreset: ThemePreset;
  onSelectPreset: (preset: ThemePreset) => void;
  controls: CustomControls;
  onUpdateControls: (updater: (prev: CustomControls) => CustomControls) => void;
  onResetControls: () => void;
}

export default function ThemeSelector({
  selectedPreset,
  onSelectPreset,
  controls,
  onUpdateControls,
  onResetControls
}: ThemeSelectorProps) {
  return (
    <div className="bg-white border-b border-gray-200 shadow-sm p-4 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-4 items-center justify-between">
        
        {/* Left: Brand Playground Info */}
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
            <Palette className="w-5 h-5 text-indigo-600" />
          </div>
          <div>
            <h1 className="text-base font-bold text-gray-900 tracking-tight flex items-center gap-2">
              <span>Universal Dashboard Playground</span>
              <span className="text-[10px] bg-indigo-100 text-indigo-700 font-semibold px-2 py-0.5 rounded-full">v4.0 PRO</span>
            </h1>
            <p className="text-xs text-gray-500">Sesuaikan layout, skema warna, & ekspor template Tailwind siap pakai</p>
          </div>
        </div>

        {/* Center: Presets Select */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-start md:justify-center">
          <span className="text-xs font-semibold text-gray-600 flex items-center gap-1">
            <Layers className="w-3.5 h-3.5 text-gray-400" /> Pilih Tema:
          </span>
          <div className="flex gap-1.5 overflow-x-auto py-1">
            {themePresets.map((preset) => {
              const isSelected = preset.id === selectedPreset.id;
              return (
                <button
                  key={preset.id}
                  onClick={() => onSelectPreset(preset)}
                  id={`preset-btn-${preset.id}`}
                  className={`text-xs px-3 py-1.5 font-medium rounded-md transition-all duration-200 cursor-pointer ${
                    isSelected
                      ? 'bg-[#1e3a6e] text-white shadow-sm ring-2 ring-blue-400 ring-offset-1'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {preset.name.split(' (')[0]}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Quick actions to see the code */}
        <div className="flex items-center gap-2 w-full md:w-auto justify-end">
          <button
            onClick={() => onUpdateControls((prev) => ({ ...prev, showCodeModal: true }))}
            id="view-code-btn"
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3.5 py-2 rounded-md shadow-sm transition-all cursor-pointer"
          >
            <Code className="w-3.5 h-3.5" />
            <span>Ekspor Kode Template</span>
          </button>
          
          <button
            onClick={onResetControls}
            title="Reset Modifikasi"
            id="reset-playground-btn"
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-md transition duration-150 border border-gray-100"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Sub menu: Controls & Toggles drawer style */}
      <div className="max-w-7xl mx-auto mt-4 pt-3 border-t border-gray-100 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Border Radius Control */}
        <div className="space-y-1">
          <label className="text-[10.5px] font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1">
            <Layout className="w-3 h-3 text-gray-400" /> Kelengkungan (Radius)
          </label>
          <div className="grid grid-cols-4 gap-1">
            {(['none', 'md', 'xl', 'full'] as const).map((r) => (
              <button
                key={r}
                onClick={() => onUpdateControls((prev) => ({ ...prev, roundedMode: r }))}
                id={`radius-${r}`}
                className={`text-[10px] py-1 border rounded-md font-medium text-center transition capitalize ${
                  controls.roundedMode === r
                    ? 'bg-indigo-50 border-indigo-400 text-indigo-700 font-bold'
                    : 'border-gray-200 text-gray-600 hover:bg-gray-50'
                }`}
              >
                {r === 'none' ? '0' : r === 'md' ? 'md' : r === 'xl' ? 'xl' : 'max'}
              </button>
            ))}
          </div>
        </div>

        {/* Layout Mode Control */}
        <div className="space-y-1">
          <label className="text-[10.5px] font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1">
            <Sliders className="w-3 h-3 text-gray-400" /> Model Layout
          </label>
          <div className="grid grid-cols-3 gap-1">
            {(['split', 'fullwidth', 'compact'] as const).map((m) => (
              <button
                key={m}
                onClick={() => onUpdateControls((prev) => ({ ...prev, layoutMode: m }))}
                id={`layout-${m}`}
                className={`text-[10px] py-1 border rounded-md font-medium text-center transition capitalize ${
                  controls.layoutMode === m
                    ? 'bg-indigo-50 border-indigo-400 text-indigo-700 font-bold'
                    : 'border-gray-200 text-gray-600 hover:bg-gray-50'
                }`}
              >
                {m === 'split' ? 'Split' : m === 'fullwidth' ? 'Full' : 'Kompak'}
              </button>
            ))}
          </div>
        </div>

        {/* Visibility toggles */}
        <div className="space-y-1 sm:col-span-1 lg:col-span-4 grid grid-cols-2 sm:grid-cols-4 gap-2">
          {/* Toggle Widget Stats */}
          <div className="flex flex-col justify-end">
            <button
              onClick={() => onUpdateControls((prev) => ({ ...prev, showStats: !prev.showStats }))}
              id="toggle-stats-btn"
              className={`w-full py-1.5 px-2 border rounded-md text-left text-xs font-medium flex items-center justify-between transition ${
                controls.showStats 
                  ? 'bg-emerald-50/50 border-emerald-300 text-emerald-800' 
                  : 'bg-gray-50 border-gray-200 text-gray-400 line-through'
              }`}
            >
              <span className="truncate">📈 Tampilkan Stats</span>
              <span className={`w-2 h-2 rounded-full ${controls.showStats ? 'bg-emerald-500' : 'bg-gray-300'}`}></span>
            </button>
          </div>

          {/* Toggle Chart Graph */}
          <div className="flex flex-col justify-end">
            <button
              onClick={() => onUpdateControls((prev) => ({ ...prev, showChart: !prev.showChart }))}
              id="toggle-chart-btn"
              className={`w-full py-1.5 px-2 border rounded-md text-left text-xs font-medium flex items-center justify-between transition ${
                controls.showChart 
                  ? 'bg-emerald-50/50 border-emerald-300 text-emerald-800' 
                  : 'bg-gray-50 border-gray-200 text-gray-400 line-through'
              }`}
            >
              <span className="truncate">📊 Tampilkan Grafik</span>
              <span className={`w-2 h-2 rounded-full ${controls.showChart ? 'bg-emerald-500' : 'bg-gray-300'}`}></span>
            </button>
          </div>

          {/* Toggle Sidebar Profile */}
          <div className="flex flex-col justify-end">
            <button
              onClick={() => onUpdateControls((prev) => ({ ...prev, showSidebarProfile: !prev.showSidebarProfile }))}
              id="toggle-sidebar-profile-btn"
              className={`w-full py-1.5 px-2 border rounded-md text-left text-xs font-medium flex items-center justify-between transition ${
                controls.showSidebarProfile 
                  ? 'bg-emerald-50/50 border-emerald-300 text-emerald-800' 
                  : 'bg-gray-50 border-gray-200 text-gray-400 line-through'
              }`}
            >
              <span className="truncate">👤 Profil Samping</span>
              <span className={`w-2 h-2 rounded-full ${controls.showSidebarProfile ? 'bg-emerald-500' : 'bg-gray-300'}`}></span>
            </button>
          </div>

          {/* Toggle Sticky Header */}
          <div className="flex flex-col justify-end">
            <button
              onClick={() => onUpdateControls((prev) => ({ ...prev, headerSticky: !prev.headerSticky }))}
              id="toggle-sticky-header-btn"
              className={`w-full py-1.5 px-2 border rounded-md text-left text-xs font-medium flex items-center justify-between transition ${
                controls.headerSticky 
                  ? 'bg-emerald-50/50 border-emerald-300 text-emerald-800' 
                  : 'bg-gray-50 border-gray-200 text-gray-400 line-through'
              }`}
            >
              <span className="truncate">📌 Sticky Header</span>
              <span className={`w-2 h-2 rounded-full ${controls.headerSticky ? 'bg-emerald-500' : 'bg-gray-300'}`}></span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
