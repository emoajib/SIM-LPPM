import React, { useState, useMemo } from 'react';
import { ThemePreset, CustomControls } from '../types';
import { 
  FileText, CheckCircle2, Clock, Coins, Download, UploadCloud, 
  UserCheck, Search, Plus, Send, RefreshCw, Briefcase, Calendar,
  Trash2, Eye, ShieldCheck, AlertCircle, FileSignature, Check, Filter, MessageSquare,
  Pencil
} from 'lucide-react';

interface ContractModuleViewProps {
  preset: ThemePreset;
  controls: CustomControls;
}

export interface KontrakRecord {
  id: string;
  nomorKontrak: string;
  judulKegiatan: string;
  jenis: 'Penelitian' | 'Pengabdian';
  skema: string;
  danaDisetujui: number;
  pihakKedua: string; // Pengusul / Dosen Ketua
  mitraKerjasama?: string;
  tahunAkademik: string;
  statusKontrak: 'Draf' | 'Diajukan' | 'Ditandatangani' | 'Selesai';
  progressPencairan: '0%' | '70%' | '100%';
  skPenerapanKontrak: 'Terbit' | 'Dalam Proses' | 'Belum Terbit';
  nomorSKKontrak: string;
  tanggalSKKontrak: string;
  metodePembayaran: string;
  reviewerNotes: string;
  isSignedByDosen: boolean;
  isSignedByRektor: boolean;
  uploadedFileName?: string;
  uploadedFileSize?: string;
  uploadedAt?: string;
}

export default function ContractModuleView({ preset, controls }: ContractModuleViewProps) {
  const colors = preset.config;
  const roundedClass = 
    controls.roundedMode === 'none' ? 'rounded-none' :
    controls.roundedMode === 'md' ? 'rounded-md' :
    controls.roundedMode === 'xl' ? 'rounded-xl' : 'rounded-2xl';

  // Sub tabs like TableView
  const [editingContractId, setEditingContractId] = useState<string | null>(null);
  const subTabs = ['Daftar Kontrak', editingContractId ? 'Edit Kontrak' : 'Penyusunan Kontrak', 'Termin & Pencairan', 'SK Penerapan Dana', 'Templat & Panduan'];
  const [activeSubTab, setActiveSubTab] = useState<number>(0);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [filterYear, setFilterYear] = useState('25/26');

  // Selected Contract ID for visual interactive status details underneath
  const [selectedContractId, setSelectedContractId] = useState<string>('CON-2026-001');

  // Interactive state
  const [showToast, setShowToast] = useState<string | null>(null);

  // Mock list of Contracts
  const [contracts, setContracts] = useState<KontrakRecord[]>([
    {
      id: 'CON-2026-001',
      nomorKontrak: '184/LPPM/ITSNU/KTM/VI/2026',
      judulKegiatan: 'Sistem Rekomendasi Motif Batik Berbasis Large Language Model dan Knowledge Base untuk Peningkatan Kepuasan Pelanggan UMKM',
      jenis: 'Penelitian',
      skema: 'Penelitian Fundamental Mandiri',
      danaDisetujui: 15500000,
      pihakKedua: 'MUJIBUL HAKIM',
      tahunAkademik: '2025/2026 Ganjil',
      statusKontrak: 'Ditandatangani',
      progressPencairan: '70%',
      skPenerapanKontrak: 'Terbit',
      nomorSKKontrak: 'SK-KONTRAK/LPPM/2841-2026',
      tanggalSKKontrak: '05 Juni 2026',
      metodePembayaran: 'Tahap I (70%) & Tahap II (30% setelah laporan akhir)',
      reviewerNotes: 'Kontrak telah dinyatakan sah & valid secara substansi akademik. Surat Keputusan (SK) Penerapan Dana hibah internal No. SK-KONTRAK/LPPM/2841-2026 ditandatangani Rektor & diterbitkan.',
      isSignedByDosen: true,
      isSignedByRektor: true,
    },
    {
      id: 'CON-2026-002',
      nomorKontrak: '189/LPPM/ITSNU/KTM/VI/2026',
      judulKegiatan: 'Rancang Bangun Chatbot Konsultasi Hukum Islam dan Kemasyarakatan menggunakan Generative AI',
      jenis: 'Penelitian',
      skema: 'Penelitian Terapan Hibah Internal',
      danaDisetujui: 18000000,
      pihakKedua: 'MUJIBUL HAKIM',
      tahunAkademik: '2025/2026 Genap',
      statusKontrak: 'Diajukan',
      progressPencairan: '0%',
      skPenerapanKontrak: 'Dalam Proses',
      nomorSKKontrak: '-',
      tanggalSKKontrak: '-',
      metodePembayaran: 'Tahap I (70%) & Tahap II (30% setelah laporan akhir)',
      reviewerNotes: 'Draft kontrak telah diajukan dan diparaf oleh Ketua LPPM. SK Penerapan Kontrak sedang dalam antrean otorisasi tanda tangan elektronik (TTE) Rektorate.',
      isSignedByDosen: true,
      isSignedByRektor: false,
    },
    {
      id: 'CON-2026-003',
      nomorKontrak: '210/LPPM/ITSNU/KTM/VI/2026',
      judulKegiatan: 'Pemberdayaan pengelolaan Sumberdaya BUMDes Berkah Jaya desa Karangasem melalui implementasi digital marketing',
      jenis: 'Pengabdian',
      skema: 'Pemberdayaan Kemitraan Masyarakat',
      danaDisetujui: 12500000,
      pihakKedua: 'MUJIBUL HAKIM',
      tahunAkademik: '2025/2026 Genap',
      statusKontrak: 'Ditandatangani',
      progressPencairan: '100%',
      skPenerapanKontrak: 'Terbit',
      nomorSKKontrak: 'SK-KONTRAK/LPPM/2219-2026',
      tanggalSKKontrak: '10 Mei 2026',
      metodePembayaran: 'Sekali Bayar (Full 100%)',
      reviewerNotes: 'Status kontrak selesai. Laporan akhir pengabdian masyarakat telah disubmit, dana 100% lunas tersalurkan kepada tim abdimas.',
      isSignedByDosen: true,
      isSignedByRektor: true,
    },
    {
      id: 'CON-2026-004',
      nomorKontrak: 'Draft-K-004',
      judulKegiatan: 'Edukasi Sanitasi Digital di Pondok Pesantren Kabupaten Pekalongan Terbuka',
      jenis: 'Pengabdian',
      skema: 'Program Kemitraan Wilayah',
      danaDisetujui: 9000000,
      pihakKedua: 'HAFIZ GHULAM',
      tahunAkademik: '2025/2026 Genap',
      statusKontrak: 'Draf',
      progressPencairan: '0%',
      skPenerapanKontrak: 'Belum Terbit',
      nomorSKKontrak: '-',
      tanggalSKKontrak: '-',
      metodePembayaran: 'Tahap I (70%) & Tahap II (30%)',
      reviewerNotes: 'Draft administrasi kontrak sedang disusun oleh pemenang hibah. Berkas belum diajukan secara resmi ke LPPM.',
      isSignedByDosen: false,
      isSignedByRektor: false,
    }
  ]);

  // Form State
  const [formData, setFormData] = useState({
    judulKegiatan: '',
    jenis: 'Penelitian' as 'Penelitian' | 'Pengabdian',
    skema: 'Penelitian Fundamental Mandiri',
    danaDisetujui: 15000000,
    pihakKedua: 'MUJIBUL HAKIM',
    tahunAkademik: '2025/2026 Genap',
    metodePembayaran: 'Tahap I (70%) & Tahap II (30%)',
    reviewerNotes: 'Draft kontrak usulan baru dari pengusul. Menunggu verifikasi berkas oleh admin LPPM.',
  });

  // Action: Create or Edit contract
  const handleCreateContract = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.judulKegiatan) {
      alert("Mohon masukkan judul kegiatan penelitian atau pengabdian!");
      return;
    }

    if (editingContractId) {
      // Edit existing contract
      setContracts(prev => prev.map(con => {
        if (con.id === editingContractId) {
          return {
            ...con,
            judulKegiatan: formData.judulKegiatan,
            jenis: formData.jenis,
            skema: formData.skema,
            danaDisetujui: Number(formData.danaDisetujui),
            pihakKedua: formData.pihakKedua,
            tahunAkademik: formData.tahunAkademik,
            metodePembayaran: formData.metodePembayaran,
            reviewerNotes: formData.reviewerNotes,
          };
        }
        return con;
      }));
      triggerToast("Berhasil memperbarui data kontrak!");
      setEditingContractId(null);
    } else {
      // Create new contract
      const newId = `CON-2026-00${contracts.length + 1}`;
      const newRecord: KontrakRecord = {
        id: newId,
        nomorKontrak: `Draft-K-00${contracts.length + 1}`,
        judulKegiatan: formData.judulKegiatan,
        jenis: formData.jenis,
        skema: formData.skema,
        danaDisetujui: Number(formData.danaDisetujui),
        pihakKedua: formData.pihakKedua,
        tahunAkademik: formData.tahunAkademik,
        statusKontrak: 'Draf',
        progressPencairan: '0%',
        skPenerapanKontrak: 'Belum Terbit',
        nomorSKKontrak: '-',
        tanggalSKKontrak: '-',
        metodePembayaran: formData.metodePembayaran,
        reviewerNotes: formData.reviewerNotes,
        isSignedByDosen: false,
        isSignedByRektor: false,
      };

      setContracts([newRecord, ...contracts]);
      setSelectedContractId(newId);
      triggerToast("Berhasil menyusun draf kontrak baru! Silakan lakukan tanda tangan digital.");
    }

    setActiveSubTab(0);
    
    // Reset Form
    setFormData({
      judulKegiatan: '',
      jenis: 'Penelitian',
      skema: 'Penelitian Fundamental Mandiri',
      danaDisetujui: 15000000,
      pihakKedua: 'MUJIBUL HAKIM',
      tahunAkademik: '2025/2026 Genap',
      metodePembayaran: 'Tahap I (70%) & Tahap II (30%)',
      reviewerNotes: 'Draft kontrak usulan baru dari pengusul. Menunggu verifikasi berkas oleh admin LPPM.',
    });
  };

  // LPPM Administration Helper Actions
  const handleEditInitiate = (contract: KontrakRecord) => {
    setEditingContractId(contract.id);
    setFormData({
      judulKegiatan: contract.judulKegiatan,
      jenis: contract.jenis,
      skema: contract.skema,
      danaDisetujui: contract.danaDisetujui,
      pihakKedua: contract.pihakKedua,
      tahunAkademik: contract.tahunAkademik,
      metodePembayaran: contract.metodePembayaran,
      reviewerNotes: contract.reviewerNotes,
    });
    setActiveSubTab(1);
  };

  const handleDeleteContract = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm("Apakah Anda yakin ingin menghapus kontrak ini?")) {
      setContracts(prev => prev.filter(c => c.id !== id));
      triggerToast("Kontrak berhasil dihapus!");
      if (selectedContractId === id) {
        setSelectedContractId('');
      }
    }
  };

  // Upload Simulation for physical contract document
  const [uploadingForContractId, setUploadingForContractId] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number>(0);

  const handleSimulateContractUpload = (id: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingForContractId(id);
    setUploadProgress(10);

    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setContracts(cnts => cnts.map(c => {
            if (c.id === id) {
              return {
                ...c,
                uploadedFileName: file.name,
                uploadedFileSize: `${(file.size / 1024).toFixed(1)} KB`,
                uploadedAt: new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })
              };
            }
            return c;
          }));
          triggerToast(`Berkas fisik kontrak "${file.name}" berhasil diunggah!`);
          setUploadingForContractId(null);
          return 0;
        }
        return prev + 30;
      });
    }, 200);
  };

  const handleRemoveContractUpload = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setContracts(cnts => cnts.map(c => {
      if (c.id === id) {
        const { uploadedFileName, uploadedFileSize, uploadedAt, ...rest } = c;
        return rest as any;
      }
      return c;
    }));
    triggerToast("Berkas kontrak terunggah berhasil dihapus.");
  };

  // Helper action: Simulasikan Tanda Tangan Dosen (TTE)
  const handleSignByDosen = (id: string) => {
    setContracts(prev => prev.map(con => {
      if (con.id === id) {
        const nextStatus = con.statusKontrak === 'Draf' ? 'Diajukan' : con.statusKontrak;
        return {
          ...con,
          isSignedByDosen: true,
          statusKontrak: nextStatus as any,
          reviewerNotes: 'Dosen ketua telah membubuhkan tanda tangan digital e-Meterai. Mengubah status berkas menjadi DIAJUKAN demi review akhir Ketua LPPM & Rektor.'
        };
      }
      return con;
    }));
    triggerToast("Tanda tangan elektronik (TTE) Dosen berhasil dibubuhkan!");
  };

  // Helper action: Simulasikan Approval LPPM & Terbitkan SK Rektor
  const handleApproveAndIssueSK = (id: string) => {
    setContracts(prev => prev.map(con => {
      if (con.id === id) {
        const randomSkNo = `SK-KONTRAK/LPPM/${Math.floor(2000 + Math.random() * 7000)}-2026`;
        return {
          ...con,
          isSignedByDosen: true, // Auto sign for demo
          isSignedByRektor: true,
          statusKontrak: 'Ditandatangani',
          skPenerapanKontrak: 'Terbit',
          nomorSKKontrak: randomSkNo,
          tanggalSKKontrak: '11 Juni 2026',
          progressPencairan: con.progressPencairan === '0%' ? '70%' : con.progressPencairan,
          reviewerNotes: `PENGESAHAN REAL-TIME: Kontrak ini telah sah ditandatangani oleh Rektor & Ketua LPPM ITSNU Pekalongan. Surat Keputusan (SK) resmi nomor ${randomSkNo} telah terbit hari ini! Dana Hibah Tahap I siap dicarikan.`
        };
      }
      return con;
    }));
    triggerToast("Otorisasi Rektorat Sukses! Status Kontrak DITANDATANGANI & SK Resmi berhasil diterbitkan.");
  };

  const triggerToast = (msg: string) => {
    setShowToast(msg);
    setTimeout(() => setShowToast(null), 4000);
  };

  // Calculated Stats
  const selectedContract = useMemo(() => {
    return contracts.find(c => c.id === selectedContractId) || contracts[0];
  }, [contracts, selectedContractId]);

  const filteredContracts = useMemo(() => {
    return contracts.filter(c => {
      const matchSearch = 
        c.judulKegiatan.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.pihakKedua.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.nomorKontrak.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchYear = c.tahunAkademik.includes(filterYear);
      return matchSearch && matchYear;
    });
  }, [contracts, searchQuery, filterYear]);

  const formattedRupiah = (num: number) => {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(num);
  };

  return (
    <div className={`space-y-4 ${controls.layoutMode === 'compact' ? 'space-y-3' : 'space-y-4'}`}>
      
      {/* Dynamic Notification Toast */}
      {showToast && (
        <div className="p-3 bg-emerald-50 border-l-4 border-emerald-500 text-emerald-800 text-xs font-bold flex items-center justify-between rounded shadow-xs mb-3 animate-fade-in">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{showToast}</span>
          </div>
          <button onClick={() => setShowToast(null)} className="text-[10px] text-gray-400 hover:text-gray-700">✕</button>
        </div>
      )}

      {/* 1. Aligned TOP Sub-Navigation Tab Bar */}
      <div className="border-b border-gray-200 overflow-x-auto select-none scrollbar-none">
        <div className="flex gap-1.5 min-w-max pb-0.5">
          {subTabs.map((tab, idx) => {
            const isActive = activeSubTab === idx;
            return (
              <button
                key={idx}
                onClick={() => {
                  setActiveSubTab(idx);
                }}
                className={`text-xs px-3.5 py-2 font-semibold transition border-b-2 whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'border-[#1e3a6e] text-[#1e3a6e] font-extrabold'
                    : 'border-transparent text-gray-500 hover:text-[#1e3a6e]'
                }`}
              >
                📝 {tab}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Aligned Form Filter & Info Utility Bar */}
      <div className="flex flex-col sm:flex-row gap-3 justify-between items-stretch sm:items-center">
        <div className="flex gap-2">
          <button 
            onClick={() => alert(`Informasi Kelayakan Dana untuk ${preset.brand.userName}: Pagu Anggaran Maksimal adalah 25 Juta Rupiah per judul sesuai SBU internal.`)}
            className="flex items-center gap-1 bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold px-3 py-1.5 rounded transition shadow-xs cursor-pointer shrink-0"
          >
            <Coins className="w-3.5 h-3.5" />
            <span>Info SBU Kontrak</span>
          </button>

          <button 
            onClick={() => {
              setEditingContractId(null);
              setFormData({
                judulKegiatan: '',
                jenis: 'Penelitian',
                skema: 'Penelitian Fundamental Mandiri',
                danaDisetujui: 15000000,
                pihakKedua: 'MUJIBUL HAKIM',
                tahunAkademik: '2025/2026 Genap',
                metodePembayaran: 'Tahap I (70%) & Tahap II (30%)',
                reviewerNotes: 'Draft kontrak usulan baru dari pengusul. Menunggu verifikasi berkas oleh admin LPPM.',
              });
              setActiveSubTab(1);
            }}
            className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold px-3 py-1.5 rounded transition shadow-xs cursor-pointer shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Tambah Kontrak</span>
          </button>
          
          {/* Quick search input */}
          <div className="relative w-full sm:w-64">
            <span className="absolute inset-y-0 left-0 flex items-center pl-2.5 pointer-events-none">
              <Search className="h-3.5 w-3.5 text-gray-400" />
            </span>
            <input
              type="text"
              placeholder="Cari kontrak, No. Kontrak, Pihak..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs bg-white border border-gray-200 rounded py-1.5 pl-8 pr-3 outline-none text-gray-700 focus:border-blue-400 focus:ring-1 focus:ring-blue-100 placeholder:text-gray-400"
            />
          </div>
        </div>

        {/* Filter Inputs right aligned matching TableView */}
        <div className="flex items-center gap-2 justify-end">
          <span className="text-[10px] sm:text-xs font-bold text-gray-600 uppercase tracking-wide flex items-center gap-1 shrink-0">
            <Filter className="w-3 h-3 text-[#1e3a6e]" /> Anggaran/Akademik:
          </span>
          <div className="flex items-center gap-1.5 bg-white border border-gray-200 rounded px-2 py-1 shadow-2xs">
            <span className="text-gray-400 text-xs">▼</span>
            <select 
              value={filterYear}
              onChange={(e) => setFilterYear(e.target.value)}
              className="text-xs font-bold text-slate-800 outline-none bg-transparent"
            >
              <option value="25/26">2025/2026</option>
              <option value="24/25">2024/2025</option>
            </select>
          </div>
        </div>
      </div>

      {activeSubTab === 1 ? (
        /* PANEL 1: PENYUSUNAN KONTRAK FORM */
        <div className="bg-white border border-gray-200 p-6 rounded-xl shadow-xs text-left max-w-3xl">
          <div className="border-b border-gray-100 pb-3 mb-4">
            <h3 className="text-xs font-black text-gray-800 uppercase tracking-wider flex items-center gap-1">
              📝 {editingContractId ? `Edit Kontrak [ID: ${editingContractId}]` : 'Buat Usulan Kontrak Baru (Penelitian / Pengabdian)'}
            </h3>
          </div>

          <form onSubmit={handleCreateContract} className="space-y-4 text-xs">
            <div className="space-y-1">
              <label className="font-bold text-gray-700">Jenis Kegiatan Kontrak</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setFormData({...formData, jenis: 'Penelitian'})}
                  className={`py-2 px-3 border rounded font-black text-center transition ${
                    formData.jenis === 'Penelitian' ? 'bg-blue-50 border-blue-400 text-blue-800 font-extrabold' : 'bg-white border-gray-200 text-gray-600'
                  }`}
                >
                  🔍 Kegiatan Penelitian
                </button>
                <button
                  type="button"
                  onClick={() => setFormData({...formData, jenis: 'Pengabdian'})}
                  className={`py-2 px-3 border rounded font-black text-center transition ${
                    formData.jenis === 'Pengabdian' ? 'bg-orange-50 border-orange-400 text-amber-800 font-extrabold' : 'bg-white border-gray-200 text-gray-600'
                  }`}
                >
                  👥 Pengabdian Masyarakat
                </button>
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-bold text-gray-700">Judul Kegiatan Penelitian / Pengabdian</label>
              <input
                type="text"
                placeholder="Masukkan judul tepat sesuai usulan proposal..."
                value={formData.judulKegiatan}
                onChange={(e) => setFormData({...formData, judulKegiatan: e.target.value})}
                className="w-full border border-gray-200 p-2.5 rounded text-gray-800 font-medium focus:border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-100"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="font-bold text-gray-700">Ketua Pengusul (Pihak Kedua)</label>
                <input
                  type="text"
                  value={formData.pihakKedua}
                  onChange={(e) => setFormData({...formData, pihakKedua: e.target.value})}
                  className="w-full border border-gray-200 p-2.5 rounded font-bold text-gray-800"
                />
              </div>
              <div className="space-y-1">
                <label className="font-bold text-gray-700">Skema Pendanaan</label>
                <input
                  type="text"
                  value={formData.skema}
                  onChange={(e) => setFormData({...formData, skema: e.target.value})}
                  className="w-full border border-gray-200 p-2.5 rounded"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="font-bold text-gray-700">Dana Disetujui (IDR)</label>
                <input
                  type="number"
                  value={formData.danaDisetujui}
                  onChange={(e) => setFormData({...formData, danaDisetujui: Number(e.target.value)})}
                  className="w-full border border-gray-200 p-2.5 rounded font-mono font-bold"
                />
              </div>
              <div className="space-y-1">
                <label className="font-bold text-gray-700">Tahun Akademik</label>
                <select
                  value={formData.tahunAkademik}
                  onChange={(e) => setFormData({...formData, tahunAkademik: e.target.value})}
                  className="w-full bg-white border border-gray-200 p-2.5 rounded font-bold text-gray-700"
                >
                  <option value="2025/2026 Ganjil">2025/2026 Ganjil</option>
                  <option value="2025/2026 Genap">2025/2026 Genap</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="font-bold text-gray-700">Skema Pembayaran</label>
                <input
                  type="text"
                  value={formData.metodePembayaran}
                  onChange={(e) => setFormData({...formData, metodePembayaran: e.target.value})}
                  className="w-full border border-gray-200 p-2.5 rounded text-gray-700"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-bold text-gray-700">Keterangan / Reviewer Notes Mandiri</label>
              <textarea
                rows={3}
                value={formData.reviewerNotes}
                onChange={(e) => setFormData({...formData, reviewerNotes: e.target.value})}
                className="w-full border border-gray-200 p-2.5 rounded text-gray-800"
              />
            </div>

            <div className="pt-4 border-t border-gray-100 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => {
                  setEditingContractId(null);
                  setActiveSubTab(0);
                }}
                className="px-4 py-2 bg-slate-100 border border-gray-200 hover:bg-slate-200 text-gray-600 rounded"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-[#1e3a6e] hover:bg-slate-900 text-white rounded font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Simpan Kontrak</span>
              </button>
            </div>
          </form>
        </div>
      ) : activeSubTab === 4 ? (
        /* TEMPLATE & PANDUAN PANEL */
        <div className="bg-white border border-gray-200 p-5 rounded-xl text-left space-y-4">
          <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-tight mb-2.5 flex items-center gap-1.5">
            <span>📚 Unduh Berkas Template Kontrak Standar ITSNU Pekalongan</span>
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-3 bg-[#f8fafc] hover:bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between font-bold text-xs">
              <div className="flex items-center gap-2">
                <span className="text-base text-blue-700">📄</span>
                <div className="flex flex-col">
                  <span className="text-slate-800 font-bold">Template_Kontrak_Penelitian_2026.docx</span>
                  <span className="text-[9.5px] text-gray-400 font-semibold">Dokumen Word • 145 KB</span>
                </div>
              </div>
              <button onClick={() => alert("Mengunduh Template Kontrak Penelitian")} className="p-1.5 bg-white border border-gray-200 rounded hover:bg-gray-100 text-slate-700 cursor-pointer">
                <Download className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="p-3 bg-[#f8fafc] hover:bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between font-bold text-xs">
              <div className="flex items-center gap-2">
                <span className="text-base text-[#b45309]">📄</span>
                <div className="flex flex-col">
                  <span className="text-slate-800 font-bold">Template_Kontrak_Abdimas_2026.docx</span>
                  <span className="text-[9.5px] text-gray-400 font-semibold">Dokumen Word • 148 KB</span>
                </div>
              </div>
              <button onClick={() => alert("Mengunduh Template Kontrak Pengabdian")} className="p-1.5 bg-white border border-gray-200 rounded hover:bg-gray-100 text-slate-700 cursor-pointer">
                <Download className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="p-3 bg-[#f8fafc] hover:bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between font-bold text-xs">
              <div className="flex items-center gap-2">
                <span className="text-base text-indigo-700">📜</span>
                <div className="flex flex-col">
                  <span className="text-slate-800 font-bold">Panduan_TTE_Meterai_Digital_LPPM.pdf</span>
                  <span className="text-[9.5px] text-gray-400 font-semibold">PDF Dokumen • 1.2 MB</span>
                </div>
              </div>
              <button onClick={() => alert("Mengunduh Panduan e-Meterai TTE")} className="p-1.5 bg-white border border-gray-200 rounded hover:bg-gray-100 text-slate-700 cursor-pointer">
                <Download className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* THE MAIN TABULAR LIST ALIGNED WITH TABLEVIEW */
        <div className="space-y-4">
          <div className={`overflow-hidden bg-white border border-gray-200 ${roundedClass} shadow-xs`}>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[950px]">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-100">
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 text-center w-12">No</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 w-44">Pihak Kedua (Dosen)</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 w-[380px]">Nomor & Judul Kontrak Kegiatan</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3">Skema & Tahun</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3">Dana Disetujui</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3 text-center">Pencairan</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3 text-center w-28">Status</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-3 text-center w-28">SK Rektor</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 text-center w-36 font-sans">Komentar</th>
                    <th className="text-[10px] uppercase font-bold text-gray-500 py-3 px-4 text-center w-40">Aksi LPPM</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 text-xs">
                  {filteredContracts.length > 0 ? (
                    filteredContracts.map((c, idx) => {
                       const isSelected = c.id === selectedContractId;
                       const matchesTabFilter = 
                         activeSubTab === 0 
                         ? true // Semua Kontrak
                         : activeSubTab === 2 
                         ? c.progressPencairan !== '0%' // Pencairan Aktif
                         : activeSubTab === 3 
                         ? c.skPenerapanKontrak === 'Terbit' // SK Terbit
                         : true;
 
                       if (!matchesTabFilter) return null;
 
                       return (
                        <tr 
                          key={c.id} 
                          className={`hover:bg-slate-50/50 transition cursor-pointer ${
                            isSelected ? 'bg-blue-50/30' : ''
                          }`}
                          onClick={() => setSelectedContractId(c.id)}
                        >
                          {/* Col 1: No */}
                          <td className="py-4 px-4 text-center font-bold text-gray-400 select-none">{idx + 1}</td>
                          
                          {/* Col 2: Dosen */}
                          <td className="py-4 px-4 font-extrabold text-[#1e3a6e] uppercase tracking-tight">
                            {c.pihakKedua}
                            <span className="text-[9.5px] font-normal text-gray-400 block tracking-normal uppercase pt-0.5">{c.jenis}</span>
                          </td>
 
                          {/* Col 3: Title */}
                          <td className="py-4 px-4 leading-relaxed text-gray-700">
                            <span className="text-[9.5px] font-bold text-gray-400 block font-mono">No: {c.nomorKontrak}</span>
                            <div className="font-semibold text-gray-900 leading-normal">
                              {c.judulKegiatan}
                            </div>
                            {c.uploadedFileName && (
                              <div className="mt-2 flex items-center gap-1.5 text-emerald-800 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded text-[10px] font-bold inline-flex">
                                <span>📄 {c.uploadedFileName} ({c.uploadedFileSize}) - Terunggah {c.uploadedAt}</span>
                                <button 
                                  onClick={(e) => handleRemoveContractUpload(c.id, e)}
                                  className="text-rose-600 hover:text-rose-800 ml-1 font-bold cursor-pointer text-xs"
                                  title="Hapus berkas kontrak fisik"
                                >
                                  ✕
                                </button>
                              </div>
                            )}
                          </td>
 
                          {/* Col 4: Skema */}
                          <td className="py-4 px-3 font-medium text-gray-600">
                            <div className="text-[10px] bg-slate-100 text-slate-800 font-bold px-2 py-0.5 rounded truncate inline-block max-w-[140px] uppercase">
                              {c.skema}
                            </div>
                            <div className="text-[10.5px] text-gray-400 font-semibold font-mono mt-1">{c.tahunAkademik}</div>
                          </td>
 
                          {/* Col 5: Dana */}
                          <td className="py-4 px-3 font-bold text-slate-800 font-mono">
                            {formattedRupiah(c.danaDisetujui)}
                          </td>
 
                          {/* Col 6: Pencairan Progress */}
                          <td className="py-4 px-3 text-center">
                            <span className="font-semibold text-[11px] bg-blue-50 text-blue-700 border border-blue-105 px-2 py-0.5 rounded font-mono">
                              {c.progressPencairan}
                            </span>
                          </td>
 
                          {/* Col 7: Status */}
                          <td className="py-4 px-3 text-center">
                            {c.statusKontrak === 'Ditandatangani' ? (
                              <span className="inline-block border px-2 py-1 rounded text-[9px] font-black bg-emerald-50 text-emerald-800 border-emerald-250 uppercase text-center w-full">
                                Ditandatangani
                              </span>
                            ) : c.statusKontrak === 'Diajukan' ? (
                              <span className="inline-block border px-2 py-1 rounded text-[9px] font-black bg-blue-50 text-blue-800 border-blue-200 uppercase text-center w-full">
                                Diajukan
                              </span>
                            ) : (
                              <span className="inline-block border px-2 py-1 rounded text-[9px] font-black bg-slate-100 text-slate-700 border-slate-200 uppercase text-center w-full">
                                Draf
                              </span>
                            )}
                          </td>
 
                          {/* Col 8: SK Rektor */}
                          <td className="py-4 px-3 text-center">
                            {c.skPenerapanKontrak === 'Terbit' ? (
                              <span className="bg-green-50 text-emerald-700 border border-green-200 font-extrabold px-1.5 py-0.5 rounded text-[9px] uppercase font-mono inline-block">
                                TERBIT
                              </span>
                            ) : c.skPenerapanKontrak === 'Dalam Proses' ? (
                              <span className="bg-amber-50 text-amber-700 border border-amber-200 font-extrabold px-1.5 py-0.5 rounded text-[9px] uppercase font-mono inline-block">
                                PROSES
                              </span>
                            ) : (
                              <span className="bg-red-50 text-red-700 border border-red-150 px-1.5 py-0.5 rounded text-[9px] uppercase font-mono inline-block">
                                TIDAK ADA
                              </span>
                            )}
                          </td>
 
                          {/* Col 9: Komentar Reviewer */}
                          <td className="py-4 px-3 text-center">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedContractId(c.id);
                              }}
                              className="text-[9.5px] bg-[#1e3a6e] hover:bg-slate-800 text-white font-bold px-2.5 py-1 rounded transition w-full"
                            >
                              Catatan LPPM
                            </button>
                          </td>
 
                          {/* Col 10: Action (View, Edit, Upload, Delete) */}
                          <td className="py-4 px-4 text-center">
                            <div className="flex items-center gap-1.5 justify-center" onClick={(e) => e.stopPropagation()}>
                              {/* View detail */}
                              <button
                                onClick={() => {
                                  setSelectedContractId(c.id);
                                  alert(`Detail Draf Kontrak ID: ${c.id}\nSkema: ${c.skema}\nDana: ${formattedRupiah(c.danaDisetujui)}\nUlasan: ${c.reviewerNotes}`);
                                }}
                                className="p-1 px-1.5 bg-blue-50 border border-blue-200 hover:bg-blue-105 text-blue-700 rounded transition cursor-pointer"
                                title="Lihat detail kontrak"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </button>

                              {/* Edit */}
                              <button
                                onClick={() => handleEditInitiate(c)}
                                className="p-1 px-1.5 bg-amber-50 border border-amber-250 hover:bg-amber-100 text-amber-800 rounded transition cursor-pointer"
                                title="Edit data kontrak"
                              >
                                <Pencil className="w-3.5 h-3.5" />
                              </button>

                              {/* Upload simulated file */}
                              {uploadingForContractId === c.id ? (
                                <div className="p-1 px-1 bg-cyan-100 border border-cyan-300 text-cyan-800 text-[8px] font-black rounded tracking-tight animate-pulse w-8 text-center select-none">
                                  {uploadProgress}%
                                </div>
                              ) : (
                                <div className="relative">
                                  <input 
                                    id={`tbl-upload-${c.id}`}
                                    type="file"
                                    onChange={(e) => handleSimulateContractUpload(c.id, e)}
                                    className="hidden"
                                    accept=".pdf,.doc,.docx"
                                  />
                                  <label 
                                    htmlFor={`tbl-upload-${c.id}`}
                                    className="p-1 px-1.5 bg-emerald-55 border border-emerald-250 hover:bg-emerald-100 text-emerald-800 rounded transition cursor-pointer flex items-center justify-center"
                                    title="Upload fisik berkas kontrak (.pdf/.docx)"
                                  >
                                    <UploadCloud className="w-3.5 h-3.5" />
                                  </label>
                                </div>
                              )}

                              {/* Delete */}
                              <button
                                onClick={(e) => handleDeleteContract(c.id, e)}
                                className="p-1 px-1.5 bg-rose-50 border border-rose-250 hover:bg-rose-100 text-rose-800 rounded transition cursor-pointer"
                                title="Hapus draf kontrak"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={10} className="py-8 text-center text-gray-400 font-bold">
                        Tidak ada usulan kontrak yang cocok dengan filter.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* LOWER INTERACTIVE DETAILED SYSTEM STATUS SHEET MATCHING REVIEW COMMENT BLOCK of TableView */}
          {selectedContract && (
            <div className="p-5 bg-white border border-gray-200 rounded-xl space-y-4 text-left shadow-xs mt-4">
              
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-gray-100 pb-3 gap-2">
                <div className="flex items-center gap-2">
                  <span className="p-1 px-2.5 bg-[#1e3a6e] text-white font-black rounded text-[10px] font-mono">
                    {selectedContract.id}
                  </span>
                  <strong className="text-slate-800 text-xs sm:text-sm truncate max-w-sm sm:max-w-xl block">
                    {selectedContract.judulKegiatan}
                  </strong>
                </div>
                <div className="text-[10px] text-gray-400 font-bold font-mono">
                  Tahun Angg.: <strong className="text-slate-600">{selectedContract.tahunAkademik}</strong>
                </div>
              </div>

              {/* Grid content inside */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-start">
                
                {/* Left side detail: signatures */}
                <div className="md:col-span-7 bg-slate-50/80 p-4 border border-gray-200 rounded-lg space-y-3.5">
                  <span className="text-[9.5px] font-black text-slate-500 uppercase tracking-widest block">
                    🖊️ Otorisasi Tandatangan Elektronik (TTE) e-Meterai LPPM
                  </span>

                  <div className="grid grid-cols-2 gap-3 text-center text-xs">
                    
                    {/* Dosen sign */}
                    <div className="p-3 bg-white rounded border border-gray-200 flex flex-col items-center justify-between h-28">
                      <span className="text-[8px] font-black text-gray-400 uppercase tracking-wide">Pihak Kedua (Ketua Dosen)</span>
                      
                      {selectedContract.isSignedByDosen ? (
                        <div className="flex flex-col items-center my-1 select-none">
                          <span className="text-lg">✍️</span>
                          <span className="text-[8px] bg-emerald-50 text-emerald-800 border border-emerald-150 px-1.5 py-0.5 rounded font-bold font-mono">
                            AUTHENTIC e-TTE
                          </span>
                        </div>
                      ) : (
                        <button 
                          onClick={() => handleSignByDosen(selectedContract.id)}
                          className="px-2.5 py-1 text-[9px] bg-[#3b82f6] hover:bg-[#2563eb] text-white font-bold rounded flex items-center gap-1 cursor-pointer transition animate-pulse"
                        >
                          <FileSignature className="w-3 h-3 text-white" />
                          <span>Paraf TTE</span>
                        </button>
                      )}

                      <span className="font-extrabold text-[10px] text-slate-800 uppercase truncate max-w-[120px]">
                        {selectedContract.pihakKedua}
                      </span>
                    </div>

                    {/* Rektor sign */}
                    <div className="p-3 bg-white rounded border border-gray-200 flex flex-col items-center justify-between h-28">
                      <span className="text-[8px] font-black text-gray-400 uppercase tracking-wide">Pihak Kesatu (Rektorat)</span>
                      
                      {selectedContract.isSignedByRektor ? (
                        <div className="flex flex-col items-center my-1 select-none">
                          <span className="text-lg">🛡️</span>
                          <span className="text-[8px] bg-blue-50 text-blue-900 border border-blue-150 px-1.5 py-0.5 rounded font-bold font-mono">
                            REKTOR APPROVED
                          </span>
                        </div>
                      ) : (
                        <button 
                          onClick={() => handleApproveAndIssueSK(selectedContract.id)}
                          className="px-2.5 py-1 text-[9px] bg-emerald-700 hover:bg-emerald-850 text-white font-bold rounded flex items-center gap-1 cursor-pointer transition"
                        >
                          <Check className="w-3 h-3 text-white" />
                          <span>Setujui (Rektor)</span>
                        </button>
                      )}

                      <span className="font-extrabold text-[9.5px] text-[#1e3a6e] uppercase tracking-tight">
                        SIM-LPPM ITSNU
                      </span>
                    </div>

                  </div>
                </div>

                {/* Right side detail: decree & comments */}
                <div className="md:col-span-5 space-y-3">
                  
                  {/* Reviewer / Comments in exact style of TableView comments */}
                  <div className="p-3.5 bg-amber-50 border-l-4 border-amber-500 rounded text-xs space-y-1 relative">
                    <div className="flex items-center gap-1.5 text-amber-950 font-bold mb-1">
                      <MessageSquare className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      <span>Ulasan / Reviewer Komentar LPPM ITSNU Pekalongan:</span>
                    </div>
                    <p className="text-gray-700 font-medium italic">
                      "{selectedContract.reviewerNotes}"
                    </p>
                  </div>

                  {/* SK Rektor card details with download */}
                  <div className="p-3.5 bg-indigo-50/20 border border-indigo-150 rounded text-xs space-y-2 text-left">
                    <span className="font-black text-indigo-900 uppercase tracking-widest text-[9.5px]">
                      STATUS SURAT KEPUTUSAN REKTOR
                    </span>

                    {selectedContract.skPenerapanKontrak === 'Terbit' ? (
                      <div className="space-y-1.5 font-medium text-slate-800 text-[11px]">
                        <div className="flex justify-between">
                          <span>Nomor SK Kontrak:</span>
                          <strong className="font-mono text-indigo-900 font-extrabold">{selectedContract.nomorSKKontrak}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span>Tanggal Terbit SK:</span>
                          <strong className="text-slate-600 font-semibold">{selectedContract.tanggalSKKontrak}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span>Termin Anggaran:</span>
                          <strong className="text-slate-600 font-semibold">{selectedContract.metodePembayaran}</strong>
                        </div>
                        
                        <button 
                          onClick={() => alert(`Mengunduh Berkas PDF SK Kontrak Resmi ${selectedContract.nomorSKKontrak}`)}
                          className="w-full mt-2 py-1 px-2.5 bg-[#1e3a6e] hover:bg-slate-900 text-white font-bold rounded flex items-center justify-center gap-1 text-[10.5px] cursor-pointer transition"
                        >
                          <Download className="w-3 h-3 text-white" />
                          <span>Unduh PDF SK Resmi</span>
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-start gap-1 p-1 bg-yellow-50 rounded text-amber-900 text-[10.5px]">
                        <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <p>
                          SK belum diterbitkan secara digital. Mohon selesaikan penandatanganan TTE di samping terlebih dahulu untuk mengeluarkan SK.
                        </p>
                      </div>
                    )}

                  </div>

                </div>

              </div>

            </div>
          )}

        </div>
      )}

    </div>
  );
}
