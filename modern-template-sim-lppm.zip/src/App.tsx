/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { themePresets } from './data/presets';
import { ThemePreset, CustomControls } from './types';
import ThemeSelector from './components/ThemeSelector';
import Sidebar from './components/Sidebar';
import DashboardView from './components/DashboardView';
import TableView from './components/TableView';
import LetterModuleView from './components/LetterModuleView';
import PrototypeAndIntellectualPropertyView from './components/PrototypeAndIntellectualPropertyView';
import ContractModuleView from './components/ContractModuleView';
import CodeExporter from './components/CodeExporter';
import { LayoutTemplate } from 'lucide-react';

export default function App() {
  const [selectedPreset, setSelectedPreset] = useState<ThemePreset>(themePresets[0]);
  
  // Custom Controls State with healthy initial defaults
  const [controls, setControls] = useState<CustomControls>({
    layoutMode: 'split',
    showStats: true,
    showChart: true,
    showSidebarProfile: true,
    roundedMode: 'md',
    headerSticky: true,
    showCodeModal: false
  });

  const [activeMenu, setActiveMenu] = useState<string>('Dashboard');
  const [showPlayground, setShowPlayground] = useState<boolean>(false);

  const handleSelectPreset = (preset: ThemePreset) => {
    setSelectedPreset(preset);
    // Auto sync menu to the first tab of target theme if not found
    if (!preset.navigation.includes(activeMenu)) {
      setActiveMenu(preset.navigation[0] || 'Dashboard');
    }
  };

  const handleUpdateControls = (updater: (prev: CustomControls) => CustomControls) => {
    setControls(updater);
  };

  const handleResetControls = () => {
    setControls({
      layoutMode: 'split',
      showStats: true,
      showChart: true,
      showSidebarProfile: true,
      roundedMode: 'md',
      headerSticky: true,
      showCodeModal: false
    });
    setSelectedPreset(themePresets[0]);
    setActiveMenu('Dashboard');
  };

  // Border radius generator class
  const roundedClass = 
    controls.roundedMode === 'none' ? 'rounded-none' :
    controls.roundedMode === 'md' ? 'rounded-md' :
    controls.roundedMode === 'xl' ? 'rounded-xl' : 'rounded-2xl';

  const getNavItemIcon = (item: string) => {
    switch (item) {
      case 'Dashboard': return '🏠';
      case 'Penelitian': return '📖';
      case 'Pengabdian': return '👥';
      case 'Kontrak': return '📝';
      case 'Surat':
      case 'Modul Surat': return '✉️';
      case 'Prototipe': return '📦';
      case 'Kekayaan Intelektual': return '🔒';
      default: return '📁';
    }
  };

  const colors = selectedPreset.config;

  return (
    <div className="min-h-screen bg-slate-50/50 text-slate-800 font-sans flex flex-col">
      
      {/* 1. Dynamic Control Playground Bar */}
      {showPlayground && (
        <ThemeSelector 
          selectedPreset={selectedPreset}
          onSelectPreset={handleSelectPreset}
          controls={controls}
          onUpdateControls={handleUpdateControls}
          onResetControls={handleResetControls}
        />
      )}

      {/* 2. Topbar Brand Header (Dynamic Theme) */}
      <header className={`bg-white border-b border-gray-100 px-6 py-3 flex items-center justify-between ${controls.headerSticky ? (showPlayground ? 'sticky top-[138px] md:top-[85px] z-30' : 'sticky top-0 z-30') : ''}`}>
        <div className="flex items-center gap-3">
          {/* Styled exact replica LPPM ITSNU logo badge */}
          {selectedPreset.id === 'sim-lppm' ? (
            <div className="flex items-center gap-2.5 select-none cursor-pointer">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-green-700 via-emerald-600 to-green-800 flex items-center justify-center font-bold text-white relative shadow-sm hover:rotate-3 transition duration-150 border-2 border-green-300">
                {/* Visual depiction of the academic shield */}
                <span className="text-base">🎓</span>
                <span className="absolute -bottom-1 -right-1 bg-amber-500 border border-white text-[7px] w-4 h-4 flex items-center justify-center rounded-full font-black text-white">★</span>
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-black tracking-tight leading-none text-slate-900 flex items-center font-sans">
                  <span className="text-green-700 font-extrabold">SIM</span>&nbsp;<span className="text-blue-900 font-extrabold">LPPM</span>
                </span>
                <span className="text-[9px] text-slate-400 font-extrabold tracking-widest uppercase">ITSNU PEKALONGAN</span>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              {/* Logo icon */}
              <div 
                id={`logo-icon-box`}
                className={`w-9 h-9 ${colors.primaryBg} ${roundedClass} text-white font-black text-[9px] flex items-center justify-center text-center leading-tight tracking-wider shadow-sm select-none shrink-0 border border-white/10`}
              >
                {selectedPreset.brand.logoInitials}
              </div>
              <div>
                <div className={`font-black text-xs uppercase tracking-wider ${colors.primaryText}`}>
                  {selectedPreset.brand.logoText}
                </div>
                <div className="text-[10px] text-gray-400 font-bold tracking-tight">Sistem Informasi Terpadu</div>
              </div>
            </div>
          )}
        </div>

        {/* Dynamic Badges based on active configuration */}
        <div className="flex items-center gap-2">
          {/* Quiet Designer Control Toggle */}
          <button
            onClick={() => setShowPlayground(!showPlayground)}
            className={`flex items-center gap-1.5 bg-slate-50 hover:bg-slate-100 font-bold text-slate-700 border border-gray-200 text-[10.5px] px-3 py-1.5 ${roundedClass} transition cursor-pointer`}
          >
            <span className={`${showPlayground ? 'rotate-45' : ''} transition duration-200`}>⚙️</span>
            <span>{showPlayground ? 'Tutup Kustomisasi' : 'Kustomisasi Tema'}</span>
          </button>

          <button 
            onClick={() => alert(`Role aktif: ${selectedPreset.brand.userRole} - ${selectedPreset.brand.userName}`)}
            id="role-switch-indicator"
            className={`${colors.primaryBg} text-white text-[11px] font-extrabold px-3 py-1.5 ${roundedClass} shadow-3xs cursor-pointer select-none transition-transform hover:scale-102`}
          >
            {selectedPreset.brand.userRole} ▾
          </button>
          
          <span className="text-xs font-black text-gray-700 hidden sm:inline-block">
            🔔 {selectedPreset.brand.userName}
          </span>
        </div>
      </header>

      {/* 3. Horizontal Navigation Bar (Adapts colors based on active theme) */}
      <nav id="dashboard-navbar-horizontal" className={`${colors.primaryBg} text-white/90 px-6 py-1 flex gap-1 items-center overflow-x-auto select-none border-b border-black/10 shadow-2xs`}>
        {selectedPreset.navigation.map((navItem) => {
          const isActive = activeMenu === navItem;
          return (
            <button
              key={navItem}
              onClick={() => setActiveMenu(navItem)}
              id={`nav-item-${navItem}`}
              className={`text-xs px-4 py-3 font-semibold transition border-b-3 whitespace-nowrap cursor-pointer hover:text-white ${
                isActive 
                  ? 'border-amber-400 text-white font-black bg-white/10' 
                  : 'border-transparent text-white/70 hover:bg-white/5'
              }`}
            >
              {getNavItemIcon(navItem)} {navItem}{navItem !== 'Dashboard' ? ' ▾' : ''}
            </button>
          );
        })}
      </nav>

      {/* 4. MAIN LAYOUT COORDINATOR */}
      <div className="flex-1 w-full max-w-7xl mx-auto p-4 md:p-6">
        
        {/* If the requested page is not the Dashboard page, we render the data table view, otherwise the full workspace */}
        {activeMenu !== 'Dashboard' ? (
          <div className="space-y-6">
            {/* Direct navigation helper status */}
            <div className="p-4 bg-white border border-gray-100 rounded-lg flex items-center justify-between text-xs font-bold text-gray-600 shadow-3xs">
              <span className="flex items-center gap-1">
                <LayoutTemplate className="w-4 h-4 text-slate-400" />
                Halaman Aktif: <strong className="text-slate-800 font-extrabold">{activeMenu}</strong>
              </span>
              <span className="text-[10.5px] text-gray-400 font-normal">
                {activeMenu === 'Surat' || activeMenu === 'Modul Surat' ? 'Informasi persuratan dan cetak tugas dinas' : 
                 activeMenu === 'Prototipe' || activeMenu === 'Kekayaan Intelektual' ? 'Sinkronisasi hilirisasi prototipe, pengabdian, dan rekam berkas hak kekayaan intelektual' :
                 activeMenu === 'Kontrak' ? 'Verifikasi draf kontrak kerja, persetujuan Rektorat, dan pemantauan penerbitan Surat Keputusan (SK) dana hibah' :
                 'Menampilkan usulan data dan draf usulan terdaftar'}
              </span>
            </div>
            
            {activeMenu === 'Surat' || activeMenu === 'Modul Surat' ? (
              <LetterModuleView preset={selectedPreset} controls={controls} />
            ) : activeMenu === 'Prototipe' || activeMenu === 'Kekayaan Intelektual' ? (
              <PrototypeAndIntellectualPropertyView preset={selectedPreset} controls={controls} activeMenu={activeMenu} />
            ) : activeMenu === 'Kontrak' ? (
              <ContractModuleView preset={selectedPreset} controls={controls} />
            ) : (
              <TableView preset={selectedPreset} controls={controls} />
            )}
          </div>
        ) : (
          /* Dashboard is active: check Split vs Fullwidth modes */
          <div className={`grid grid-cols-1 ${controls.layoutMode === 'split' ? 'lg:grid-cols-4' : 'grid-cols-1'} gap-6 items-start`}>
            
            {/* Left Content column: Banner + Stats + Charts + Table list */}
            <div className={`${controls.layoutMode === 'split' ? 'lg:col-span-3' : 'col-span-1'} space-y-6`}>
              {/* Core welcome banner and state metrics */}
              <DashboardView preset={selectedPreset} controls={controls} />

              {/* Table embedded directly on the main dashboard tab for easy previewing */}
              <div className="pt-2">
                <div className="flex items-center justify-between mb-3">
                  <h3 className={`text-xs font-black uppercase tracking-wider ${colors.primaryText}`}>
                    Daftar Usulan Terdaftar
                  </h3>
                  <span className="text-[10px] text-indigo-600 font-bold bg-white px-2 py-0.5 border border-indigo-100 rounded">
                    Berdasarkan Filter Aktif
                  </span>
                </div>
                <TableView preset={selectedPreset} controls={controls} />
              </div>
            </div>

            {/* Right sidebar column: Profiles, stats, and logs */}
            {controls.layoutMode === 'split' && (
              <div className="space-y-6 lg:sticky lg:top-[205px]">
                <Sidebar preset={selectedPreset} controls={controls} />
              </div>
            )}

          </div>
        )}

      </div>

      {/* 5. Informative Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12 py-6 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-gray-500 font-medium">
          <div className="flex items-center gap-2">
            <span className="bg-[#1e3a6e] text-white px-2.5 py-0.5 font-bold rounded">INFO</span>
            <span>
              {showPlayground 
                ? "Gunakan tombol Ekspor Kode Template di atas untuk mengunduh kode JSX & Tailwind siap pakai." 
                : "Klik tombol ⚙️ Kustomisasi Tema di kanan atas untuk mengganti tema atau mengekspor kode template Tailwind."}
            </span>
          </div>
          <div>
            <span>Didesain oleh <strong className="text-gray-800 font-bold">LPPM ITSNU Pekalongan</strong> © 2026</span>
          </div>
        </div>
      </footer>

      {/* 6. Code Exporter Overlay Modal */}
      {controls.showCodeModal && (
        <CodeExporter 
          preset={selectedPreset}
          controls={controls}
          onClose={() => setControls((prev) => ({ ...prev, showCodeModal: false }))}
        />
      )}

    </div>
  );
}
