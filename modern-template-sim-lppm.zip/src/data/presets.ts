import { ThemePreset } from '../types';

export const themePresets: ThemePreset[] = [
  {
    id: 'sim-lppm',
    name: 'SIM LPPM (Akademik ITSNU)',
    description: 'Berdasarkan screenshot resmi LPPM ITSNU Pekalongan. Kombinasi warna biru tua, layout tab navigasi horizontal, serta panel performa dosen SINTA.',
    className: 'theme-lppm',
    config: {
      primaryBg: 'bg-[#1e3a6e]',
      primaryText: 'text-[#1e3a6e]',
      accentColor: '#3b82f6',
      sidebarBg: 'bg-white border border-gray-200',
      sidebarText: 'text-gray-700',
      cardBg: 'bg-white',
      textColor: 'text-gray-800',
      badgeStyle: 'bg-red-100 text-red-700 border-red-200',
      highlightColors: {
        first: 'bg-pink-600 hover:bg-pink-700',
        second: 'bg-teal-600 hover:bg-teal-700',
        third: 'bg-green-600 hover:bg-green-700',
      }
    },
    brand: {
      logoInitials: 'SIM LPPM',
      logoText: 'SIM LPPM',
      userRole: '👤 DOSEN',
      userName: 'MUJIBUL HAKIM',
      userAvatar: '👤',
      userMeta: 'Teknologi Informasi\nInstitut Teknologi Dan Sains Nahdlatul Ulama\nPekalongan',
      userSinta: '767',
      userEducation: 'S2',
      userRank: 'Lektor',
    },
    navigation: ['Dashboard', 'Penelitian', 'Pengabdian', 'Kontrak', 'Surat', 'Prototipe', 'Kekayaan Intelektual'],
    stats: [
      { value: '1', title: 'Penelitian', sub: 'Didanai oleh Simlitabmas/ITSNU', colorClass: 'bg-[#fb7185]', icon: '🔍' },
      { value: '2', title: 'Pengabdian', sub: 'Didanai oleh Simlitabmas/ITSNU', colorClass: 'bg-[#06b6d4]', icon: '🤝' },
      { value: '3', title: 'Surat', sub: 'Surat Tugas & Izin Penelitian/Abdimas', colorClass: 'bg-[#fbbf24]', icon: '✉️' },
      { value: '0', title: 'Prototipe', sub: 'Didanai oleh Simlitabmas/ITSNU', colorClass: 'bg-[#10b981]', icon: '📦' }
    ],
    history: [
      { category: 'Penelitian', title: 'Penerapan Sistem ERP UMKM Berkah Jaya' },
      { category: 'Pengabdian kepada Masyarakat', title: 'Pemberdayaan pengelolaan Sumberdaya BUMDes Berkah Jaya desa Karangasem melalui implementasi digital marketing' },
      { category: 'Surat', title: 'Surat Tugas Penelitian Mandiri No: 124/LPPM/ITSNU/2026' },
      { category: 'Prototipe', title: 'Tidak ada' }
    ],
    tableData: [
      {
        no: 1,
        col1: 'MUJIBUL HAKIM',
        col2: '(0608068901)',
        title: 'Sistem Rekomendasi Motif Batik Berbasis Large Language Model dan Knowledge Base untuk Peningkatan Kepuasan Pelanggan UMKM',
        category: 'Kerjasama Perguruan Tinggi',
        focus: 'Sosial Humaniora',
        field3: '2026',
        role: 'Ketua',
        status: 'tidak'
      },
      {
        no: 2,
        col1: 'HAFIZ GHULAM',
        col2: '(0627088203)',
        title: 'Analisis Berbasis Data Terhadap Persepsi Wisatawan Internasional Tentang Pariwisata Batik Pekalongan: Strategi Komunikasi Digital Berbahasa Inggris',
        category: 'Penelitian Dosen Pemula',
        focus: 'Sosial Humaniora',
        field3: '2026',
        role: 'Anggota',
        status: 'tidak'
      }
    ]
  },
  {
    id: 'saas-enterprise',
    name: 'SaaS Enterprise (LPPM Premium)',
    description: 'Desain SaaS global dengan layout modern minimalis. Menggunakan warna slate gelap, disesuaikan dengan SIM LPPM untuk Akreditasi & Analisis Kinerja Premium.',
    className: 'theme-saas',
    config: {
      primaryBg: 'bg-slate-900',
      primaryText: 'text-slate-950',
      accentColor: '#6366f1',
      sidebarBg: 'bg-white border border-slate-200',
      sidebarText: 'text-slate-600',
      cardBg: 'bg-white',
      textColor: 'text-slate-800',
      badgeStyle: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      highlightColors: {
        first: 'bg-indigo-600 hover:bg-indigo-700',
        second: 'bg-violet-600 hover:bg-violet-700',
        third: 'bg-sky-600 hover:bg-sky-700',
      }
    },
    brand: {
      logoInitials: 'SIM LPPM',
      logoText: 'SIM LPPM Enterprise',
      userRole: '💼 REVIEWER',
      userName: 'PROF. DR. KH. SYAMSUL BAHRI',
      userAvatar: '👤',
      userMeta: 'Sains & Teknologi\nInstitut Teknologi Dan Sains Nahdlatul Ulama Pekalongan',
      userSinta: '1240',
      userEducation: 'S3',
      userRank: 'Guru Besar',
    },
    navigation: ['Dashboard', 'Penelitian', 'Pengabdian', 'Kontrak', 'Surat', 'Prototipe', 'Kekayaan Intelektual'],
    stats: [
      { value: '12', title: 'Penelitian', sub: 'Didanai oleh Simlitabmas/ITSNU', colorClass: 'bg-indigo-600', icon: '🔍' },
      { value: '8', title: 'Pengabdian', sub: 'Didanai oleh Simlitabmas/ITSNU', colorClass: 'bg-violet-600', icon: '🤝' },
      { value: '5', title: 'Surat', sub: 'Surat Tugas & Izin Penelitian/Abdimas', colorClass: 'bg-sky-600', icon: '✉️' },
      { value: '2', title: 'Prototipe', sub: 'Didanai oleh Simlitabmas/ITSNU', colorClass: 'bg-[#10b981]', icon: '📦' }
    ],
    history: [
      { category: 'Penelitian', title: 'Rancang Bangun Sistem Grid IoT Pertanian Pekalongan' },
      { category: 'Pengabdian kepada Masyarakat', title: 'Edukasi Sanitasi Digital di Pondok Pesantren' },
      { category: 'Surat', title: 'Surat Tugas Reviewer Internal No: 089/LPPM/ITSNU/VI/2026' },
      { category: 'Prototipe', title: 'Prototipe Smart Energy Monitoring system' }
    ],
    tableData: [
      {
        no: 1,
        col1: 'PROF. DR. KH. SYAMSUL BAHRI',
        col2: '(0612056001)',
        title: 'Studi Komparatif Implementasi E-Government dan Kesiapan Infrastruktur Digital Pedesaan Kabupaten Pekalongan',
        category: 'Penelitian Fundamental',
        focus: 'Sosial Humaniora',
        field3: '2026',
        role: 'Ketua',
        status: 'didandai'
      },
      {
        no: 2,
        col1: 'MUJIBUL HAKIM',
        col2: '(0608068901)',
        title: 'Rancang Bangun Chatbot Konsultasi Hukum Islam dan Kemasyarakatan menggunakan Generative AI',
        category: 'Penelitian Terapan',
        focus: 'Sains & Teknologi',
        field3: '2026',
        role: 'Anggota',
        status: 'tidak'
      }
    ]
  },
  {
    id: 'cyber-dark',
    name: 'Cyber Dark (LPPM Lab Terminal)',
    description: 'Gaya visual modern futuristik gelap dengan background pekat, aksen hijau neon untuk SIM LPPM Divisi Keamanan IT & Pusat Data Riset.',
    className: 'theme-cyber',
    config: {
      primaryBg: 'bg-zinc-950',
      primaryText: 'text-emerald-400',
      accentColor: '#10b981',
      sidebarBg: 'bg-zinc-900 border border-zinc-850',
      sidebarText: 'text-zinc-400',
      cardBg: 'bg-zinc-900',
      textColor: 'text-zinc-100',
      badgeStyle: 'bg-emerald-950/70 text-emerald-300 border-emerald-900',
      highlightColors: {
        first: 'bg-emerald-600 hover:bg-emerald-700',
        second: 'bg-amber-600 hover:bg-amber-700',
        third: 'bg-purple-600 hover:bg-purple-700',
      }
    },
    brand: {
      logoInitials: 'SIM LPPM',
      logoText: 'SIM LPPM Cyber Lab',
      userRole: '🛡️ ADMIN IT',
      userName: 'AHMAD JUNAEDI, M.KOM.',
      userAvatar: '👤',
      userMeta: 'Keamanan Jaringan\nInstitut Teknologi Dan Sains Nahdlatul Ulama Pekalongan',
      userSinta: '450',
      userEducation: 'S2',
      userRank: 'Asisten Ahli',
    },
    navigation: ['Dashboard', 'Penelitian', 'Pengabdian', 'Kontrak', 'Surat', 'Prototipe', 'Kekayaan Intelektual'],
    stats: [
      { value: '4', title: 'Penelitian', sub: 'Didanai oleh Simlitabmas/ITSNU', colorClass: 'bg-emerald-700', icon: '🔍' },
      { value: '3', title: 'Pengabdian', sub: 'Didanai oleh Simlitabmas/ITSNU', colorClass: 'bg-amber-600', icon: '🤝' },
      { value: '2', title: 'Surat', sub: 'Surat Tugas & Izin Penelitian/Abdimas', colorClass: 'bg-purple-600', icon: '✉️' },
      { value: '1', title: 'Prototipe', sub: 'Didanai oleh Simlitabmas/ITSNU', colorClass: 'bg-[#10b981]', icon: '📦' }
    ],
    history: [
      { category: 'Penelitian', title: 'Riset Penetrasi Cyber Security Framework Kampus ITSNU' },
      { category: 'Pengabdian kepada Masyarakat', title: 'Pelatihan Keamanan Siber Kelurahan Pekalongan Utama' },
      { category: 'Surat', title: 'Surat Tugas Pengujian Kerentanan No: 072/2026' },
      { category: 'Prototipe', title: 'Prototipe Firewall IDS/IPS Machine Learning' }
    ],
    tableData: [
      {
        no: 1,
        col1: 'AHMAD JUNAEDI, M.KOM.',
        col2: '(0619028802)',
        title: 'Analisis Komparatif Algoritma Lightweight Cryptography untuk Pengamanan IoT Node pada Smart City Pekalongan',
        category: 'Penelitian Terapan',
        focus: 'Komputer & Keamanan',
        field3: '2026',
        role: 'Ketua',
        status: 'didandai'
      },
      {
        no: 2,
        col1: 'MUJIBUL HAKIM',
        col2: '(0608068901)',
        title: 'Kriptografi Visual Berbasis Matriks untuk Pengamanan Sertifikat E-Learning Kampus ITSNU Pekalongan',
        category: 'Penelitian Mandiri',
        focus: 'Sains & Teknologi',
        field3: '2026',
        role: 'Anggota',
        status: 'tidak'
      }
    ]
  },
  {
    id: 'amber-creative',
    name: 'Warm Creative (LPPM Budaya & Batik)',
    description: 'Kombinasi warna cokelat hangat dan aksen emas. Sangat cocok untuk SIM LPPM Divisi Desain Kreatif, Riset Kebudayaan lokal, dan Edukasi Batik.',
    className: 'theme-creative',
    config: {
      primaryBg: 'bg-[#451a03]',
      primaryText: 'text-[#451a03]',
      accentColor: '#f59e0b',
      sidebarBg: 'bg-white border border-[#fed7aa]',
      sidebarText: 'text-[#451a03]',
      cardBg: 'bg-[#fffffb]',
      textColor: 'text-[#451a03]',
      badgeStyle: 'bg-amber-100 text-[#b45309] border-amber-200',
      highlightColors: {
        first: 'bg-amber-700 hover:bg-amber-800',
        second: 'bg-rose-700 hover:bg-rose-800',
        third: 'bg-orange-700 hover:bg-orange-850',
      }
    },
    brand: {
      logoInitials: 'SIM LPPM',
      logoText: 'SIM LPPM Kreatif',
      userRole: '🎨 KAPRODI',
      userName: 'DENI ALFIAN, M.DS.',
      userAvatar: '👤',
      userMeta: 'Desain Komunikasi Visual\nInstitut Teknologi Dan Sains Nahdlatul Ulama Pekalongan',
      userSinta: '512',
      userEducation: 'S2',
      userRank: 'Lektor',
    },
    navigation: ['Dashboard', 'Penelitian', 'Pengabdian', 'Kontrak', 'Surat', 'Prototipe', 'Kekayaan Intelektual'],
    stats: [
      { value: '3', title: 'Penelitian', sub: 'Didanai oleh Simlitabmas/ITSNU', colorClass: 'bg-amber-700', icon: '🔍' },
      { value: '4', title: 'Pengabdian', sub: 'Didanai oleh Simlitabmas/ITSNU', colorClass: 'bg-[#06b6d4]', icon: '🤝' },
      { value: '6', title: 'Surat', sub: 'Surat Tugas & Izin Penelitian/Abdimas', colorClass: 'bg-orange-700', icon: '✉️' },
      { value: '1', title: 'Prototipe', sub: 'Didanai oleh Simlitabmas/ITSNU', colorClass: 'bg-[#10b981]', icon: '📦' }
    ],
    history: [
      { category: 'Penelitian', title: 'Revitalisasi Motif Batik Pesisiran Pekalongan Bermakna Filosofis Lokal Melalui Media Interaktif digital' },
      { category: 'Pengabdian kepada Masyarakat', title: 'Pendampingan Hak Paten Merek Dagang Pengrajin Batik Krapyak' },
      { category: 'Surat', title: 'Surat Tugas Deskripsi Inovasi Seni No: 031/2026' },
      { category: 'Prototipe', title: 'E-Catalog Batik Tradisional Pekalongan' }
    ],
    tableData: [
      {
        no: 1,
        col1: 'DENI ALFIAN, M.DS.',
        col2: '(0615019001)',
        title: 'Eksplorasi Ornamen Ragam Hias Pekalongan Utara Sebagai Media Kampanye Edukasi Pelestarian Mangrove',
        category: 'Program Kemitraan Wilayah',
        focus: 'Sosial Humaniora',
        field3: '2026',
        role: 'Ketua',
        status: 'didandai'
      },
      {
        no: 2,
        col1: 'MUJIBUL HAKIM',
        col2: '(0608068901)',
        title: 'Pengembangan Prototype Pembelajaran Aksara Jawa Klasik Berbasis Gamifikasi Untuk Sekolah Dasar Pekalongan',
        category: 'Penelitian Dosen Pemula',
        focus: 'Sosial Humaniora',
        field3: '2026',
        role: 'Anggota',
        status: 'tidak'
      }
    ]
  }
];
