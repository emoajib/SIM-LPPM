export interface ThemePreset {
  id: string;
  name: string;
  description: string;
  className: string;
  config: {
    primaryBg: string; // Tailwind class
    primaryText: string; // Tailwind class
    accentColor: string; // Tailwind hex or name
    sidebarBg: string;
    sidebarText: string;
    cardBg: string;
    textColor: string;
    badgeStyle: string;
    highlightColors: {
      first: string;
      second: string;
      third: string;
    };
  };
  brand: {
    logoInitials: string;
    logoText: string;
    userRole: string;
    userName: string;
    userAvatar: string;
    userMeta: string;
    userSinta?: string;
    userEducation?: string;
    userRank?: string;
  };
  navigation: string[];
  stats: {
    value: string;
    title: string;
    sub: string;
    colorClass: string;
    icon: string;
  }[];
  history: {
    category: string;
    title: string;
  }[];
  tableData: {
    no: number;
    col1: string; // Leader / Main Context
    col2: string; // Details / Sub Context
    title: string;
    category: string;
    focus: string;
    field3: string; // Additional field (Year/Cost)
    role: string;
    status: 'didandai' | 'proses' | 'tidak';
  }[];
}

export interface CustomControls {
  layoutMode: 'split' | 'fullwidth' | 'compact';
  showStats: boolean;
  showChart: boolean;
  showSidebarProfile: boolean;
  roundedMode: 'none' | 'md' | 'xl' | 'full';
  headerSticky: boolean;
  showCodeModal: boolean;
}
